"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="text-sm uppercase tracking-[0.2em] text-primary">Hindsight hiccup</p>
      <h1 className="mt-3 text-3xl font-semibold">That didn&apos;t load the way we predicted.</h1>
      <p className="mt-3 max-w-md text-muted-foreground">
        Something on our side is temporarily unavailable. Your data is safe — try again, or head back home.
      </p>
      <div className="mt-6 flex gap-3">
        <Button onClick={() => reset()}>Try again</Button>
        <Button asChild variant="secondary">
          <Link href="/">Home</Link>
        </Button>
      </div>
    </div>
  );
}

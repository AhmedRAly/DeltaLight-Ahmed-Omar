import type { Metadata } from "next";
import { ConnectionsClient } from "@/components/connections/connections-client";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Connections" };
export const dynamic = "force-dynamic";

export default async function ConnectionsPage() {
  const user = await getSessionUser();
  if (!hasSupabase()) {
    return (
      <div className="container max-w-3xl py-16">
        <h1 className="text-4xl font-semibold tracking-tight">Connections</h1>
        <p className="mt-3 text-muted-foreground">Set up Supabase to see your connections.</p>
      </div>
    );
  }
  if (!user) {
    return (
      <div className="container max-w-3xl py-16">
        <h1 className="text-4xl font-semibold tracking-tight">Connections</h1>
        <p className="mt-3 text-muted-foreground">Sign in to see your connections.</p>
      </div>
    );
  }
  const supabase = createAdminClient();
  const { data: rows } = await supabase
    .from("connections")
    .select("id, from_user, to_user, status, message, match_score, created_at")
    .or(`from_user.eq.${user.id},to_user.eq.${user.id}`)
    .order("created_at", { ascending: false });
  const ids = new Set<string>();
  for (const r of rows ?? []) {
    ids.add(r.from_user);
    ids.add(r.to_user);
  }
  const { data: profs } = await supabase
    .from("profiles")
    .select("id, name, headline, avatar_url, city")
    .in("id", Array.from(ids));
  const byId = new Map((profs ?? []).map((p) => [p.id, p]));
  type Conn = NonNullable<typeof rows>[number];
  const mine = (rows ?? []).map((r: Conn) => {
    const otherId = r.from_user === user.id ? r.to_user : r.from_user;
    const other = byId.get(otherId) ?? { id: otherId, name: "Someone", headline: null, avatar_url: null, city: null };
    return {
      id: r.id,
      status: r.status as "pending" | "accepted" | "declined",
      message: r.message,
      match_score: r.match_score,
      created_at: r.created_at,
      other,
    };
  });

  return (
    <div className="container max-w-3xl py-10 md:py-14">
      <h1 className="text-4xl font-semibold tracking-tight">Connections</h1>
      <p className="mt-3 text-muted-foreground">People you connected with on Hindsight.</p>
      <div className="mt-8">
        <ConnectionsClient mine={mine} meId={user.id} />
      </div>
    </div>
  );
}
import type { Metadata } from "next";
import { IngestConsole, type IngestRunRow, type SourceRow } from "@/components/admin/ingest-console";
import { SOURCES } from "@/lib/constants";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const metadata: Metadata = {
  title: "Ingestion console",
  description: "Pull real decision stories from public sources, with live progress.",
};

export const dynamic = "force-dynamic";

async function loadData(): Promise<{
  sources: SourceRow[];
  runs: IngestRunRow[];
  storyCount: number | null;
  error: string | null;
}> {
  const emptyRow = (s: (typeof SOURCES)[number]): SourceRow => ({
    id: s.id,
    name: s.name,
    type: s.type,
    base_url: s.baseUrl,
    last_synced_at: null,
    items_count: 0,
    last_status: null,
    last_error: null,
  });
  const fallback: SourceRow[] = SOURCES.map(emptyRow);
  if (!hasSupabase()) {
    return { sources: fallback, runs: [], storyCount: null, error: "Supabase is not configured — set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY." };
  }
  try {
    const db = createAdminClient();
    const [sourcesRes, runsRes, countRes] = await Promise.all([
      db.from("sources").select("*"),
      db.from("ingest_runs").select("*").order("started_at", { ascending: false }).limit(30),
      db.from("stories").select("id", { count: "exact", head: true }),
    ]);
    const rows = sourcesRes.data ?? [];
    const byId = new Map(rows.map((r): [string, SourceRow] => [r.id, r]));
    // Keep the canonical order from constants; include any DB-only rows at the end.
    const ordered: SourceRow[] = SOURCES.map((s) => byId.get(s.id) ?? emptyRow(s));
    for (const r of rows) if (!SOURCES.some((s) => s.id === r.id)) ordered.push(r);
    const error = sourcesRes.error?.message ?? runsRes.error?.message ?? null;
    return {
      sources: ordered,
      runs: runsRes.data ?? [],
      storyCount: countRes.error ? null : countRes.count ?? 0,
      error: error ? `Could not load everything from the database: ${error}` : null,
    };
  } catch (err) {
    return {
      sources: fallback,
      runs: [],
      storyCount: null,
      error: err instanceof Error ? err.message : "Could not reach the database",
    };
  }
}

export default async function AdminIngestPage() {
  const { sources, runs, storyCount, error } = await loadData();
  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] glow" aria-hidden />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] grid-bg" aria-hidden />
      <div className="container relative py-10 md:py-14">
        <IngestConsole
          initialSources={sources}
          initialRuns={runs}
          initialStoryCount={storyCount}
          loadError={error}
          adminTokenRequired={Boolean(process.env.ADMIN_TOKEN)}
        />
      </div>
    </div>
  );
}

import type { Metadata, Viewport } from "next";
import { Bricolage_Grotesque, Fraunces } from "next/font/google";
import { ThemeShell } from "@/components/site/theme-shell";
import { SiteNav } from "@/components/site/nav";
import { getSessionUser } from "@/lib/supabase/server";
import "./globals.css";

const inter = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const serif = Fraunces({ subsets: ["latin"], variable: "--font-serif", display: "swap", style: ["normal", "italic"] });

export const metadata: Metadata = {
  title: { default: "Hindsight — What do you need advice for?", template: "%s · Hindsight" },
  description:
    "Ask what you're deciding. Hindsight searches real posts from people who already made the call — and shows you exactly where every answer came from.",
};

export const viewport: Viewport = { themeColor: "#09090b", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getSessionUser();
  return (
    <html lang="en" className={`dark ${inter.variable} ${serif.variable}`}>
      <body className="font-sans">
        <ThemeShell>
          <SiteNav signedIn={Boolean(user)} userName={user?.name ?? null} />
          <main className="relative">{children}</main>
          <footer className="border-t py-10 text-sm text-muted-foreground">
            <div className="container flex flex-col justify-between gap-3 md:flex-row">
              <p>Hindsight — learn from people who already decided. Every answer is traceable to its source.</p>
              <p>
                Excerpts link to their original public posts and a stored raw record. Community posts, member profiles and some decision statistics are illustrative sample content.
              </p>
            </div>
          </footer>
        </ThemeShell>
      </body>
    </html>
  );
}

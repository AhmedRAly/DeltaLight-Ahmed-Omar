import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="text-sm uppercase tracking-[0.2em] text-primary">404</p>
      <h1 className="mt-3 text-3xl font-semibold">Nobody has made this page yet.</h1>
      <p className="mt-3 text-muted-foreground">But plenty of people have made your decision.</p>
      <Button asChild className="mt-6">
        <Link href="/ask">Ask Hindsight</Link>
      </Button>
    </div>
  );
}

import type { Metadata } from "next";
import { ResearchView } from "@/components/research/research-view";

export const metadata: Metadata = { title: "Research" };

export default function AskPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = typeof searchParams.q === "string" ? searchParams.q.slice(0, 400) : "";
  return <ResearchView key={q} q={q} />;
}

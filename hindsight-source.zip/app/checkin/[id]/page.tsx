import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { CheckinPanel } from "@/components/log/checkin-panel";
import { HORIZONS, type Horizon } from "@/lib/constants";
import { findSimilar, EMPTY_INSIGHTS } from "@/lib/hindsight";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const metadata: Metadata = { title: "Check in" };
export const dynamic = "force-dynamic";

export default async function CheckinPage({ params }: { params: { id: string } }) {
  const id = z.string().uuid().safeParse(params.id);
  if (!id.success || !hasSupabase()) notFound();
  const supabase = createAdminClient();

  const { data: decision } = await supabase
    .from("decisions")
    .select("id, text, category, options, chosen_option, predicted_happiness, predicted_outcome, confidence, created_at, embedding, is_seed")
    .eq("id", id.data)
    .maybeSingle();
  if (!decision) notFound();

  const [{ data: checkins }, { data: schedule }] = await Promise.all([
    supabase.from("checkins").select("horizon, actual_happiness, regret, would_choose_again, biggest_surprise, surprise_tags, checkin_at").eq("decision_id", decision.id),
    supabase.from("scheduled_checkins").select("horizon, due_at, status").eq("decision_id", decision.id),
  ]);

  let crowd = EMPTY_INSIGHTS;
  try {
    const res = await findSimilar({
      text: decision.text,
      embedding: decision.embedding ?? null,
      decisionCount: 40,
      storyCount: 0,
      excludeId: decision.id,
    });
    crowd = res.insights;
  } catch {
    crowd = EMPTY_INSIGHTS;
  }

  const order = (h: string) => HORIZONS.indexOf(h as Horizon);
  const sortedSchedule = (schedule ?? []).sort((a, b) => order(a.horizon) - order(b.horizon));
  const done = new Set((checkins ?? []).map((c) => c.horizon));

  return (
    <div className="container max-w-3xl py-10 md:py-14">
      <CheckinPanel
        decision={{
          id: decision.id,
          text: decision.text,
          chosen_option: decision.chosen_option,
          predicted_happiness: decision.predicted_happiness,
          predicted_outcome: decision.predicted_outcome,
          confidence: decision.confidence,
          created_at: decision.created_at,
        }}
        checkins={(checkins ?? []).map((c) => ({ ...c, horizon: c.horizon as Horizon })).sort((a, b) => order(a.horizon) - order(b.horizon))}
        schedule={sortedSchedule.map((s) => ({ horizon: s.horizon as Horizon, due_at: s.due_at, status: s.status, done: done.has(s.horizon) }))}
        crowd={crowd}
      />
    </div>
  );
}

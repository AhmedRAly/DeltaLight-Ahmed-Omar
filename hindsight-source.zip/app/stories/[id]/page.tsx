import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, Clock } from "lucide-react";
import { z } from "zod";
import { OutcomeBadge, SourceBadge } from "@/components/stories/source-badge";
import { StoryCard, StoryFlow } from "@/components/stories/story-card";
import { Avatar } from "@/components/ui/misc";
import type { Database, StoryMatch } from "@/lib/database.types";
import { STAGE_LABEL, sourceLabel, type Stage } from "@/lib/constants";
import { STORY_COLUMNS } from "@/lib/stories";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

type PersonMatch = Database["public"]["Functions"]["match_profiles_by_embedding"]["Returns"][number];

async function load(id: string) {
  const supabase = createAdminClient();
  const { data: story } = await supabase.from("stories").select(`${STORY_COLUMNS}, embedding`).eq("id", id).maybeSingle();
  if (!story) return null;
  let similar: StoryMatch[] = [];
  let people: PersonMatch[] = [];
  if (story.embedding) {
    const [s, p] = await Promise.all([
      supabase.rpc("match_stories", { query_embedding: story.embedding, match_count: 5, filter_path: null }),
      supabase.rpc("match_profiles_by_embedding", { query_embedding: story.embedding, match_count: 4 }),
    ]);
    similar = s.data ?? [];
    people = p.data ?? [];
  } else {
    const s = await supabase.rpc("search_stories_text", { q: story.title, match_count: 5, filter_path: null });
    similar = s.data ?? [];
  }
  return { story, similar: similar.filter((s) => s.id !== story.id).slice(0, 4), people };
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  if (!z.string().uuid().safeParse(params.id).success || !hasSupabase()) return { title: "Story" };
  try {
    const { data } = await createAdminClient().from("stories").select("title, tldr").eq("id", params.id).maybeSingle();
    return data ? { title: data.title, description: data.tldr } : { title: "Story" };
  } catch {
    return { title: "Story" };
  }
}

export default async function StoryPage({ params }: { params: { id: string } }) {
  if (!z.string().uuid().safeParse(params.id).success || !hasSupabase()) notFound();
  const data = await load(params.id).catch(() => null);
  if (!data) notFound();
  const { story, similar, people } = data;

  return (
    <article className="container max-w-3xl py-10 md:py-16">
      <Link href="/stories" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All stories
      </Link>

      <div className="mt-8 flex flex-wrap items-center gap-2">
        <SourceBadge sourceId={story.source_id} url={story.url} />
        <OutcomeBadge type={story.outcome_type} />
        <span className="rounded-full border px-2.5 py-0.5 text-[11px] capitalize text-muted-foreground">{story.path}</span>
        <span className="rounded-full border px-2.5 py-0.5 text-[11px] capitalize text-muted-foreground">{story.category}</span>
        <span className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" /> {story.read_time_min} min read
        </span>
      </div>

      <h1 className="mt-6 font-serif text-4xl leading-[1.1] tracking-tight md:text-5xl">{story.title}</h1>
      <p className="mt-6 font-serif text-xl leading-relaxed text-foreground/85 md:text-2xl">{story.tldr}</p>

      <div className="mt-10">
        <StoryFlow story={story} />
      </div>

      <div className="prose-story mt-10">
        <h2 className="mb-3 text-sm uppercase tracking-[0.16em] text-muted-foreground">The decision</h2>
        <p>{story.decision_text}</p>
        {story.what_they_chose && (
          <>
            <h2 className="mb-3 mt-8 text-sm uppercase tracking-[0.16em] text-muted-foreground">What they chose</h2>
            <p>{story.what_they_chose}</p>
          </>
        )}
        {story.outcome && (
          <>
            <h2 className="mb-3 mt-8 text-sm uppercase tracking-[0.16em] text-muted-foreground">What happened</h2>
            <p>{story.outcome}</p>
          </>
        )}
      </div>

      {(story.timeline || story.revenue_or_salary_mentioned) && (
        <dl className="mt-6 grid gap-3 sm:grid-cols-2">
          {story.timeline && (
            <div className="rounded-xl border bg-card/60 p-4">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Timeline</dt>
              <dd className="mt-1">{story.timeline}</dd>
            </div>
          )}
          {story.revenue_or_salary_mentioned && (
            <div className="rounded-xl border bg-card/60 p-4">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Numbers mentioned</dt>
              <dd className="mt-1">{story.revenue_or_salary_mentioned}</dd>
            </div>
          )}
        </dl>
      )}

      {story.lessons.length > 0 && (
        <section className="mt-10 rounded-2xl border bg-gradient-to-br from-primary/10 to-transparent p-6">
          <h2 className="text-sm uppercase tracking-[0.16em] text-primary">Lessons</h2>
          <ul className="mt-4 space-y-3">
            {story.lessons.map((l) => (
              <li key={l} className="flex gap-3 text-lg leading-relaxed">
                <span className="mt-3 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {l}
              </li>
            ))}
          </ul>
        </section>
      )}

      {story.surprise_tags.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {story.surprise_tags.map((t) => (
            <span key={t} className="rounded-full border px-3 py-1 text-sm text-muted-foreground">{t}</span>
          ))}
        </div>
      )}

      <div className="mt-10 flex flex-col justify-between gap-3 rounded-2xl border bg-card/70 p-5 sm:flex-row sm:items-center">
        <p className="text-sm text-muted-foreground">
          Originally shared on <span className="text-foreground">{sourceLabel(story.source_id, story.url)}</span>
          {story.author_handle ? <> by {story.author_handle}</> : null}. Summary generated by AI from the public post.
        </p>
        <a
          href={story.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex shrink-0 items-center gap-1 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Read original <ArrowUpRight className="h-4 w-4" />
        </a>
      </div>

      {people.length > 0 && (
        <section className="mt-14">
          <h2 className="text-xl font-semibold tracking-tight">People working on this now</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {people.map((p) => (
              <Link key={p.id} href={`/partners/${p.id}`} className="flex items-start gap-3 rounded-xl border bg-card/60 p-4 transition hover:border-primary/40">
                <Avatar name={p.name} src={p.avatar_url} />
                <div className="min-w-0">
                  <div className="font-medium">{p.name}</div>
                  <div className="line-clamp-1 text-sm text-muted-foreground">{p.headline ?? STAGE_LABEL[p.stage as Stage]}</div>
                  <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{p.goals}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {similar.length > 0 && (
        <section className="mt-14">
          <h2 className="text-xl font-semibold tracking-tight">Similar stories</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {similar.map((s) => (
              <StoryCard key={s.id} story={s} compact />
            ))}
          </div>
        </section>
      )}
    </article>
  );
}

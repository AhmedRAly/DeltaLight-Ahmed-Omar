import type { Metadata } from "next";
import Link from "next/link";
import { Search } from "lucide-react";
import { Library } from "@/components/stories/library";
import { StoryCard } from "@/components/stories/story-card";
import { CATEGORIES, OUTCOME_TYPES, SOURCES } from "@/lib/constants";
import { storyFiltersSchema } from "@/lib/schemas";
import { listStories, type StoryFilters, type StoryRow } from "@/lib/stories";
import { hasSupabase } from "@/lib/supabase/admin";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "Real stories" };
export const dynamic = "force-dynamic";

type SP = Record<string, string | string[] | undefined>;

function href(sp: SP, patch: Record<string, string | undefined>) {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries({ ...sp, ...patch })) {
    if (typeof v === "string" && v && k !== "page") params.set(k, v);
  }
  if (patch.page) params.set("page", patch.page);
  const s = params.toString();
  return s ? `/stories?${s}` : "/stories";
}

function Chip({ active, to, children }: { active: boolean; to: string; children: React.ReactNode }) {
  return (
    <Link
      href={to}
      scroll={false}
      className={cn(
        "whitespace-nowrap rounded-full border px-3 py-1 text-sm capitalize transition",
        active ? "border-primary/50 bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {children}
    </Link>
  );
}

export default async function StoriesPage({ searchParams }: { searchParams: SP }) {
  const flat = Object.fromEntries(Object.entries(searchParams).map(([k, v]) => [k, Array.isArray(v) ? v[0] : v]));
  const parsed = storyFiltersSchema.safeParse(flat);
  const f: StoryFilters = parsed.success ? parsed.data : { page: 0 };

  let stories: StoryRow[] = [];
  let mode = "latest";
  let hasMore = false;
  let failed = false;
  if (hasSupabase()) {
    try {
      const res = await listStories(f);
      stories = res.stories;
      mode = res.mode;
      hasMore = res.hasMore;
    } catch {
      failed = true;
    }
  } else failed = true;

  return (
    <div className="container max-w-6xl py-10 md:py-14">
      <header className="max-w-3xl">
        <p className="text-xs uppercase tracking-[0.18em] text-primary">Stories</p>
        <h1 className="mt-3 font-serif text-5xl leading-[1.05] tracking-tight md:text-6xl">People who already did it.</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          First-person accounts of starting businesses, switching careers and climbing the ladder, pulled from public sources and
          linked back to the original. Structured stories appear as posts are processed; until then, browse the raw posts below.
        </p>
      </header>

      <form action="/stories" className="mt-8 flex items-center gap-2 rounded-2xl border bg-card/80 p-2">
        <Search className="ml-2 h-5 w-5 text-muted-foreground" />
        <input
          name="q"
          defaultValue={f.q ?? ""}
          placeholder="Search stories: “quit consulting to start an agency”"
          className="h-11 flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground/70"
        />
        {f.path && <input type="hidden" name="path" value={f.path} />}
        <button className="h-11 rounded-xl bg-primary px-5 text-sm font-medium text-primary-foreground">Search</button>
      </form>

      <div className="mt-5 space-y-3">
        <div className="flex gap-2 overflow-x-auto pb-1">
          <Chip active={!f.path} to={href(flat, { path: undefined })}>All paths</Chip>
          <Chip active={f.path === "business"} to={href(flat, { path: "business" })}>Business</Chip>
          <Chip active={f.path === "corporate"} to={href(flat, { path: "corporate" })}>Corporate</Chip>
          <span className="mx-1 w-px shrink-0 bg-border" />
          {OUTCOME_TYPES.map((o) => (
            <Chip key={o} active={f.outcome === o} to={href(flat, { outcome: f.outcome === o ? undefined : o })}>
              {o}
            </Chip>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((c) => (
            <Chip key={c} active={f.category === c} to={href(flat, { category: f.category === c ? undefined : c })}>
              {c}
            </Chip>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {SOURCES.map((s) => (
            <Chip key={s.id} active={f.source === s.id} to={href(flat, { source: f.source === s.id ? undefined : s.id })}>
              <span className="normal-case">{s.name}</span>
            </Chip>
          ))}
        </div>
      </div>

      {f.q && (
        <p className="mt-6 text-sm text-muted-foreground">
          {stories.length} results for &ldquo;{f.q}&rdquo; · {mode === "hybrid" ? "semantic + keyword search" : "keyword search"}
        </p>
      )}

      {failed ? (
        <div className="mt-10 rounded-2xl border bg-card/70 p-8 text-center text-muted-foreground">
          Stories are temporarily unavailable. Please try again in a moment.
        </div>
      ) : stories.length === 0 ? (
        <Library q={typeof flat.q === "string" ? flat.q : undefined} />
      ) : (
        <div className="mt-8 grid gap-5 md:grid-cols-2">
          {stories.map((s) => (
            <StoryCard key={s.id} story={s} />
          ))}
        </div>
      )}

      {(hasMore || f.page > 0) && !f.q && (
        <div className="mt-10 flex justify-center gap-3">
          {f.page > 0 && (
            <Link href={href(flat, { page: String(f.page - 1) })} className="rounded-xl border px-4 py-2 text-sm hover:bg-secondary">
              ← Newer
            </Link>
          )}
          {hasMore && (
            <Link href={href(flat, { page: String(f.page + 1) })} className="rounded-xl border px-4 py-2 text-sm hover:bg-secondary">
              Older →
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

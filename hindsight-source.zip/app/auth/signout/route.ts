import { NextResponse } from "next/server";
import { DEMO_COOKIE } from "@/lib/demo";
import { createServerSupabase } from "@/lib/supabase/server";

export async function POST(req: Request) {
  try {
    await createServerSupabase().auth.signOut();
  } catch {
    // no real session to clear
  }
  const res = NextResponse.redirect(new URL("/", req.url), { status: 303 });
  res.cookies.set(DEMO_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}

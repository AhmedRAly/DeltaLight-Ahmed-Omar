import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, ChevronLeft, Database, ShieldCheck } from "lucide-react";
import { LiveRecord } from "@/components/research/live-record";
import { SourceBadge } from "@/components/stories/source-badge";
import { rawApiUrlFor } from "@/lib/research";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const metadata: Metadata = { title: "Source record" };
export const dynamic = "force-dynamic";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function SourcePage({ params }: { params: { id: string } }) {
  if (!UUID.test(params.id) || !hasSupabase()) notFound();
  const db = createAdminClient();
  const { data: raw } = await db.from("raw_items").select("*").eq("id", params.id).maybeSingle();
  if (!raw) notFound();
  const { data: story } = await db.from("stories").select("id, title").eq("raw_item_id", raw.id).maybeSingle();
  const rawApi = rawApiUrlFor(raw.external_id);

  const rows: [string, string][] = [
    ["Source", raw.source_id],
    ["External ID", raw.external_id],
    ["Author handle", raw.author_handle ?? "—"],
    ["Posted", raw.posted_at ? new Date(raw.posted_at).toUTCString() : "—"],
    ["Fetched by Hindsight", new Date(raw.fetched_at).toUTCString()],
    ["Score at fetch", String(raw.score)],
    ["Stored characters", String(raw.body.length)],
  ];

  return (
    <div className="container max-w-4xl py-10 md:py-14">
      <Link href="/ask" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Back to research
      </Link>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <SourceBadge sourceId={raw.source_id} url={raw.url} />
        <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-medium text-emerald-400">
          <Database className="h-3 w-3" /> Raw record
        </span>
      </div>
      <h1 className="mt-4 text-3xl font-semibold leading-tight tracking-tight md:text-4xl">{raw.title}</h1>

      <div className="mt-6 flex flex-wrap gap-3">
        <a
          href={raw.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:brightness-110"
        >
          Open original post <ArrowUpRight className="h-4 w-4" />
        </a>
        {rawApi && (
          <a
            href={rawApi}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm hover:bg-secondary"
          >
            Open raw API response <ArrowUpRight className="h-4 w-4" />
          </a>
        )}
        {story && (
          <Link href={`/stories/${story.id}`} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm hover:bg-secondary">
            Structured story →
          </Link>
        )}
      </div>

      <section className="mt-10 overflow-hidden rounded-2xl border bg-card/70">
        <dl className="divide-y">
          {rows.map(([k, v]) => (
            <div key={k} className="grid grid-cols-3 gap-4 px-5 py-3 text-sm">
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="col-span-2 break-all font-mono text-[13px]">{v}</dd>
            </div>
          ))}
          <div className="grid grid-cols-3 gap-4 px-5 py-3 text-sm">
            <dt className="text-muted-foreground">Original URL</dt>
            <dd className="col-span-2 break-all font-mono text-[13px]">{raw.url}</dd>
          </div>
        </dl>
      </section>

      <section className="mt-8">
        <h2 className="text-lg font-semibold tracking-tight">Text exactly as stored</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          HTML tags are stripped and whitespace normalized; the words are not edited. Compare with the original post above.
        </p>
        <pre className="mt-4 max-h-[520px] overflow-auto whitespace-pre-wrap rounded-2xl border bg-black/40 p-5 font-mono text-[13px] leading-relaxed text-foreground/85">
          {raw.body}
        </pre>
      </section>

      {rawApi && <LiveRecord rawApiUrl={rawApi} />}

      <section className="mt-10 rounded-2xl border border-primary/20 bg-primary/5 p-5">
        <div className="flex items-center gap-2 text-sm font-medium text-primary">
          <ShieldCheck className="h-4 w-4" /> How to verify this yourself
        </div>
        <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-sm text-foreground/80">
          <li>Open the original post and compare the text.</li>
          <li>Open the raw API response — it is the public JSON Hindsight parsed this record from.</li>
          <li>Use &ldquo;Fetch live JSON&rdquo; to pull it again right now, directly from your browser.</li>
        </ol>
      </section>
    </div>
  );
}

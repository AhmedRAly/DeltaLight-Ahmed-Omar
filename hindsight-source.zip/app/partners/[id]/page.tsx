import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, MapPin } from "lucide-react";
import { z } from "zod";
import { ConnectButton } from "@/components/partners/connect-button";
import { Avatar } from "@/components/ui/misc";
import { LOOKING_FOR_LABEL, STAGE_LABEL, type LookingFor, type Stage } from "@/lib/constants";
import { explainMatch } from "@/lib/partners";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Profile" };
export const dynamic = "force-dynamic";

export default async function PartnerProfilePage({ params }: { params: { id: string } }) {
  if (!z.string().uuid().safeParse(params.id).success || !hasSupabase()) notFound();
  const supabase = createAdminClient();
  const { data: p } = await supabase
    .from("profiles")
    .select("id, name, headline, avatar_url, city, path, stage, goals, skills_have, skills_need, hours_per_week, looking_for, is_seed, is_guest")
    .eq("id", params.id)
    .maybeSingle();
  if (!p) notFound();

  const user = await getSessionUser();
  let match: { score: number; sentence: string } | null = null;
  let viewerHasProfile = false;
  if (user && user.id !== p.id) {
    const { data: me } = await supabase.from("profiles").select("id, path, stage").eq("id", user.id).maybeSingle();
    viewerHasProfile = Boolean(me);
    if (me) {
      const { data: ms } = await supabase.rpc("match_partners", { p_user_id: me.id, match_count: 200 });
      const m = (ms ?? []).find((x) => x.id === p.id);
      if (m) match = { score: m.score, sentence: explainMatch(m, me).sentence };
    }
  }

  return (
    <div className="container max-w-3xl py-10 md:py-14">
      <Link href="/partners" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Partners
      </Link>
      <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-center">
        <Avatar name={p.name} src={p.avatar_url} size={88} />
        <div className="flex-1">
          <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">
            {p.name}
          </h1>
          {p.headline && <p className="mt-1 text-lg text-muted-foreground">{p.headline}</p>}
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
            {p.city && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" /> {p.city}
              </span>
            )}
            <span className="capitalize">{p.path}</span>
            <span>{STAGE_LABEL[p.stage as Stage] ?? p.stage}</span>
            <span>{p.hours_per_week} h/week</span>
          </div>
        </div>
        {match && (
          <div className="text-right">
            <div className="text-5xl font-semibold text-primary">{Math.round(match.score * 100)}%</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">match with you</div>
          </div>
        )}
      </div>

      {match && <p className="mt-6 rounded-xl border bg-primary/5 p-4 text-foreground/90">{match.sentence}</p>}

      <section className="mt-8 rounded-2xl border bg-card/70 p-6">
        <h2 className="text-sm uppercase tracking-[0.16em] text-muted-foreground">Goals</h2>
        <p className="mt-3 text-lg leading-relaxed">{p.goals}</p>
      </section>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <section className="rounded-2xl border bg-card/70 p-6">
          <h2 className="text-sm uppercase tracking-[0.16em] text-muted-foreground">Has</h2>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {p.skills_have.map((s) => (
              <span key={s} className="rounded-md bg-emerald-500/15 px-2 py-0.5 text-sm text-emerald-300">{s}</span>
            ))}
          </div>
        </section>
        <section className="rounded-2xl border bg-card/70 p-6">
          <h2 className="text-sm uppercase tracking-[0.16em] text-muted-foreground">Needs</h2>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {p.skills_need.map((s) => (
              <span key={s} className="rounded-md bg-primary/15 px-2 py-0.5 text-sm text-primary">{s}</span>
            ))}
          </div>
        </section>
      </div>

      {p.looking_for.length > 0 && (
        <p className="mt-6 text-sm text-muted-foreground">
          Looking for: {p.looking_for.map((l) => LOOKING_FOR_LABEL[l as LookingFor] ?? l).join(" · ")}
        </p>
      )}

      {user?.id !== p.id && (
        <div className="mt-8">
          <ConnectButton toUser={p.id} name={p.name} signedIn={Boolean(user)} hasProfile={viewerHasProfile} score={match?.score ?? null} />
        </div>
      )}
    </div>
  );
}

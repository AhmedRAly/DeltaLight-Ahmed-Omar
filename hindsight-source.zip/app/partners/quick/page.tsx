import type { Metadata } from "next";
import { QuickForm } from "@/components/partners/quick-form";

export const metadata: Metadata = { title: "Quick match" };

export default function QuickPartnerPage({ searchParams }: { searchParams: { room?: string } }) {
  const room = typeof searchParams.room === "string" ? searchParams.room.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) : "";
  return (
    <div className="container max-w-xl py-10">
      {room && (
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm text-primary">
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" /> Live room {room}
        </div>
      )}
      <h1 className="text-4xl font-semibold tracking-tight">Who should you talk to?</h1>
      <p className="mt-3 text-muted-foreground">30 seconds. We&apos;ll match you with people in this room and beyond.</p>
      <div className="mt-8">
        <QuickForm room={room || undefined} />
      </div>
    </div>
  );
}

import type { Metadata } from "next";
import { MemberGrid } from "@/components/business/member-grid";
import { Circles, parseCircles, type Circle } from "@/components/partners/circles";
import { PartnersApp } from "@/components/partners/partners-app";
import type { ProfileDraft } from "@/components/partners/profile-form";
import type { LookingFor, PathKind, Stage } from "@/lib/constants";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Hindsight Business" };
export const dynamic = "force-dynamic";

export default async function PartnersPage({ searchParams }: { searchParams: { path?: string } }) {
  const user = await getSessionUser();
  let own: (Partial<ProfileDraft> & { id: string }) | null = null;
  let circles: Circle[] = [];

  if (hasSupabase()) {
    const supabase = createAdminClient();
    try {
      const circlesRes = await supabase.rpc("circles_overview", { member_limit: 7 });
      circles = parseCircles(circlesRes.data ?? null);
      const p = user
        ? (
            await supabase
              .from("profiles")
              .select("id, name, headline, city, path, stage, goals, skills_have, skills_need, hours_per_week, looking_for")
              .eq("id", user.id)
              .maybeSingle()
          ).data
        : null;
      if (p) {
        own = {
          id: p.id,
          name: p.name,
          headline: p.headline ?? "",
          city: p.city ?? "",
          path: p.path as PathKind,
          stage: p.stage as Stage,
          goals: p.goals,
          skills_have: p.skills_have,
          skills_need: p.skills_need,
          hours_per_week: p.hours_per_week,
          looking_for: p.looking_for as LookingFor[],
        };
      }
    } catch {
      circles = [];
    }
  }

  return (
    <div className="container max-w-6xl py-10 md:py-14">
      <header className="max-w-3xl">
        <p className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Hindsight Business
        </p>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight md:text-6xl">The people on the other side of the decision.</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Founders, operators and career-switchers who&apos;ve made the same call you&apos;re weighing. Find co-founders, mentors and
          accountability partners — matched on goals and the skills you&apos;re missing.
        </p>
      </header>
      <MemberGrid path={typeof searchParams.path === "string" ? searchParams.path : "all"} />
      <div className="mt-14 grid gap-10 lg:grid-cols-[1fr_380px]">
        <PartnersApp signedIn={Boolean(user)} ownProfileId={own?.id ?? null} ownProfile={own} />
        <aside className="lg:sticky lg:top-20 lg:self-start">
          <Circles circles={circles} />
        </aside>
      </div>
    </div>
  );
}

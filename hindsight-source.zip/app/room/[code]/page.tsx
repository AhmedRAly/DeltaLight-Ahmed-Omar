import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RoomQR } from "@/components/room/qr-code";
import { RoomView } from "@/components/room/room-view";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: { code: string } }): Promise<Metadata> {
  const code = params.code.toUpperCase();
  return { title: `Room ${code}` };
}

export default async function RoomPage({ params }: { params: { code: string } }) {
  const code = params.code.toUpperCase();
  if (!/^[A-Z0-9]{3,8}$/.test(code)) notFound();
  if (!hasSupabase()) {
    return (
      <div className="container max-w-3xl py-16">
        <h1 className="text-4xl font-semibold tracking-tight">Room {code}</h1>
        <p className="mt-3 text-muted-foreground">Set up Supabase to run a live room.</p>
      </div>
    );
  }
  const supabase = createAdminClient();
  const { data: exists } = await supabase.from("decisions").select("id").eq("room_code", code).limit(1);
  const { data: profs } = await supabase.from("profiles").select("id").eq("room_code", code).limit(1);
  if (!exists?.length && !profs?.length) {
    return (
      <div className="container max-w-3xl py-16">
        <h1 className="text-4xl font-semibold tracking-tight">Room {code}</h1>
        <p className="mt-3 text-muted-foreground">No one has joined yet. Share the link and decisions will appear live.</p>
        <div className="mt-8 flex gap-3">
          <Button asChild>
            <Link href={`/log?room=${code}`}>Log a decision in this room</Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href={`/partners/quick?room=${code}`}>Join as a partner</Link>
          </Button>
        </div>
      </div>
    );
  }

  const site = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

  return (
    <div className="container max-w-5xl py-10 md:py-14">
      <Link href="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Home
      </Link>
      <div className="mt-6 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-primary">Live room</p>
          <h1 className="mt-2 font-mono text-5xl font-semibold tracking-tight md:text-6xl">{code}</h1>
        </div>
        <div className="flex gap-3">
          <Button asChild>
            <Link href={`/log?room=${code}`}>Log a decision</Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href={`/partners/quick?room=${code}`}>Find a partner</Link>
          </Button>
        </div>
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <div className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" /> Live stats update in real time as people submit.
          </div>
          <RoomView code={code} />
        </div>
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border bg-card/80 p-6 text-center">
            <RoomQR url={`${site}/log?room=${code}`} />
            <p className="mt-4 text-sm text-muted-foreground">Scan to join this room</p>
            <div className="mt-3 space-y-2">
              <Button asChild className="w-full">
                <Link href={`/log?room=${code}`}>Log a decision</Link>
              </Button>
              <Button asChild variant="secondary" className="w-full">
                <Link href={`/partners/quick?room=${code}`}>Find a partner</Link>
              </Button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
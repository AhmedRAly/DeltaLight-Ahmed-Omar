import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, QrCode, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { roomCode } from "@/lib/utils";

export const metadata: Metadata = { title: "Start a room" };
export const dynamic = "force-dynamic";

export default function NewRoomPage() {
  const code = roomCode();
  return (
    <div className="container max-w-3xl py-10 md:py-16">
      <Link href="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Home
      </Link>
      <h1 className="mt-6 text-4xl font-semibold tracking-tight">Your live room</h1>
      <p className="mt-3 text-muted-foreground">Share this code with the room. Decisions and partner matches appear live.</p>
      <div className="mt-8 flex flex-col items-center gap-6 rounded-3xl border bg-card/80 p-8 text-center">
        <div className="font-mono text-6xl font-bold tracking-[0.1em] text-primary">{code}</div>
        <div className="flex gap-3">
          <Button asChild>
            <Link href={`/room/${code}`}>Open room</Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href={`/log?room=${code}`}>Log a decision</Link>
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">Judges scan the QR on the room page to submit decisions from their phones.</p>
      </div>
    </div>
  );
}
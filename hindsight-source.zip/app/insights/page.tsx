import type { Metadata } from "next";
import { InsightsView } from "@/components/insights/insights-view";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const metadata: Metadata = { title: "Insights" };
export const dynamic = "force-dynamic";

export default async function InsightsPage() {
  let data: Awaited<ReturnType<typeof load>> | null = null;
  if (hasSupabase()) {
    try {
      data = await load();
    } catch {
      data = null;
    }
  }
  return <InsightsView data={data} />;
}

async function load() {
  const supabase = createAdminClient();
  const [{ data: counters }, { data: insights }] = await Promise.all([
    supabase.rpc("site_counters"),
    supabase.rpc("global_insights"),
  ]);
  return { counters: counters ?? null, insights: insights ?? null };
}
import { NextResponse } from "next/server";
import { z } from "zod";
import { chatText, hasOpenAI } from "@/lib/ai";

export const dynamic = "force-dynamic";

const bodySchema = z.object({
  q: z.string().trim().min(3).max(400),
  items: z
    .array(z.object({ title: z.string().max(300), excerpt: z.string().max(600), sourceName: z.string().max(80) }))
    .min(1)
    .max(14),
});

const SYSTEM = `You are Hindsight. You are given a person's question and numbered excerpts from real public posts.
Write 3-4 short sentences (max 90 words) on what these people experienced and what to weigh.
Rules:
- Use ONLY the excerpts. Never invent facts, numbers or people.
- Every sentence must end with one or more citations like [1] or [2][4] that refer to the excerpt numbers.
- If excerpts disagree, say so. If they are thin or off-topic, say that plainly.
- No preamble, no bullet points, no medical/legal/financial directives.`;

export async function POST(req: Request) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success || !hasOpenAI()) return NextResponse.json({ summary: null });
  const { q, items } = parsed.data;
  const data = items.map((it, i) => `[${i + 1}] (${it.sourceName}) ${it.title}\n${it.excerpt}`).join("\n\n");
  const summary = await chatText(SYSTEM, `QUESTION: ${q}\n\nEXCERPTS:\n${data}`, 320);
  return NextResponse.json({ summary });
}

import { NextResponse } from "next/server";
import { askSchema } from "@/lib/schemas";
import { RESEARCH_SOURCES, type ResearchSourceKey } from "@/lib/research";
import { researchSource } from "@/lib/research-server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET(req: Request) {
  const url = new URL(req.url);
  const source = url.searchParams.get("source") as ResearchSourceKey | null;
  const parsed = askSchema.safeParse({ q: url.searchParams.get("q") ?? "" });
  if (!parsed.success) return NextResponse.json({ error: "Tell us a little more about what you need advice on." }, { status: 400 });
  if (!source || !RESEARCH_SOURCES.includes(source)) return NextResponse.json({ error: "Unknown source." }, { status: 400 });
  return NextResponse.json(await researchSource(source, parsed.data.q));
}

import { NextResponse } from "next/server";
import { embed } from "@/lib/ai";
import { profileInputSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";
import { normalizeSkills, toVector } from "@/lib/utils";

export const dynamic = "force-dynamic";

// Creates/updates a goal profile. Signed-in users own profile id = auth uid;
// anonymous visitors get a guest profile (id kept in localStorage) so matching works instantly.
export async function POST(req: Request) {
  const parsed = profileInputSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    return NextResponse.json({ error: `Please check "${first?.path.join(".") ?? "your profile"}".` }, { status: 400 });
  }
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const p = parsed.data;
  const supabase = createAdminClient();

  try {
    const user = await getSessionUser();
    const e = await embed(`${p.headline ?? ""}. ${p.goals}`);
    const fields = {
      name: p.name,
      headline: p.headline || null,
      city: p.city || null,
      path: p.path,
      stage: p.stage,
      goals: p.goals,
      skills_have: normalizeSkills(p.skills_have),
      skills_need: normalizeSkills(p.skills_need),
      hours_per_week: p.hours_per_week,
      looking_for: p.looking_for,
      goal_embedding: e ? toVector(e) : null,
      room_code: p.room_code ?? null,
    };

    if (user) {
      const { error } = await supabase.from("profiles").upsert({ id: user.id, ...fields, is_guest: false, is_seed: false }, { onConflict: "id" });
      if (error) throw new Error(error.message);
      return NextResponse.json({ id: user.id, guest: false });
    }

    if (p.guest_id) {
      const { data: existing } = await supabase.from("profiles").select("id, is_guest").eq("id", p.guest_id).maybeSingle();
      if (existing?.is_guest) {
        const { error } = await supabase.from("profiles").update(fields).eq("id", existing.id);
        if (error) throw new Error(error.message);
        return NextResponse.json({ id: existing.id, guest: true });
      }
    }
    const { data: row, error } = await supabase.from("profiles").insert({ ...fields, is_guest: true }).select("id").single();
    if (error || !row) throw new Error(error?.message ?? "insert failed");
    return NextResponse.json({ id: row.id, guest: true });
  } catch (err) {
    console.error("[api/profile]", (err as Error).message);
    return NextResponse.json({ error: "We couldn't save your profile. Please try again." }, { status: 500 });
  }
}

export async function GET(req: Request) {
  const id = new URL(req.url).searchParams.get("id");
  if (!id || !/^[0-9a-f-]{36}$/i.test(id) || !hasSupabase()) return NextResponse.json({ profile: null });
  const { data } = await createAdminClient()
    .from("profiles")
    .select("id, name, headline, city, path, stage, goals, skills_have, skills_need, hours_per_week, looking_for, is_guest")
    .eq("id", id)
    .maybeSingle();
  return NextResponse.json({ profile: data ?? null });
}

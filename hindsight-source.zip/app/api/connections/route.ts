import { NextResponse } from "next/server";
import { connectSchema, connectionUpdateSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

function firstName(name: string) {
  return name.split(/\s+/)[0] ?? name;
}

export async function POST(req: Request) {
  const parsed = connectSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in to connect.", needsAuth: true }, { status: 401 });

  const supabase = createAdminClient();
  try {
    const [{ data: me }, { data: target }] = await Promise.all([
      supabase.from("profiles").select("id, name, is_guest").eq("id", user.id).maybeSingle(),
      supabase.from("profiles").select("id, name, is_seed, is_guest, goals").eq("id", parsed.data.to_user).maybeSingle(),
    ]);
    if (!me) return NextResponse.json({ error: "Create your goal profile first.", needsProfile: true }, { status: 409 });
    if (!target || target.id === me.id) return NextResponse.json({ error: "Person not found." }, { status: 404 });

    // Demo profiles can't reply, so they auto-accept with a friendly opener (clearly marked as demo in the UI).
    const autoAccept = target.is_seed;
    const { data: conn, error } = await supabase
      .from("connections")
      .upsert(
        {
          from_user: me.id,
          to_user: target.id,
          message: parsed.data.message || null,
          match_score: parsed.data.match_score ?? null,
          status: autoAccept ? "accepted" : "pending",
        },
        { onConflict: "from_user,to_user" }
      )
      .select("id, status")
      .single();
    if (error || !conn) throw new Error(error?.message ?? "insert failed");

    if (parsed.data.message) {
      await supabase.from("messages").insert({ connection_id: conn.id, sender: me.id, body: parsed.data.message });
    }
    if (autoAccept) {
      await supabase.from("messages").insert({
        connection_id: conn.id,
        sender: target.id,
        body: `Hey ${firstName(me.name)} — thanks for reaching out! I'm ${firstName(target.name)}. Happy to compare notes. What are you working on this week?`,
      });
    }
    return NextResponse.json({ id: conn.id, status: conn.status });
  } catch (err) {
    console.error("[api/connections]", (err as Error).message);
    return NextResponse.json({ error: "We couldn't send that request. Please try again." }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  const parsed = connectionUpdateSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const supabase = createAdminClient();
  const { data: conn } = await supabase.from("connections").select("id, to_user").eq("id", parsed.data.id).maybeSingle();
  if (!conn || conn.to_user !== user.id) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  const { error } = await supabase.from("connections").update({ status: parsed.data.status }).eq("id", conn.id);
  if (error) return NextResponse.json({ error: "Update failed." }, { status: 500 });
  return NextResponse.json({ ok: true });
}

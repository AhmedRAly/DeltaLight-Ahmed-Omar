import { NextResponse, type NextRequest } from "next/server";
import { runAll } from "@/scripts/ingest/pipeline";

export const maxDuration = 300;
export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get("authorization") !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const summaries = await runAll({ maxProcess: 10 });
    return NextResponse.json({ ok: true, summaries });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Ingestion failed" }, { status: 500 });
  }
}

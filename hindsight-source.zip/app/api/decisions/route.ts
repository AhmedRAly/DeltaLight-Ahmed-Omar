import { NextResponse } from "next/server";
import { embed } from "@/lib/ai";
import { findSimilar } from "@/lib/hindsight";
import { decisionInputSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";
import { toVector } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const parsed = decisionInputSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please complete the decision, options and your prediction." }, { status: 400 });
  }
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const d = parsed.data;
  const options = Array.from(new Set(d.options.filter(Boolean)));
  const chosen = options.includes(d.chosen_option) ? d.chosen_option : options[0];

  try {
    const user = await getSessionUser();
    const e = await embed(`${d.text}\nChose: ${chosen}`);
    const supabase = createAdminClient();
    const { data: row, error } = await supabase
      .from("decisions")
      .insert({
        user_id: user?.id ?? null,
        text: d.text,
        category: d.category,
        options,
        chosen_option: chosen,
        predicted_happiness: d.predicted_happiness,
        predicted_outcome: d.predicted_outcome || null,
        confidence: d.confidence,
        embedding: e ? toVector(e) : null,
        room_code: d.room_code ?? null,
      })
      .select("id")
      .single();
    if (error || !row) throw new Error(error?.message ?? "insert failed");

    const similar = await findSimilar({ text: d.text, embedding: e, decisionCount: 40, storyCount: 1, excludeId: row.id });
    const s = similar.stories[0];
    return NextResponse.json({
      id: row.id,
      peek: {
        similar_n: similar.insights.n,
        would_choose_again_pct: similar.insights.would_choose_again_pct,
        avg_actual: similar.insights.avg_actual,
        forecast_gap: similar.insights.forecast_gap,
        n_seed: similar.insights.n_seed,
        story: s ? { id: s.id, title: s.title, url: s.url, source_id: s.source_id, tldr: s.tldr } : null,
      },
    });
  } catch (err) {
    console.error("[api/decisions]", (err as Error).message);
    return NextResponse.json({ error: "We couldn't save that decision. Please try again." }, { status: 500 });
  }
}

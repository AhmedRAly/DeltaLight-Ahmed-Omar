import { NextResponse } from "next/server";
import { z } from "zod";
import { peekDecision } from "@/lib/hindsight";
import { hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const id = z.string().uuid().safeParse(params.id);
  if (!id.success || !hasSupabase()) return NextResponse.json({ peek: null }, { status: 400 });
  try {
    return NextResponse.json({ peek: await peekDecision(id.data) });
  } catch (err) {
    console.error("[api/peek]", (err as Error).message);
    return NextResponse.json({ peek: null });
  }
}

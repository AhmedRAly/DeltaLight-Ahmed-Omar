import { NextResponse } from "next/server";
import { HORIZONS } from "@/lib/constants";
import { timeTravelSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

// Demo helper: makes the next pending check-in due right now so the full
// predict → check-in → forecast-gap loop can be shown live.
export async function POST(req: Request) {
  const parsed = timeTravelSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success || !hasSupabase()) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const supabase = createAdminClient();
  try {
    const { data: rows } = await supabase
      .from("scheduled_checkins")
      .select("id, horizon, status")
      .eq("decision_id", parsed.data.decision_id);
    const next = (rows ?? [])
      .filter((r) => r.status !== "done")
      .sort((a, b) => HORIZONS.indexOf(a.horizon as (typeof HORIZONS)[number]) - HORIZONS.indexOf(b.horizon as (typeof HORIZONS)[number]))[0];
    if (!next) return NextResponse.json({ horizon: null, message: "All check-ins are complete." });
    const { error } = await supabase
      .from("scheduled_checkins")
      .update({ status: "due", due_at: new Date().toISOString() })
      .eq("id", next.id);
    if (error) throw new Error(error.message);
    return NextResponse.json({ horizon: next.horizon });
  } catch (err) {
    console.error("[api/time-travel]", (err as Error).message);
    return NextResponse.json({ error: "Time travel failed. Try again." }, { status: 500 });
  }
}

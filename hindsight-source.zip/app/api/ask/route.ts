import { NextResponse } from "next/server";
import { findSimilar } from "@/lib/hindsight";
import { askSchema } from "@/lib/schemas";
import { hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const parsed = askSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Tell us a little more about your decision." }, { status: 400 });
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  try {
    const result = await findSimilar({ text: parsed.data.q });
    return NextResponse.json({
      ...result,
      matches: result.matches.slice(0, 8).map((m) => ({
        id: m.id,
        text: m.text,
        category: m.category,
        chosen_option: m.chosen_option,
        predicted_happiness: m.predicted_happiness,
        is_seed: m.is_seed,
        similarity: m.similarity,
        latest_horizon: m.latest_horizon,
        latest_actual_happiness: m.latest_actual_happiness,
        latest_would_choose_again: m.latest_would_choose_again,
        latest_surprise: m.latest_surprise,
      })),
    });
  } catch (err) {
    console.error("[api/ask]", (err as Error).message);
    return NextResponse.json({ error: "Hindsight is catching its breath. Try again in a moment." }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { explainMatch } from "@/lib/partners";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const id = z.string().uuid().safeParse(sp.get("profile_id"));
  if (!id.success || !hasSupabase()) return NextResponse.json({ matches: [] }, { status: 400 });
  const supabase = createAdminClient();
  try {
    const [{ data: me }, { data, error }] = await Promise.all([
      supabase.from("profiles").select("path, stage").eq("id", id.data).maybeSingle(),
      supabase.rpc("match_partners", { p_user_id: id.data, match_count: 24 }),
    ]);
    if (error) throw new Error(error.message);
    const matches = (data ?? [])
      .filter((m) => !sp.get("seed_only") || m.is_seed)
      .map((m) => ({ ...m, explanation: explainMatch(m, me) }));
    return NextResponse.json({ matches });
  } catch (err) {
    console.error("[api/partners/matches]", (err as Error).message);
    return NextResponse.json({ matches: [], error: "Matching is temporarily unavailable." }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { embed } from "@/lib/ai";
import { explainMatch } from "@/lib/partners";
import { quickProfileSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { normalizeSkills, toVector } from "@/lib/utils";

export const dynamic = "force-dynamic";

// Room-mode quick profile: a guest profile tagged with the room code, matched instantly.
export async function POST(req: Request) {
  const parsed = quickProfileSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Add your name, a goal and at least one skill." }, { status: 400 });
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const q = parsed.data;
  const supabase = createAdminClient();
  try {
    const e = await embed(q.goals);
    const { data: row, error } = await supabase
      .from("profiles")
      .insert({
        name: q.name,
        path: q.path,
        stage: q.path === "corporate" ? "employed" : "building",
        goals: q.goals,
        skills_have: normalizeSkills(q.skills_have),
        skills_need: normalizeSkills(q.skills_need),
        hours_per_week: 10,
        looking_for: ["network", "accountability"],
        goal_embedding: e ? toVector(e) : null,
        is_guest: true,
        room_code: q.room_code ?? null,
      })
      .select("id, path, stage")
      .single();
    if (error || !row) throw new Error(error?.message ?? "insert failed");
    const { data: ms } = await supabase.rpc("match_partners", { p_user_id: row.id, match_count: 3 });
    return NextResponse.json({
      id: row.id,
      matches: (ms ?? []).map((m) => ({ ...m, explanation: explainMatch(m, row) })),
    });
  } catch (err) {
    console.error("[api/partners/quick]", (err as Error).message);
    return NextResponse.json({ error: "Couldn't create your profile. Try again." }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { addSearch, recentSearches } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const bodySchema = z.object({ q: z.string().trim().min(3).max(400), count: z.number().int().min(0).max(1000) });

/** Recent distinct searches for the signed-in user. Anonymous visitors are never recorded. */
export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ items: [], signedIn: false });
  return NextResponse.json({ items: recentSearches(user.id), signedIn: true });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ saved: false });
  const parsed = bodySchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ saved: false }, { status: 400 });
  addSearch(user.id, parsed.data.q, parsed.data.count);
  return NextResponse.json({ saved: true });
}

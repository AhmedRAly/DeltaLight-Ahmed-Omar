import { NextResponse, type NextRequest } from "next/server";
import { ingestRequestSchema } from "@/lib/schemas";
import { runSource, SOURCE_IDS, type RunSummary } from "@/scripts/ingest/pipeline";

export const maxDuration = 300;
export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function authorized(req: NextRequest): boolean {
  const token = process.env.ADMIN_TOKEN;
  if (!token) return true;
  return req.headers.get("x-admin-token") === token;
}

export async function POST(req: NextRequest) {
  if (!authorized(req)) {
    return NextResponse.json({ error: "Unauthorized: a valid x-admin-token header is required" }, { status: 401 });
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const parsed = ingestRequestSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request: expected { source: string, max_process?: number }" }, { status: 400 });
  }
  const { source, max_process } = parsed.data;
  if (source !== "all" && !SOURCE_IDS.includes(source)) {
    return NextResponse.json({ error: `Unknown source: ${source}` }, { status: 400 });
  }

  try {
    const summaries: RunSummary[] = [];
    if (source === "all") {
      for (const id of SOURCE_IDS) {
        summaries.push(await runSource(id, { maxProcess: max_process ?? 8 }));
      }
    } else {
      summaries.push(await runSource(source, { maxProcess: max_process ?? 12 }));
    }
    return NextResponse.json({ summaries });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Ingestion failed" }, { status: 500 });
  }
}

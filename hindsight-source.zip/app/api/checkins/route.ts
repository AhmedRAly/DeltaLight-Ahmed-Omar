import { NextResponse } from "next/server";
import { chatJSON } from "@/lib/ai";
import { checkinInputSchema, surpriseTagsSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

const TAG_SYSTEM = `Extract 1-3 short lowercase tags (1-3 words each) naming the THEMES of the surprise someone describes after making a life decision.
Examples of good tags: "loneliness", "cash flow", "more meetings", "identity", "freedom", "imposter syndrome", "slower sales", "family support", "health".
Only use themes present in the text. Return JSON: {"tags": string[]}`;

export async function POST(req: Request) {
  const parsed = checkinInputSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Please complete the check-in." }, { status: 400 });
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const c = parsed.data;
  const supabase = createAdminClient();

  try {
    const { data: sched } = await supabase
      .from("scheduled_checkins")
      .select("status, due_at")
      .eq("decision_id", c.decision_id)
      .eq("horizon", c.horizon)
      .maybeSingle();
    if (!sched) return NextResponse.json({ error: "Check-in not found." }, { status: 404 });
    if (sched.status === "pending" && new Date(sched.due_at).getTime() > Date.now()) {
      return NextResponse.json({ error: "This check-in isn't due yet." }, { status: 409 });
    }

    let tags: string[] = [];
    if (c.biggest_surprise && c.biggest_surprise.length > 3) {
      const out = await chatJSON({ system: TAG_SYSTEM, user: c.biggest_surprise, schema: surpriseTagsSchema, maxTokens: 80 });
      tags = (out?.tags ?? []).map((t) => t.toLowerCase().trim()).filter(Boolean).slice(0, 3);
    }

    const { error } = await supabase.from("checkins").upsert(
      {
        decision_id: c.decision_id,
        horizon: c.horizon,
        actual_happiness: c.actual_happiness,
        regret: c.regret,
        would_choose_again: c.would_choose_again,
        biggest_surprise: c.biggest_surprise || null,
        surprise_tags: tags,
      },
      { onConflict: "decision_id,horizon" }
    );
    if (error) throw new Error(error.message);
    await supabase.from("scheduled_checkins").update({ status: "done" }).eq("decision_id", c.decision_id).eq("horizon", c.horizon);
    return NextResponse.json({ ok: true, tags });
  } catch (err) {
    console.error("[api/checkins]", (err as Error).message);
    return NextResponse.json({ error: "We couldn't save your check-in. Please try again." }, { status: 500 });
  }
}

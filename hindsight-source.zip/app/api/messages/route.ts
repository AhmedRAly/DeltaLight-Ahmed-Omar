import { NextResponse } from "next/server";
import { messageSchema } from "@/lib/schemas";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const parsed = messageSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Message can't be empty." }, { status: 400 });
  if (!hasSupabase()) return NextResponse.json({ error: "The database is not configured yet." }, { status: 503 });
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const supabase = createAdminClient();
  const { data: conn } = await supabase
    .from("connections")
    .select("id, from_user, to_user, status")
    .eq("id", parsed.data.connection_id)
    .maybeSingle();
  if (!conn || (conn.from_user !== user.id && conn.to_user !== user.id)) {
    return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  }
  if (conn.status !== "accepted") return NextResponse.json({ error: "Chat opens once the request is accepted." }, { status: 409 });
  const { data, error } = await supabase
    .from("messages")
    .insert({ connection_id: conn.id, sender: user.id, body: parsed.data.body })
    .select("id, connection_id, sender, body, created_at")
    .single();
  if (error) return NextResponse.json({ error: "Couldn't send. Try again." }, { status: 500 });
  return NextResponse.json({ message: data });
}

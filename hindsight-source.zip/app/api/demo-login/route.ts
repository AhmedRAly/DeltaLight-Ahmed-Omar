import { NextResponse } from "next/server";
import { z } from "zod";
import { DEMO_COOKIE, DEMO_USERS, demoEnabled, findDemoUser } from "@/lib/demo";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

const schema = z.object({ id: z.string().uuid().optional(), email: z.string().email().max(200).optional() }).refine((v) => v.id || v.email);

export async function POST(req: Request) {
  if (!demoEnabled()) return NextResponse.json({ error: "Demo sign-in is off." }, { status: 403 });
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  // Fake login: a known persona email picks that persona, any other email gets the first one.
  const user = parsed.success
    ? findDemoUser(parsed.data.id) ?? DEMO_USERS.find((u) => u.email === parsed.data.email?.toLowerCase()) ?? DEMO_USERS[0]
    : null;
  if (!user) return NextResponse.json({ error: "Unknown demo user." }, { status: 400 });

  // Best effort: give the persona a Business profile so matching and connections work right away.
  if (hasSupabase()) {
    try {
      await createAdminClient()
        .from("profiles")
        .upsert(
          {
            id: user.id,
            name: user.name,
            headline: user.headline,
            city: user.profile.city,
            path: user.profile.path,
            stage: user.profile.stage,
            goals: user.profile.goals,
            skills_have: user.profile.skills_have,
            skills_need: user.profile.skills_need,
            hours_per_week: user.profile.hours_per_week,
            looking_for: user.profile.looking_for,
            is_seed: false,
            is_guest: false,
          },
          { onConflict: "id" }
        );
    } catch {
      // The app works without a profile row.
    }
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set(DEMO_COOKIE, user.id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7 });
  return res;
}

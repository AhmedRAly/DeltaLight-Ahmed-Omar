import { NextResponse } from "next/server";
import { z } from "zod";
import { CATEGORIES } from "@/lib/constants";
import { getStanding, MAX_QUESTIONS_PER_DAY } from "@/lib/community";
import { addQuestion, countToday } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const schema = z.object({
  title: z.string().trim().min(10, "Make the question at least 10 characters.").max(200),
  body: z.string().trim().max(3000).default(""),
  category: z.enum(CATEGORIES).default("other"),
});

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in to ask a question." }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check your question." }, { status: 400 });
  if (getStanding(user.id).answers < 1) return NextResponse.json({ error: "Answer one question first, then you can ask yours." }, { status: 403 });
  if (countToday(user.id, "questions") >= MAX_QUESTIONS_PER_DAY)
    return NextResponse.json({ error: `You can post ${MAX_QUESTIONS_PER_DAY} questions per day. Try again tomorrow.` }, { status: 429 });
  const q = addQuestion({ id: user.id, name: user.name ?? "Member" }, parsed.data);
  return NextResponse.json({ id: q.id });
}

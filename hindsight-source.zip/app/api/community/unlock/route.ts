import { NextResponse } from "next/server";
import { z } from "zod";
import { getAccess } from "@/lib/community";
import { addUnlock, getQuestion } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const schema = z.object({ question_id: z.string().min(3).max(80) });

/** Spend one unlock to read the answers to a question you did not answer. */
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "Bad request." }, { status: 400 });
  const q = getQuestion(parsed.data.question_id);
  if (!q) return NextResponse.json({ error: "That question no longer exists." }, { status: 404 });
  const { state } = getAccess(user.id, q);
  if (state === "author" || state === "answered" || state === "unlocked") return NextResponse.json({ ok: true, charged: false });
  if (state !== "can-unlock") return NextResponse.json({ error: "Answer a question to earn more unlocks." }, { status: 402 });
  addUnlock(user.id, q.id);
  return NextResponse.json({ ok: true, charged: true });
}

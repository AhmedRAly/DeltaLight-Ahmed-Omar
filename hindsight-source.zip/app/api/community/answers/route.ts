import { NextResponse } from "next/server";
import { z } from "zod";
import { MAX_ANSWERS_PER_DAY } from "@/lib/community";
import { addAnswer, countToday, getQuestion, userActivity } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const schema = z.object({
  question_id: z.string().min(3).max(80),
  body: z.string().trim().min(20, "Write at least 20 characters so it is actually helpful.").max(3000),
});

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Sign in to answer." }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check your answer." }, { status: 400 });
  const q = getQuestion(parsed.data.question_id);
  if (!q) return NextResponse.json({ error: "That question no longer exists." }, { status: 404 });
  if (q.authorId === user.id) return NextResponse.json({ error: "You can't answer your own question." }, { status: 400 });
  if (userActivity(user.id).answered.has(q.id)) return NextResponse.json({ error: "You already answered this question." }, { status: 409 });
  if (countToday(user.id, "answers") >= MAX_ANSWERS_PER_DAY) return NextResponse.json({ error: "You've reached today's answer limit. Come back tomorrow." }, { status: 429 });
  addAnswer({ id: user.id, name: user.name ?? "Member" }, q.id, parsed.data.body);
  return NextResponse.json({ ok: true });
}

import { VoidHero } from "@/components/home/void-hero";

export default function HomePage() {
  return <VoidHero />;
}

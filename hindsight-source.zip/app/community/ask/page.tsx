import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ChevronLeft, RefreshCw } from "lucide-react";
import { AskForm } from "@/components/community/forms";
import { getStanding, preview, TOPIC_STYLE } from "@/lib/community";
import { pickerQuestions } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";
import { cn, timeAgo } from "@/lib/utils";

export const metadata: Metadata = { title: "Ask a question" };
export const dynamic = "force-dynamic";

export default async function AskCommunityPage({ searchParams }: { searchParams: { title?: string; round?: string } }) {
  const user = await getSessionUser();
  const title = typeof searchParams.title === "string" ? searchParams.title.slice(0, 200) : "";
  const round = Math.max(0, Math.min(500, Number.parseInt(searchParams.round ?? "0", 10) || 0));
  const titleQs = title ? `&title=${encodeURIComponent(title)}` : "";
  const standing = user ? getStanding(user.id) : null;
  const mustAnswer = Boolean(user && standing && standing.answers < 1);
  const picks = mustAnswer ? pickerQuestions(user!.id, round) : [];

  return (
    <div className="container max-w-3xl py-10 md:py-14">
      <Link href="/community" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Community
      </Link>

      {!user && (
        <>
          <h1 className="mt-6 font-serif text-4xl italic tracking-tight">Ask the community</h1>
          <div className="mt-8 rounded-2xl border bg-card/70 p-6">
            <p className="text-lg">Sign in to post a question.</p>
            <p className="mt-1 text-sm text-muted-foreground">Sign in to continue.</p>
            <Link
              href={`/login?next=${encodeURIComponent(`/community/ask${title ? `?title=${encodeURIComponent(title)}` : ""}`)}`}
              className="mt-4 inline-flex rounded-xl bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:brightness-110"
            >
              Sign in
            </Link>
          </div>
        </>
      )}

      {user && mustAnswer && (
        <>
          <p className="mt-6 text-xs uppercase tracking-[0.2em] text-primary">Step 1 of 2</p>
          <h1 className="mt-2 font-serif text-4xl italic leading-tight tracking-tight">Before you ask, help someone else.</h1>
          <p className="mt-3 max-w-xl text-muted-foreground">
            Pick one question below that fits your experience or skills, and answer it. You&apos;ll then be able to post your own, and you&apos;ll earn unlocks to read other threads.
          </p>
          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {picks.map((q) => (
              <li key={q.id}>
                <Link
                  href={`/community/${q.id}?from=ask${titleQs}`}
                  className="group flex h-full flex-col rounded-2xl border bg-card/70 p-4 transition hover:-translate-y-0.5 hover:border-primary/40"
                >
                  <span className={cn("w-fit rounded-full border px-2 py-0.5 text-[11px] capitalize", TOPIC_STYLE[q.category])}>{q.category}</span>
                  <h2 className="mt-3 text-[15px] font-medium leading-snug">{q.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-foreground/60">{preview(q.body, 105)}</p>
                  <div className="mt-auto flex items-center justify-between pt-4 text-xs text-muted-foreground">
                    <span>
                      {q.authorName} · {timeAgo(q.createdAt)}
                    </span>
                    <span className="inline-flex items-center gap-1 text-primary opacity-0 transition group-hover:opacity-100">
                      Answer <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex justify-center">
            <Link
              href={`/community/ask?round=${round + 1}${titleQs}`}
              scroll={false}
              className="inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Show me different questions
            </Link>
          </div>
        </>
      )}

      {user && !mustAnswer && (
        <>
          <h1 className="mt-6 font-serif text-4xl italic tracking-tight">Ask the community</h1>
          <p className="mt-2 text-muted-foreground">Real people answer. The more context you give, the better the answers.</p>
          <div className="mt-8">
            <AskForm initialTitle={title} />
          </div>
          <p className="mt-6 text-sm text-muted-foreground">
            Want more unlocks?{" "}
            <Link href="/community?sort=unanswered" className="text-primary hover:underline">
              Answer another question
            </Link>
            .
          </p>
        </>
      )}
    </div>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, EyeOff, MessageSquarePlus } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { CATEGORIES } from "@/lib/constants";
import { CREDITS_PER_ANSWER, getStanding, TOPIC_STYLE } from "@/lib/community";
import { listQuestions, userActivity, type Sort } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";
import { cn, timeAgo } from "@/lib/utils";

export const metadata: Metadata = { title: "Community" };
export const dynamic = "force-dynamic";

const SORTS: { id: Sort; label: string }[] = [
  { id: "new", label: "Newest" },
  { id: "unanswered", label: "Needs an answer" },
  { id: "popular", label: "Most answered" },
];

export default async function CommunityPage({ searchParams }: { searchParams: { sort?: string; topic?: string } }) {
  const sort = (SORTS.find((s) => s.id === searchParams.sort)?.id ?? "new") as Sort;
  const topic = (CATEGORIES as readonly string[]).includes(searchParams.topic ?? "") ? searchParams.topic! : "";
  const user = await getSessionUser();
  const questions = listQuestions({ sort, topic });
  const standing = user ? getStanding(user.id) : null;
  const seen = user ? new Set([...Array.from(userActivity(user.id).answered), ...Array.from(userActivity(user.id).unlocked)]) : new Set<string>();

  const href = (patch: { sort?: string; topic?: string }) => {
    const p = new URLSearchParams();
    const s = patch.sort ?? (sort !== "new" ? sort : "");
    const t = patch.topic ?? topic;
    if (s) p.set("sort", s);
    if (t) p.set("topic", t);
    const q = p.toString();
    return q ? `/community?${q}` : "/community";
  };

  return (
    <div className="container max-w-4xl py-10 md:py-14">
      <header className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
        <div className="max-w-xl">
          <h1 className="text-3xl font-semibold leading-tight tracking-tight md:text-4xl">Community answers</h1>
          <p className="mt-2 text-muted-foreground">Real advice from people who&apos;ve been there. Answer one question to unlock the rest.</p>
        </div>
        <Link href="/community/ask" className="inline-flex h-11 shrink-0 items-center gap-2 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground hover:brightness-110">
          <MessageSquarePlus className="h-4 w-4" /> Ask a question
        </Link>
      </header>

      <div className="mt-8 flex flex-col gap-4 rounded-2xl border border-primary/25 bg-primary/[0.06] p-5 sm:flex-row sm:items-center">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-card shadow-sm">
          <EyeOff className="h-6 w-6 text-primary" />
        </div>
        <div className="flex-1 text-sm">
          {standing ? (
            <>
              <p className="text-base font-semibold">
                {standing.credits} unlock{standing.credits === 1 ? "" : "s"} available
              </p>
              <p className="mt-0.5 text-muted-foreground">
                Threads with a crossed-out eye are hidden. Each answer you write earns {CREDITS_PER_ANSWER} unlocks. You&apos;ve written {standing.answers}.
              </p>
            </>
          ) : (
            <p className="text-muted-foreground">
              <Link href="/login?next=/community" className="font-semibold text-primary hover:underline">Sign in</Link> to ask and answer. You earn {CREDITS_PER_ANSWER} unlocks for every answer you write.
            </p>
          )}
        </div>
        <Link href="/community?sort=unanswered" className="inline-flex h-10 items-center justify-center rounded-full border border-primary/40 bg-card px-5 text-sm font-semibold text-primary hover:bg-primary/10">
          Answer to earn
        </Link>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1 rounded-full border bg-card p-0.5 text-xs">
          {SORTS.map((s) => (
            <Link key={s.id} href={href({ sort: s.id === "new" ? "" : s.id })} scroll={false} className={cn("rounded-full px-3 py-1.5 transition", sort === s.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>
              {s.label}
            </Link>
          ))}
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Link href={href({ topic: "" })} scroll={false} className={cn("rounded-full border px-2.5 py-1 text-xs", !topic ? "border-primary/50 bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground")}>
            All
          </Link>
          {CATEGORIES.map((c) => (
            <Link key={c} href={href({ topic: c })} scroll={false} className={cn("rounded-full border px-2.5 py-1 text-xs capitalize", topic === c ? "border-primary/50 bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground")}>
              {c}
            </Link>
          ))}
        </div>
      </div>

      {questions.length === 0 ? (
        <div className="mt-8 rounded-2xl border bg-card p-10 text-center text-muted-foreground">
          <p className="text-foreground">No questions here yet.</p>
          <p className="mt-1 text-sm">Be the first to ask one.</p>
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {questions.map((q) => (
            <li key={q.id}>
              <Link href={`/community/${q.id}`} className="group block rounded-2xl border bg-card p-5 shadow-sm transition hover:border-primary/50 hover:shadow-md">
                <div className="flex items-start gap-4">
                  <Avatar name={q.authorName} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className={cn("rounded-full border px-2 py-0.5 font-medium capitalize", TOPIC_STYLE[q.category])}>{q.category}</span>
                      {q.answerCount === 0 && <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 font-medium text-primary">needs an answer</span>}
                      <span className="text-muted-foreground">{q.authorName} · {timeAgo(q.createdAt)}</span>
                    </div>
                    <h2 className="mt-2 text-lg font-semibold leading-snug tracking-tight group-hover:text-primary">{q.title}</h2>
                    {q.body && <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{q.body}</p>}
                    <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
                      {user && !seen.has(q.id) && q.answerCount > 0 && q.authorId !== user.id ? (
                        <span className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5">
                          <EyeOff className="h-3.5 w-3.5 text-red-600" />
                          <span className="locked-lines flex flex-col gap-1" aria-hidden>
                            <span style={{ width: 90, height: 6 }} />
                          </span>
                          {q.answerCount} hidden
                        </span>
                      ) : (
                        <span className="rounded-full bg-muted px-3 py-1.5">{q.answerCount} answer{q.answerCount === 1 ? "" : "s"}</span>
                      )}
                      <ArrowRight className="ml-auto h-4 w-4 transition group-hover:translate-x-0.5 group-hover:text-primary" />
                    </div>
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CheckCircle2, ChevronLeft, MessageCircle, ShieldCheck } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { LockedBox } from "@/components/community/locked-box";
import { AnswerForm, UnlockButton } from "@/components/community/forms";
import { canSeeAnswers, CREDITS_PER_ANSWER, getAccess, TOPIC_STYLE } from "@/lib/community";
import { getQuestion, listAnswers } from "@/lib/community-store";
import { getSessionUser } from "@/lib/supabase/server";
import { cn, timeAgo } from "@/lib/utils";

export const metadata: Metadata = { title: "Question" };
export const dynamic = "force-dynamic";

export default async function QuestionPage({ params, searchParams }: { params: { id: string }; searchParams: { from?: string; title?: string } }) {
  const q = getQuestion(params.id);
  if (!q) notFound();

  const user = await getSessionUser();
  const { state, standing } = getAccess(user?.id ?? null, q);
  const visible = canSeeAnswers(state);
  const answers = visible ? listAnswers(q.id) : [];
  const loginHref = `/login?next=${encodeURIComponent(`/community/${q.id}`)}`;
  const canAnswer = state !== "signed-out" && state !== "author" && state !== "answered";
  const fromAsk = searchParams.from === "ask";
  const askHref = `/community/ask${searchParams.title ? `?title=${encodeURIComponent(searchParams.title)}` : ""}`;

  return (
    <div className="container max-w-3xl py-10 md:py-14">
      <Link href={fromAsk ? askHref : "/community"} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> {fromAsk ? "Pick a different question" : "Community"}
      </Link>

      {fromAsk && state === "answered" && (
        <div className="mt-6 flex flex-col items-start justify-between gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4 sm:flex-row sm:items-center">
          <p className="flex items-center gap-2 text-sm text-primary">
            <CheckCircle2 className="h-4 w-4" /> Thanks for answering. You earned {CREDITS_PER_ANSWER} unlocks.
          </p>
          <Link href={askHref} className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:brightness-110">
            Now ask your question <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      )}

      <article className="mt-6">
        <span className={cn("rounded-full border px-2 py-0.5 text-xs capitalize", TOPIC_STYLE[q.category])}>{q.category}</span>
        <h1 className="mt-3 text-3xl font-semibold leading-tight tracking-tight md:text-4xl">{q.title}</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          {q.authorName} · {timeAgo(q.createdAt)} · {q.answerCount} answer{q.answerCount === 1 ? "" : "s"}
        </p>
        {q.body && <p className="mt-5 whitespace-pre-wrap text-[16px] leading-relaxed text-foreground/85">{q.body}</p>}
      </article>

      {canAnswer && (
        <section id="your-answer" className="mt-10 scroll-mt-24 rounded-2xl border border-primary/25 bg-card p-5 shadow-sm md:p-6">
          <h2 className="text-lg font-semibold tracking-tight">Your answer</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {visible ? `Add your voice. Each answer earns you ${CREDITS_PER_ANSWER} unlocks.` : `Answer to unlock the ${q.answerCount} existing answer${q.answerCount === 1 ? "" : "s"} and earn ${CREDITS_PER_ANSWER} unlocks.`}
          </p>
          <div className="mt-4">
            <AnswerForm questionId={q.id} locked={!visible} />
          </div>
        </section>
      )}

      <section className="mt-10">
        {visible ? (
          <>
            <h2 className="flex items-center gap-2 text-lg font-semibold tracking-tight">
              <MessageCircle className="h-5 w-5 text-primary" /> Answers <span className="text-muted-foreground">{answers.length}</span>
            </h2>
            {answers.length === 0 ? (
              <p className="mt-4 rounded-2xl border bg-card p-6 text-muted-foreground">No answers yet. Check back soon.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {answers.map((a) => (
                  <li key={a.id} className="rounded-2xl border bg-card p-5 shadow-sm">
                    <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-foreground/90">{a.body}</p>
                    <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                      <Avatar name={a.authorName} size={22} /> {a.authorName} · {timeAgo(a.createdAt)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </>
        ) : (
          <LockedBox count={q.answerCount} state={state} standing={standing} questionId={q.id} loginHref={loginHref} />
        )}
      </section>

      <p className="mt-10 flex items-center gap-2 text-xs text-muted-foreground">
        <ShieldCheck className="h-4 w-4" /> Peer opinions, not professional advice.
      </p>
    </div>
  );
}

import type { Metadata } from "next";
import { EyeOff, MessageSquare, ShieldCheck, Unlock } from "lucide-react";
import { FakeLogin } from "@/components/site/fake-login";
import { LoginForm } from "@/components/site/login-form";
import { DEMO_USERS, demoEnabled } from "@/lib/demo";

export const metadata: Metadata = { title: "Sign in" };

const PERKS = [
  { icon: MessageSquare, title: "Answer a question", text: "Share what you'd do, or what happened when you faced it." },
  { icon: Unlock, title: "Unlock the answers", text: "Every answer you give earns unlocks to read other threads." },
  { icon: ShieldCheck, title: "Stay anonymous", text: "Only a display name is ever shown. No employers, no details." },
];

export default function LoginPage({ searchParams }: { searchParams: { next?: string; error?: string } }) {
  const next = typeof searchParams.next === "string" && searchParams.next.startsWith("/") && !searchParams.next.startsWith("//") ? searchParams.next : "/";
  const accounts = demoEnabled();
  return (
    <div className="container grid max-w-5xl items-center gap-12 py-12 md:grid-cols-[1.1fr_1fr] md:py-20">
      <div>
        <p className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          <EyeOff className="h-3.5 w-3.5" /> Give one answer, get them all
        </p>
        <h1 className="mt-5 text-4xl font-semibold leading-[1.1] tracking-tight md:text-5xl">See what people really say about the big decisions.</h1>
        <p className="mt-4 max-w-lg text-lg text-muted-foreground">
          Honest advice from people who&apos;ve already been there. It&apos;s hidden until you add your own. That&apos;s how everyone gets real answers.
        </p>
        <ul className="mt-8 space-y-5">
          {PERKS.map((p, i) => (
            <li key={p.title} className="flex gap-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <p.icon className="h-5 w-5" />
              </span>
              <span>
                <span className="block font-medium">{i + 1}. {p.title}</span>
                <span className="block text-sm text-muted-foreground">{p.text}</span>
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-2xl border bg-card p-6 shadow-sm md:p-8">
        <h2 className="text-2xl font-semibold tracking-tight">Welcome back</h2>
        <p className="mt-1 text-sm text-muted-foreground">Sign in to read, ask and answer.</p>
        {searchParams.error && <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-700">That link expired or was already used. Request a new one.</p>}
        <div className="mt-6">
          {accounts ? (
            <FakeLogin users={DEMO_USERS.map(({ id, name, headline }) => ({ id, name, headline }))} next={next} />
          ) : (
            <LoginForm next={next} />
          )}
        </div>
      </div>
    </div>
  );
}

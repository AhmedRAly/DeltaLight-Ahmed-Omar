import type { Metadata } from "next";
import { LogForm } from "@/components/log/log-form";

export const metadata: Metadata = { title: "Log a decision" };

export default function LogPage({ searchParams }: { searchParams: { text?: string; room?: string } }) {
  const text = typeof searchParams.text === "string" ? searchParams.text.slice(0, 600) : "";
  const room = typeof searchParams.room === "string" ? searchParams.room.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) : "";
  return (
    <div className="container max-w-2xl py-10 md:py-14">
      {room && (
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm text-primary">
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" /> Live room {room}
        </div>
      )}
      <h1 className="text-4xl font-semibold tracking-tight md:text-5xl">Log a decision.</h1>
      <p className="mt-3 text-lg text-muted-foreground">
        Write down your prediction now. Hindsight checks back later — the gap between the two is the most honest data on earth.
      </p>
      <div className="mt-10">
        <LogForm initialText={text} room={room || undefined} />
      </div>
    </div>
  );
}

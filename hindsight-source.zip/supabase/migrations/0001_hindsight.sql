-- =====================================================================
-- Hindsight — full schema. Paste into the Supabase SQL editor and run.
-- Safe to re-run: uses IF NOT EXISTS / CREATE OR REPLACE where possible.
-- =====================================================================

create extension if not exists vector with schema extensions;
create extension if not exists pg_trgm with schema extensions;
create extension if not exists pg_cron;
create extension if not exists pgcrypto with schema extensions;

set search_path = public, extensions;
  
-- ---------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------

-- Goal profiles. For signed-in users id = auth.uid(). Demo/guest profiles
-- (seed + room QR flow) get a random id and are flagged accordingly.
create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  headline text,
  avatar_url text,
  city text,
  path text not null default 'business' check (path in ('business','corporate','both')),
  stage text not null default 'idea' check (stage in ('idea','building','launched','employed','switching')),
  goals text not null default '',
  skills_have text[] not null default '{}',
  skills_need text[] not null default '{}',
  hours_per_week int not null default 10 check (hours_per_week between 0 and 100),
  looking_for text[] not null default '{}',
  goal_embedding vector(1536),
  is_seed boolean not null default false,
  is_guest boolean not null default false,
  room_code text,
  created_at timestamptz not null default now()
);

create table if not exists public.decisions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid null,
  text text not null check (char_length(text) between 3 and 600),
  category text not null default 'other'
    check (category in ('business','career','money','education','relationships','location','other')),
  options jsonb not null default '[]'::jsonb,
  chosen_option text,
  predicted_happiness int not null check (predicted_happiness between 1 and 10),
  predicted_outcome text,
  confidence int not null default 5 check (confidence between 1 and 10),
  embedding vector(1536),
  is_seed boolean not null default false,
  room_code text,
  created_at timestamptz not null default now(),
  fts tsvector generated always as (
    to_tsvector('english', coalesce(text,'') || ' ' || coalesce(chosen_option,'') || ' ' || coalesce(predicted_outcome,''))
  ) stored
);

create table if not exists public.checkins (
  id uuid primary key default gen_random_uuid(),
  decision_id uuid not null references public.decisions(id) on delete cascade,
  horizon text not null check (horizon in ('1w','1m','6m','1y')),
  actual_happiness int not null check (actual_happiness between 1 and 10),
  regret int not null check (regret between 0 and 10),
  would_choose_again boolean not null,
  biggest_surprise text,
  surprise_tags text[] not null default '{}',
  checkin_at timestamptz not null default now(),
  unique (decision_id, horizon)
);

create table if not exists public.scheduled_checkins (
  id uuid primary key default gen_random_uuid(),
  decision_id uuid not null references public.decisions(id) on delete cascade,
  due_at timestamptz not null,
  horizon text not null check (horizon in ('1w','1m','6m','1y')),
  status text not null default 'pending' check (status in ('pending','due','done')),
  unique (decision_id, horizon)
);

create table if not exists public.sources (
  id text primary key,
  name text not null,
  type text not null,
  base_url text not null,
  last_synced_at timestamptz,
  items_count int not null default 0,
  last_status text,
  last_error text
);

create table if not exists public.raw_items (
  id uuid primary key default gen_random_uuid(),
  source_id text not null references public.sources(id) on delete cascade,
  external_id text not null unique,
  url text not null,
  title text not null,
  body text not null default '',
  author_handle text,
  posted_at timestamptz,
  score int not null default 0,
  fetched_at timestamptz not null default now(),
  processed boolean not null default false,
  is_story boolean,
  process_note text
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  raw_item_id uuid unique references public.raw_items(id) on delete cascade,
  source_id text not null references public.sources(id) on delete cascade,
  url text not null,
  title text not null,
  category text not null default 'other'
    check (category in ('business','career','money','education','relationships','location','other')),
  path text not null default 'business' check (path in ('business','corporate')),
  decision_text text not null,
  what_they_chose text,
  starting_point text,
  outcome text,
  outcome_type text not null default 'ongoing' check (outcome_type in ('success','mixed','failure','ongoing')),
  revenue_or_salary_mentioned text,
  timeline text,
  lessons text[] not null default '{}',
  surprise_tags text[] not null default '{}',
  tldr text not null,
  read_time_min int not null default 3,
  author_handle text,
  embedding vector(1536),
  created_at timestamptz not null default now(),
  fts tsvector generated always as (
    to_tsvector('english',
      coalesce(title,'') || ' ' || coalesce(tldr,'') || ' ' || coalesce(decision_text,'') || ' ' ||
      coalesce(what_they_chose,'') || ' ' || coalesce(outcome,''))
  ) stored
);

create table if not exists public.connections (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  message text,
  match_score float,
  created_at timestamptz not null default now(),
  unique (from_user, to_user),
  check (from_user <> to_user)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references public.connections(id) on delete cascade,
  sender uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

-- Live ingestion progress (drives /admin/ingest via Realtime)
create table if not exists public.ingest_runs (
  id uuid primary key default gen_random_uuid(),
  source_id text not null references public.sources(id) on delete cascade,
  status text not null default 'running' check (status in ('running','done','error','skipped')),
  fetched int not null default 0,
  new_items int not null default 0,
  processed int not null default 0,
  stories_created int not null default 0,
  message text,
  started_at timestamptz not null default now(),
  finished_at timestamptz
);

-- Goal-based circles (members are assigned by embedding similarity)
create table if not exists public.circles (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null,
  path text not null default 'both' check (path in ('business','corporate','both')),
  keywords text[] not null default '{}',
  embedding vector(1536)
);

-- ---------------------------------------------------------------------
-- Indexes
-- ---------------------------------------------------------------------
create index if not exists decisions_embedding_hnsw on public.decisions using hnsw (embedding vector_cosine_ops);
create index if not exists stories_embedding_hnsw on public.stories using hnsw (embedding vector_cosine_ops);
create index if not exists profiles_goal_embedding_hnsw on public.profiles using hnsw (goal_embedding vector_cosine_ops);
create index if not exists circles_embedding_hnsw on public.circles using hnsw (embedding vector_cosine_ops);
create unique index if not exists raw_items_external_source_uidx on public.raw_items (external_id, source_id);
create index if not exists raw_items_unprocessed_idx on public.raw_items (source_id) where processed = false;
create index if not exists decisions_fts_idx on public.decisions using gin (fts);
create index if not exists stories_fts_idx on public.stories using gin (fts);
create index if not exists decisions_text_trgm on public.decisions using gin (text gin_trgm_ops);
create index if not exists stories_title_trgm on public.stories using gin (title gin_trgm_ops);
create index if not exists decisions_room_idx on public.decisions (room_code) where room_code is not null;
create index if not exists profiles_room_idx on public.profiles (room_code) where room_code is not null;
create index if not exists checkins_decision_idx on public.checkins (decision_id);
create index if not exists messages_connection_idx on public.messages (connection_id, created_at);
create index if not exists stories_created_idx on public.stories (created_at desc);

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------
create or replace function public.horizon_rank(h text) returns int
language sql immutable as $$
  select case h when '1w' then 1 when '1m' then 2 when '6m' then 3 when '1y' then 4 else 0 end
$$;

-- OR-semantics full-text query (more forgiving than plainto_tsquery's AND)
create or replace function public.or_tsquery(q text) returns tsquery
language sql immutable as $$
  select case
    when coalesce(trim(q), '') = '' or plainto_tsquery('english', q)::text = '' then null
    else to_tsquery('english', replace(plainto_tsquery('english', q)::text, ' & ', ' | '))
  end
$$;

-- ---------------------------------------------------------------------
-- Triggers
-- ---------------------------------------------------------------------
create or replace function public.schedule_checkins() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.scheduled_checkins (decision_id, due_at, horizon, status)
  select new.id, new.created_at + h.iv, h.horizon,
         case when new.created_at + h.iv <= now() then 'due' else 'pending' end
  from (values ('1w', interval '7 days'), ('1m', interval '30 days'),
               ('6m', interval '180 days'), ('1y', interval '365 days')) as h(horizon, iv)
  on conflict (decision_id, horizon) do nothing;
  return new;
end $$;

drop trigger if exists decisions_schedule_checkins on public.decisions;
create trigger decisions_schedule_checkins after insert on public.decisions
for each row execute function public.schedule_checkins();

create or replace function public.complete_scheduled_checkin() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.scheduled_checkins set status = 'done'
  where decision_id = new.decision_id and horizon = new.horizon;
  return new;
end $$;

drop trigger if exists checkins_complete_schedule on public.checkins;
create trigger checkins_complete_schedule after insert on public.checkins
for each row execute function public.complete_scheduled_checkin();

-- ---------------------------------------------------------------------
-- Vector + text search
-- ---------------------------------------------------------------------
create or replace function public.match_decisions(
  query_embedding vector(1536), match_count int default 50, threshold float default 0.3
) returns table (
  id uuid, text text, category text, options jsonb, chosen_option text,
  predicted_happiness int, predicted_outcome text, confidence int, is_seed boolean,
  created_at timestamptz, similarity float,
  latest_horizon text, latest_actual_happiness int, latest_regret int,
  latest_would_choose_again boolean, latest_surprise text
)
language sql stable set search_path = public, extensions as $$
  select d.id, d.text, d.category, d.options, d.chosen_option, d.predicted_happiness,
         d.predicted_outcome, d.confidence, d.is_seed, d.created_at,
         (1 - (d.embedding <=> query_embedding))::float as similarity,
         lc.horizon, lc.actual_happiness, lc.regret, lc.would_choose_again, lc.biggest_surprise
  from public.decisions d
  left join lateral (
    select c.horizon, c.actual_happiness, c.regret, c.would_choose_again, c.biggest_surprise
    from public.checkins c where c.decision_id = d.id
    order by public.horizon_rank(c.horizon) desc limit 1
  ) lc on true
  where d.embedding is not null
    and 1 - (d.embedding <=> query_embedding) > threshold
  order by d.embedding <=> query_embedding
  limit match_count
$$;

-- Fallback when OpenAI is unavailable: full-text + trigram
create or replace function public.search_decisions_text(q text, match_count int default 50)
returns table (
  id uuid, text text, category text, options jsonb, chosen_option text,
  predicted_happiness int, predicted_outcome text, confidence int, is_seed boolean,
  created_at timestamptz, similarity float,
  latest_horizon text, latest_actual_happiness int, latest_regret int,
  latest_would_choose_again boolean, latest_surprise text
)
language sql stable set search_path = public, extensions as $$
  select d.id, d.text, d.category, d.options, d.chosen_option, d.predicted_happiness,
         d.predicted_outcome, d.confidence, d.is_seed, d.created_at,
         greatest(coalesce(ts_rank(d.fts, public.or_tsquery(q)), 0), word_similarity(q, d.text))::float as similarity,
         lc.horizon, lc.actual_happiness, lc.regret, lc.would_choose_again, lc.biggest_surprise
  from public.decisions d
  left join lateral (
    select c.horizon, c.actual_happiness, c.regret, c.would_choose_again, c.biggest_surprise
    from public.checkins c where c.decision_id = d.id
    order by public.horizon_rank(c.horizon) desc limit 1
  ) lc on true
  where d.fts @@ public.or_tsquery(q) or q <% d.text
  order by similarity desc
  limit match_count
$$;

create or replace function public.decision_insights(ids uuid[])
returns jsonb language sql stable set search_path = public, extensions as $$
with d as (
  select * from public.decisions where id = any(ids)
),
c as (
  select c.*, d.chosen_option, d.predicted_happiness, public.horizon_rank(c.horizon) as hr
  from public.checkins c join d on d.id = c.decision_id
),
latest as (
  select distinct on (decision_id) * from c order by decision_id, hr desc
)
select jsonb_build_object(
  'n', (select count(*) from d),
  'n_with_checkins', (select count(*) from latest),
  'n_seed', (select count(*) from d where is_seed),
  'avg_predicted', (select round(avg(predicted_happiness)::numeric, 2) from d),
  'avg_actual', (select round(avg(actual_happiness)::numeric, 2) from latest),
  'forecast_gap', (select round((avg(actual_happiness) - avg(predicted_happiness))::numeric, 2) from latest),
  'would_choose_again_pct', (select round(100.0 * avg(case when would_choose_again then 1 else 0 end), 1) from latest),
  'avg_regret', (select round(avg(regret)::numeric, 2) from latest),
  'by_horizon', coalesce((
    select jsonb_agg(jsonb_build_object('horizon', h.horizon, 'n', h.n, 'avg_predicted', h.ap, 'avg_actual', h.aa) order by h.hr)
    from (
      select horizon, hr, count(*) as n,
             round(avg(predicted_happiness)::numeric, 2) as ap,
             round(avg(actual_happiness)::numeric, 2) as aa
      from c group by horizon, hr
    ) h
  ), '[]'::jsonb),
  'by_option', coalesce((
    select jsonb_agg(to_jsonb(o) order by o.n desc) from (
      select min(chosen_option) as option, count(*) as n,
             round(100.0 * avg(case when would_choose_again then 1 else 0 end), 1) as would_choose_again_pct,
             round(avg(regret)::numeric, 2) as avg_regret,
             round(avg(actual_happiness)::numeric, 2) as avg_actual,
             round(avg(predicted_happiness)::numeric, 2) as avg_predicted
      from latest where chosen_option is not null
      group by lower(trim(chosen_option))
      order by count(*) desc limit 4
    ) o
  ), '[]'::jsonb),
  'top_surprise_tags', coalesce((
    select jsonb_agg(jsonb_build_object('tag', s.tag, 'n', s.n) order by s.n desc) from (
      select lower(t) as tag, count(*) as n
      from c, unnest(c.surprise_tags) as t
      group by lower(t) order by count(*) desc limit 8
    ) s
  ), '[]'::jsonb)
)
$$;

create or replace function public.match_stories(
  query_embedding vector(1536), match_count int default 5, filter_path text default null
) returns table (
  id uuid, title text, url text, source_id text, category text, path text, tldr text,
  outcome_type text, decision_text text, what_they_chose text, starting_point text, outcome text,
  lessons text[], read_time_min int, similarity float
)
language sql stable set search_path = public, extensions as $$
  select s.id, s.title, s.url, s.source_id, s.category, s.path, s.tldr, s.outcome_type,
         s.decision_text, s.what_they_chose, s.starting_point, s.outcome, s.lessons, s.read_time_min,
         (1 - (s.embedding <=> query_embedding))::float as similarity
  from public.stories s
  where s.embedding is not null and (filter_path is null or s.path = filter_path)
  order by s.embedding <=> query_embedding
  limit match_count
$$;

create or replace function public.search_stories_text(q text, match_count int default 5, filter_path text default null)
returns table (
  id uuid, title text, url text, source_id text, category text, path text, tldr text,
  outcome_type text, decision_text text, what_they_chose text, starting_point text, outcome text,
  lessons text[], read_time_min int, similarity float
)
language sql stable set search_path = public, extensions as $$
  select s.id, s.title, s.url, s.source_id, s.category, s.path, s.tldr, s.outcome_type,
         s.decision_text, s.what_they_chose, s.starting_point, s.outcome, s.lessons, s.read_time_min,
         greatest(coalesce(ts_rank(s.fts, public.or_tsquery(q)), 0), word_similarity(q, s.title))::float as similarity
  from public.stories s
  where (filter_path is null or s.path = filter_path)
    and (s.fts @@ public.or_tsquery(q) or q <% s.title)
  order by similarity desc
  limit match_count
$$;

-- Hybrid (vector + full-text) story search with reciprocal-rank fusion.
create or replace function public.hybrid_search_stories(
  q text, query_embedding vector(1536) default null, match_count int default 60
) returns table (id uuid, score float)
language sql stable set search_path = public, extensions as $$
  with semantic as (
    select s.id, row_number() over (order by s.embedding <=> query_embedding) as r
    from public.stories s
    where query_embedding is not null and s.embedding is not null
    order by s.embedding <=> query_embedding
    limit match_count
  ),
  fulltext as (
    select s.id, row_number() over (
      order by ts_rank_cd(s.fts, public.or_tsquery(q)) desc, word_similarity(q, s.title) desc
    ) as r
    from public.stories s
    where s.fts @@ public.or_tsquery(q) or q <% s.title
    limit match_count
  )
  select coalesce(se.id, ft.id) as id,
         (coalesce(1.0 / (60 + se.r), 0) + coalesce(1.0 / (60 + ft.r), 0))::float as score
  from semantic se full outer join fulltext ft on se.id = ft.id
  order by score desc
  limit match_count
$$;

-- ---------------------------------------------------------------------
-- Partner matching
-- score = 0.5 * goal similarity + 0.35 * complementary skills + 0.15 * fit
-- Goal cosine similarity is rescaled from the typical 0.2–0.7 band of
-- text-embedding-3-small to 0–1 so percentages are human-meaningful.
-- ---------------------------------------------------------------------
create or replace function public.score_pair(me public.profiles, p public.profiles)
returns table (
  score float, goal_score float, skill_score float, fit_score float,
  they_have_i_need text[], i_have_they_need text[]
)
language sql stable set search_path = public, extensions as $$
  with base as (
    select
      case
        when (me).goal_embedding is not null and (p).goal_embedding is not null
          then least(1, greatest(0, ((1 - ((me).goal_embedding <=> (p).goal_embedding)) - 0.2) / 0.5))
        else least(1, similarity(coalesce((me).goals, ''), coalesce((p).goals, '')) * 2.5)
      end::float as g,
      array(
        select distinct lower(h) from unnest((p).skills_have) h
        where lower(h) in (select lower(n) from unnest((me).skills_need) n)
      ) as thin,
      array(
        select distinct lower(h) from unnest((me).skills_have) h
        where lower(h) in (select lower(n) from unnest((p).skills_need) n)
      ) as ihtn
  ),
  parts as (
    select g, thin, ihtn,
      (0.5 * case when cardinality((me).skills_need) = 0 then 0
                  else cardinality(thin)::float / cardinality((me).skills_need) end
     + 0.5 * case when cardinality((p).skills_need) = 0 then 0
                  else cardinality(ihtn)::float / cardinality((p).skills_need) end)::float as s,
      ((case when (me).path = (p).path then 1.0
             when (me).path = 'both' or (p).path = 'both' then 0.6 else 0 end)
     + (case when (me).stage = (p).stage then 1.0
             when (me).stage in ('idea','building') and (p).stage in ('idea','building') then 0.7
             when (me).stage in ('employed','switching') and (p).stage in ('employed','switching') then 0.7
             else 0.3 end)
     + greatest(0, 1 - abs((me).hours_per_week - (p).hours_per_week)::float / 30)
      )::float / 3 as f
    from base
  )
  select round((0.5 * g + 0.35 * s + 0.15 * f)::numeric, 4)::float, g, s, f, thin, ihtn from parts
$$;

create or replace function public.match_partners(p_user_id uuid, match_count int default 20)
returns table (
  id uuid, name text, headline text, avatar_url text, city text, path text, stage text,
  goals text, skills_have text[], skills_need text[], hours_per_week int, looking_for text[],
  is_seed boolean, score float, goal_score float, skill_score float, fit_score float,
  they_have_i_need text[], i_have_they_need text[]
)
language sql stable set search_path = public, extensions as $$
  select p.id, p.name, p.headline, p.avatar_url, p.city, p.path, p.stage, p.goals,
         p.skills_have, p.skills_need, p.hours_per_week, p.looking_for, p.is_seed,
         s.score, s.goal_score, s.skill_score, s.fit_score, s.they_have_i_need, s.i_have_they_need
  from public.profiles me
  join public.profiles p on p.id <> me.id
  cross join lateral public.score_pair(me, p) s
  where me.id = p_user_id
    and not exists (
      select 1 from public.connections c
      where (c.from_user = me.id and c.to_user = p.id) or (c.from_user = p.id and c.to_user = me.id)
    )
  order by s.score desc
  limit match_count
$$;

create or replace function public.room_pairs(code text, min_score float default 0)
returns table (
  a_id uuid, a_name text, b_id uuid, b_name text, score float,
  a_gets text[], b_gets text[]
)
language sql stable set search_path = public, extensions as $$
  select a.id, a.name, b.id, b.name, s.score, s.they_have_i_need, s.i_have_they_need
  from public.profiles a
  join public.profiles b on b.room_code = a.room_code and a.id < b.id
  cross join lateral public.score_pair(a, b) s
  where a.room_code = code and s.score >= min_score
  order by s.score desc
  limit 5
$$;

create or replace function public.room_stats(code text)
returns jsonb language sql stable set search_path = public, extensions as $$
with d as (
  select * from public.decisions where room_code = code
),
p as (
  select * from public.profiles where room_code = code
),
cat as (
  select category, count(*) as n from d group by category
)
select jsonb_build_object(
  'decisions', (select count(*) from d),
  'profiles', (select count(*) from p),
  'avg_predicted', (select round(avg(predicted_happiness)::numeric, 2) from d),
  'top_categories', coalesce((select jsonb_agg(jsonb_build_object('category', c.category, 'n', c.n) order by c.n desc) from (select * from cat order by n desc limit 6) c), '[]'::jsonb),
  'pairs', (select coalesce(jsonb_agg(to_jsonb(r) order by r.score desc), '[]'::jsonb) from public.room_pairs(code, 0.8) r)
)
$$;

create or replace function public.match_profiles_by_embedding(query_embedding vector(1536), match_count int default 4)
returns table (id uuid, name text, headline text, avatar_url text, path text, stage text, goals text, is_seed boolean, similarity float)
language sql stable set search_path = public, extensions as $$
  select p.id, p.name, p.headline, p.avatar_url, p.path, p.stage, p.goals, p.is_seed,
         (1 - (p.goal_embedding <=> query_embedding))::float
  from public.profiles p
  where p.goal_embedding is not null and p.is_guest = false
  order by p.goal_embedding <=> query_embedding
  limit match_count
$$;

-- Circles: each profile joins its single closest circle (or keyword match without embeddings)
create or replace function public.circles_overview(member_limit int default 6)
returns jsonb language sql stable set search_path = public, extensions as $$
  with best as (
    select distinct on (p.id) p.id as profile_id, c.id as circle_id,
           1 - (p.goal_embedding <=> c.embedding) as sim
    from public.profiles p cross join public.circles c
    where p.goal_embedding is not null and c.embedding is not null and p.is_guest = false
    order by p.id, p.goal_embedding <=> c.embedding
  ),
  kw as (
    select distinct on (p.id) p.id as profile_id, c.id as circle_id
    from public.profiles p join public.circles c
      on (p.goal_embedding is null or c.embedding is null)
     and exists (select 1 from unnest(c.keywords) k where p.goals ilike '%' || k || '%')
    where p.is_guest = false
  ),
  m as (
    select profile_id, circle_id from best where sim > 0.25
    union
    select profile_id, circle_id from kw
  )
  select coalesce(jsonb_agg(x order by (x->>'member_count')::int desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'id', c.id, 'slug', c.slug, 'name', c.name, 'description', c.description, 'path', c.path,
      'member_count', (select count(*) from m where m.circle_id = c.id),
      'members', coalesce((
        select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'headline', p.headline, 'avatar_url', p.avatar_url))
        from (select p2.* from m join public.profiles p2 on p2.id = m.profile_id
              where m.circle_id = c.id order by p2.created_at desc limit member_limit) p
      ), '[]'::jsonb)
    ) as x
    from public.circles c
  ) t
$$;

-- ---------------------------------------------------------------------
-- Aggregates for the home counters and /insights
-- ---------------------------------------------------------------------
create or replace function public.site_counters()
returns jsonb language sql stable set search_path = public as $$
  select jsonb_build_object(
    'decisions', (select count(*) from public.decisions),
    'checkins', (select count(*) from public.checkins),
    'stories', (select count(*) from public.stories),
    'sources', (select count(*) from public.sources where items_count > 0),
    'sources_total', (select count(*) from public.sources),
    'people', (select count(*) from public.profiles where is_guest = false)
  )
$$;

create or replace function public.global_insights()
returns jsonb language sql stable set search_path = public, extensions as $$
with latest as (
  select distinct on (c.decision_id) c.*, d.category, d.chosen_option, d.predicted_happiness, d.text
  from public.checkins c join public.decisions d on d.id = c.decision_id
  order by c.decision_id, public.horizon_rank(c.horizon) desc
),
by_choice as (
  select category, min(chosen_option) as choice, count(*) as n,
         round(avg(regret)::numeric, 2) as avg_regret,
         round(100.0 * avg(case when would_choose_again then 1 else 0 end), 1) as again_pct,
         round((avg(actual_happiness) - avg(predicted_happiness))::numeric, 2) as gap
  from latest where chosen_option is not null
  group by category, lower(trim(chosen_option))
  having count(*) >= 3
)
select jsonb_build_object(
  'gaps_by_category', coalesce((
    select jsonb_agg(to_jsonb(g) order by g.gap asc) from (
      select category, count(*) as n,
             round(avg(predicted_happiness)::numeric, 2) as avg_predicted,
             round(avg(actual_happiness)::numeric, 2) as avg_actual,
             round((avg(actual_happiness) - avg(predicted_happiness))::numeric, 2) as gap
      from latest group by category
    ) g
  ), '[]'::jsonb),
  'most_regretted', coalesce((
    select jsonb_agg(to_jsonb(r)) from (select * from by_choice order by avg_regret desc limit 6) r
  ), '[]'::jsonb),
  'would_do_again', coalesce((
    select jsonb_agg(to_jsonb(r)) from (select * from by_choice order by again_pct desc, n desc limit 6) r
  ), '[]'::jsonb),
  'story_outcomes', coalesce((
    select jsonb_agg(to_jsonb(o) order by o.total desc) from (
      select category, count(*) as total,
             count(*) filter (where outcome_type = 'success') as success,
             count(*) filter (where outcome_type = 'mixed') as mixed,
             count(*) filter (where outcome_type = 'failure') as failure,
             count(*) filter (where outcome_type = 'ongoing') as ongoing
      from public.stories group by category
    ) o
  ), '[]'::jsonb),
  'story_tags', coalesce((
    select jsonb_agg(jsonb_build_object('tag', t.tag, 'n', t.n) order by t.n desc) from (
      select lower(tag) as tag, count(*) as n from public.stories, unnest(surprise_tags) tag
      group by lower(tag) order by count(*) desc limit 14
    ) t
  ), '[]'::jsonb),
  'top_lessons', coalesce((
    select jsonb_agg(to_jsonb(l2)) from (
      select * from (
        select distinct on (s.id) s.id as story_id, s.title, s.source_id, s.outcome_type,
               s.created_at, lesson
        from public.stories s
        cross join lateral unnest(s.lessons) as lesson
        where cardinality(s.lessons) > 0
        order by s.id, char_length(lesson) asc
      ) l order by l.created_at desc limit 12
    ) l2
  ), '[]'::jsonb),
  'totals', jsonb_build_object(
    'decisions', (select count(*) from public.decisions),
    'checkins', (select count(*) from public.checkins),
    'stories', (select count(*) from public.stories),
    'avg_gap', (select round((avg(actual_happiness) - avg(predicted_happiness))::numeric, 2) from latest),
    'again_pct', (select round(100.0 * avg(case when would_choose_again then 1 else 0 end), 1) from latest)
  )
)
$$;

-- ---------------------------------------------------------------------
-- pg_cron: mark due check-ins every 5 minutes
-- ---------------------------------------------------------------------
do $$
begin
  if exists (select 1 from cron.job where jobname = 'hindsight-mark-due') then
    perform cron.unschedule('hindsight-mark-due');
  end if;
  perform cron.schedule(
    'hindsight-mark-due', '*/5 * * * *',
    $cron$update public.scheduled_checkins set status = 'due' where status = 'pending' and due_at <= now()$cron$
  );
end $$;

-- ---------------------------------------------------------------------
-- Realtime
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['decisions','checkins','stories','connections','messages','profiles','ingest_runs','sources']
  loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- Row Level Security
-- (All writes from the app go through server routes with zod validation;
--  these policies protect direct client access.)
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.decisions enable row level security;
alter table public.checkins enable row level security;
alter table public.scheduled_checkins enable row level security;
alter table public.sources enable row level security;
alter table public.raw_items enable row level security;
alter table public.stories enable row level security;
alter table public.connections enable row level security;
alter table public.messages enable row level security;
alter table public.ingest_runs enable row level security;
alter table public.circles enable row level security;

drop policy if exists "profiles public read" on public.profiles;
create policy "profiles public read" on public.profiles for select using (true);
drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles insert own" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Decisions are anonymous by design: the UI never renders user_id.
drop policy if exists "decisions public read" on public.decisions;
create policy "decisions public read" on public.decisions for select using (true);
drop policy if exists "checkins public read" on public.checkins;
create policy "checkins public read" on public.checkins for select using (true);
drop policy if exists "scheduled public read" on public.scheduled_checkins;
create policy "scheduled public read" on public.scheduled_checkins for select using (true);
drop policy if exists "stories public read" on public.stories;
create policy "stories public read" on public.stories for select using (true);
drop policy if exists "sources public read" on public.sources;
create policy "sources public read" on public.sources for select using (true);
drop policy if exists "ingest runs public read" on public.ingest_runs;
create policy "ingest runs public read" on public.ingest_runs for select using (true);
drop policy if exists "circles public read" on public.circles;
create policy "circles public read" on public.circles for select using (true);
-- raw_items: no public policy (service role only)

drop policy if exists "connections participants read" on public.connections;
create policy "connections participants read" on public.connections for select
  using (auth.uid() = from_user or auth.uid() = to_user);
drop policy if exists "connections create own" on public.connections;
create policy "connections create own" on public.connections for insert
  with check (auth.uid() = from_user);
drop policy if exists "connections participants update" on public.connections;
create policy "connections participants update" on public.connections for update
  using (auth.uid() = from_user or auth.uid() = to_user);

drop policy if exists "messages participants read" on public.messages;
create policy "messages participants read" on public.messages for select using (
  exists (select 1 from public.connections c where c.id = connection_id
          and (auth.uid() = c.from_user or auth.uid() = c.to_user))
);
drop policy if exists "messages participants send" on public.messages;
create policy "messages participants send" on public.messages for insert with check (
  sender = auth.uid() and exists (
    select 1 from public.connections c where c.id = connection_id and c.status = 'accepted'
      and (auth.uid() = c.from_user or auth.uid() = c.to_user))
);

-- ---------------------------------------------------------------------
-- The 10 sources
-- ---------------------------------------------------------------------
insert into public.sources (id, name, type, base_url) values
  ('reddit-entrepreneur', 'r/Entrepreneur', 'reddit', 'https://www.reddit.com/r/Entrepreneur'),
  ('reddit-startups', 'r/startups', 'reddit', 'https://www.reddit.com/r/startups'),
  ('reddit-smallbusiness', 'r/smallbusiness', 'reddit', 'https://www.reddit.com/r/smallbusiness'),
  ('reddit-career', 'r/careerguidance + r/careeradvice', 'reddit', 'https://www.reddit.com/r/careerguidance'),
  ('reddit-sideproject', 'r/SideProject + r/SaaS', 'reddit', 'https://www.reddit.com/r/SideProject'),
  ('hackernews', 'Hacker News', 'algolia', 'https://news.ycombinator.com'),
  ('indiehackers', 'Indie Hackers', 'rss', 'https://www.indiehackers.com'),
  ('producthunt', 'Product Hunt', 'graphql', 'https://www.producthunt.com'),
  ('workplace-se', 'The Workplace (Stack Exchange)', 'stackexchange', 'https://workplace.stackexchange.com'),
  ('devto-medium', 'Dev.to + Medium', 'api+rss', 'https://dev.to')
on conflict (id) do update set name = excluded.name, type = excluded.type, base_url = excluded.base_url;

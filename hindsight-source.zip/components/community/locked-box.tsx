import Link from "next/link";
import { Lock } from "lucide-react";
import { UnlockButton } from "@/components/community/forms";
import { EyeBlocked } from "@/components/community/eye-blocked";
import type { AccessState, Standing } from "@/lib/community";
import { CREDITS_PER_ANSWER } from "@/lib/community";

const WIDTHS = [
  ["92%", "100%", "78%"],
  ["86%", "95%", "64%"],
  ["100%", "82%", "55%"],
];

/** The box of hidden answers: blurred placeholder cards, an eye with an X over them, and how to get in. */
export function LockedBox({ count, state, standing, questionId, loginHref }: { count: number; state: AccessState; standing: Standing | null; questionId: string; loginHref: string }) {
  const cards = Math.max(1, Math.min(count, 3));
  return (
    <div className="relative overflow-hidden rounded-2xl border bg-card shadow-sm">
      <div className="select-none space-y-3 p-5" aria-hidden>
        {Array.from({ length: cards }).map((_, i) => (
          <div key={i} className="rounded-xl border bg-background p-4">
            <div className="locked-lines space-y-2.5">
              {WIDTHS[i % 3].map((w, j) => (
                <span key={j} style={{ width: w }} />
              ))}
            </div>
            <div className="locked-lines mt-4 flex items-center gap-2">
              <span style={{ width: 22, height: 22, borderRadius: 999 }} />
              <span style={{ width: 90, height: 9 }} />
            </div>
          </div>
        ))}
      </div>

      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-card/30 via-card/80 to-card px-5 text-center backdrop-blur-[3px]">
        <EyeBlocked size={104} />
        <h3 className="mt-4 text-lg font-semibold tracking-tight">
          {count} answer{count === 1 ? "" : "s"} hidden
        </h3>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">
          {state === "signed-out" ? "Sign in, then share your own take to see what others said." : `Give one answer, get all of them. Each answer you write earns ${CREDITS_PER_ANSWER} unlocks.`}
        </p>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
          {state === "signed-out" && (
            <Link href={loginHref} className="inline-flex h-10 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground hover:brightness-110">
              Sign in
            </Link>
          )}
          {(state === "can-unlock" || state === "locked") && (
            <a href="#your-answer" className="inline-flex h-10 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground hover:brightness-110">
              Answer to unlock
            </a>
          )}
          {state === "can-unlock" && standing && <UnlockButton questionId={questionId} credits={standing.credits} />}
        </div>
        {state === "locked" && (
          <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
            <Lock className="h-3 w-3" /> You&apos;re out of unlocks. Answering is the only way in.
          </p>
        )}
      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";

/** An eye with a blur on it and a crisp X across it: "you can't see this yet". */
export function EyeBlocked({ size = 96, className }: { size?: number; className?: string }) {
  return (
    <div className={cn("eye-blocked-pulse relative", className)} style={{ width: size, height: size * 0.62 }} aria-hidden>
      <svg viewBox="0 0 120 74" width="100%" height="100%" className="overflow-visible">
        <defs>
          <filter id="eb-blur" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="2.6" />
          </filter>
        </defs>
        {/* blurred eye */}
        <g filter="url(#eb-blur)" opacity="0.9">
          <path d="M6 37 C26 6 94 6 114 37 C94 68 26 68 6 37 Z" fill="hsl(var(--card))" stroke="hsl(var(--foreground) / 0.55)" strokeWidth="5" strokeLinejoin="round" />
          <circle cx="60" cy="37" r="17" fill="hsl(var(--foreground) / 0.55)" />
          <circle cx="60" cy="37" r="7" fill="hsl(var(--card))" />
        </g>
        {/* the X, drawn sharp on top */}
        <g stroke="hsl(var(--background))" strokeWidth="13" strokeLinecap="round">
          <path d="M40 12 L80 62" />
          <path d="M80 12 L40 62" />
        </g>
        <g stroke="hsl(0 72% 50%)" strokeWidth="7" strokeLinecap="round">
          <path d="M40 12 L80 62" />
          <path d="M80 12 L40 62" />
        </g>
      </svg>
    </div>
  );
}

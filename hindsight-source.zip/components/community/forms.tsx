"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Loader2, Lock, Unlock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { CATEGORIES } from "@/lib/constants";
import { cn } from "@/lib/utils";

async function post(url: string, body: unknown): Promise<{ ok: boolean; data: Record<string, unknown> }> {
  try {
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    return { ok: res.ok, data: await res.json().catch(() => ({})) };
  } catch {
    return { ok: false, data: { error: "Network error. Try again." } };
  }
}

export function AskForm({ initialTitle = "" }: { initialTitle?: string }) {
  const router = useRouter();
  const [title, setTitle] = useState(initialTitle);
  const [body, setBody] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("career");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const r = await post("/api/community/questions", { title, body, category });
    if (!r.ok) {
      setError(String(r.data.error ?? "Something went wrong."));
      return setBusy(false);
    }
    router.push(`/community/${r.data.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <div>
        <label htmlFor="q-title" className="text-sm font-medium">Your question</label>
        <Input id="q-title" className="mt-2" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} placeholder="Should I take the counteroffer or leave?" required />
        <p className="mt-1.5 text-xs text-muted-foreground">{title.length}/200</p>
      </div>
      <div>
        <label htmlFor="q-body" className="text-sm font-medium">Details <span className="font-normal text-muted-foreground">(optional, but better answers need context)</span></label>
        <Textarea id="q-body" className="mt-2 min-h-[140px]" value={body} onChange={(e) => setBody(e.target.value)} maxLength={3000} placeholder="Your situation, what you've considered, what's at stake." />
      </div>
      <div>
        <p className="text-sm font-medium">Topic</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={cn("rounded-full border px-3 py-1.5 text-sm capitalize transition", category === c ? "border-primary/60 bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground")}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <p className="rounded-xl border bg-card/60 p-3 text-xs text-muted-foreground">
        Your question shows your display name. Avoid sharing employers or anything private.
      </p>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <Button type="submit" size="lg" disabled={busy || title.trim().length < 10}>
        {busy && <Loader2 className="h-4 w-4 animate-spin" />} Post question
      </Button>
    </form>
  );
}

export function AnswerForm({ questionId, locked }: { questionId: string; locked?: boolean }) {
  const router = useRouter();
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const r = await post("/api/community/answers", { question_id: questionId, body });
    if (!r.ok) {
      setError(String(r.data.error ?? "Something went wrong."));
      return setBusy(false);
    }
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <Textarea value={body} onChange={(e) => setBody(e.target.value)} maxLength={3000} placeholder="Share what you would do, or what happened when you faced something similar." className="min-h-[130px]" />
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">{body.trim().length < 20 ? `${20 - body.trim().length} more characters` : `${body.length}/3000`}</p>
        <Button type="submit" disabled={busy || body.trim().length < 20}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} {locked ? "Answer to unlock" : "Post answer"}
        </Button>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
    </form>
  );
}

export function UnlockButton({ questionId, credits }: { questionId: string; credits: number }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  async function go() {
    setBusy(true);
    setError(null);
    const r = await post("/api/community/unlock", { question_id: questionId });
    if (!r.ok) {
      setError(String(r.data.error ?? "Could not unlock."));
      return setBusy(false);
    }
    router.refresh();
  }
  return (
    <div>
      <Button onClick={go} disabled={busy}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unlock className="h-4 w-4" />} Use 1 unlock ({credits} left)
      </Button>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}

export function LockIcon() {
  return <Lock className="h-5 w-5 text-primary" />;
}

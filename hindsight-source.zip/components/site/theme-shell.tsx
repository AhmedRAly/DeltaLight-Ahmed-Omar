"use client";

import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const LIGHT: string[] = [];

/** Switches the colour tokens to the light "review site" look on login and Community. */
export function ThemeShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() ?? "/";
  const light = LIGHT.some((p) => pathname === p || pathname.startsWith(p + "/"));
  return <div className={cn("min-h-[100dvh]", light && "gd")}>{children}</div>;
}

"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { ArrowRight, Loader2 } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import type { DemoUser } from "@/lib/demo";

type Persona = Pick<DemoUser, "id" | "name" | "headline" | "blurb">;

export function DemoLogin({ users, next }: { users: Persona[]; next: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function go(id: string) {
    setBusy(id);
    setError(null);
    try {
      const res = await fetch("/api/demo-login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
      if (!res.ok) throw new Error();
      router.push(next);
      router.refresh();
    } catch {
      setError("Couldn't start the demo session. Try again.");
      setBusy(null);
    }
  }

  return (
    <div>
      <ul className="grid gap-3 sm:grid-cols-2">
        {users.map((u) => (
          <li key={u.id}>
            <button
              type="button"
              onClick={() => go(u.id)}
              disabled={busy !== null}
              className="group flex h-full w-full items-start gap-3 rounded-2xl border bg-card/70 p-4 text-left transition hover:-translate-y-0.5 hover:border-primary/40 disabled:opacity-60"
            >
              <Avatar name={u.name} size={44} />
              <span className="min-w-0 flex-1">
                <span className="block font-medium">{u.name}</span>
                <span className="mt-0.5 block text-sm text-foreground/75">{u.headline}</span>
                <span className="mt-1 block text-xs text-muted-foreground">{u.blurb}</span>
              </span>
              {busy === u.id ? <Loader2 className="mt-1 h-4 w-4 animate-spin text-primary" /> : <ArrowRight className="mt-1 h-4 w-4 text-muted-foreground transition group-hover:text-primary" />}
            </button>
          </li>
        ))}
      </ul>
      {error && <p className="mt-3 text-sm text-red-300">{error}</p>}
    </div>
  );
}

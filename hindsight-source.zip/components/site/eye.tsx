"use client";

import { useEffect, useId, useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { cn } from "@/lib/utils";

const ALMOND = "M3 20 C13 5 47 5 57 20 C47 35 13 35 3 20 Z";

/** The Hindsight mark: an open eye. Static, used in the nav and as the favicon base. */
export function EyeMark({ size = 28, className }: { size?: number; className?: string }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={size} height={(size * 40) / 60} viewBox="0 0 60 40" className={cn("overflow-visible", className)} aria-hidden>
      <defs>
        <radialGradient id={`iris-${id}`} cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="hsl(148 75% 62%)" />
          <stop offset="70%" stopColor="hsl(148 70% 45%)" />
          <stop offset="100%" stopColor="hsl(148 70% 30%)" />
        </radialGradient>
        <clipPath id={`clip-${id}`}>
          <path d={ALMOND} />
        </clipPath>
      </defs>
      <path d={ALMOND} fill="hsl(240 10% 3%)" stroke="hsl(148 70% 45%)" strokeWidth="2.2" strokeLinejoin="round" />
      <g clipPath={`url(#clip-${id})`}>
        <circle cx="30" cy="20" r="9.5" fill={`url(#iris-${id})`} />
        <circle cx="30" cy="20" r="4.2" fill="hsl(240 10% 2%)" />
        <circle cx="33" cy="16.8" r="1.7" fill="white" opacity="0.9" />
      </g>
    </svg>
  );
}

/** A larger eye whose iris follows the pointer and which blinks now and then. */
export function EyeLive({ size = 72, className }: { size?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const id = useId().replace(/:/g, "");
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 140, damping: 16 });
  const sy = useSpring(y, { stiffness: 140, damping: 16 });

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2);
      const dy = e.clientY - (r.top + r.height / 2);
      const dist = Math.hypot(dx, dy) || 1;
      const reach = Math.min(1, dist / 260);
      x.set((dx / dist) * 9 * reach);
      y.set((dy / dist) * 5 * reach);
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, [x, y]);

  return (
    <div ref={ref} className={cn("eye-blink", className)} style={{ width: size, height: (size * 40) / 60 }} aria-hidden>
      <svg width="100%" height="100%" viewBox="0 0 60 40" className="overflow-visible">
        <defs>
          <radialGradient id={`iris-${id}`} cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="hsl(148 75% 62%)" />
            <stop offset="70%" stopColor="hsl(148 70% 45%)" />
            <stop offset="100%" stopColor="hsl(148 70% 30%)" />
          </radialGradient>
          <clipPath id={`clip-${id}`}>
            <path d={ALMOND} />
          </clipPath>
          <filter id={`glow-${id}`} x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" />
          </filter>
        </defs>
        <path d={ALMOND} fill="hsl(148 70% 45%)" opacity="0.25" filter={`url(#glow-${id})`} />
        <path d={ALMOND} fill="hsl(240 10% 3%)" stroke="hsl(148 70% 45%)" strokeWidth="1.6" strokeLinejoin="round" />
        <g clipPath={`url(#clip-${id})`}>
          <motion.g style={{ x: sx, y: sy }}>
            <circle cx="30" cy="20" r="9.5" fill={`url(#iris-${id})`} />
            <circle cx="30" cy="20" r="4.2" fill="hsl(240 10% 2%)" />
            <circle cx="33" cy="16.8" r="1.7" fill="white" opacity="0.9" />
          </motion.g>
        </g>
      </svg>
    </div>
  );
}

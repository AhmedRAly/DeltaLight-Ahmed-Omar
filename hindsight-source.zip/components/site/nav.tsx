"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { EyeMark } from "@/components/site/eye";
import { cn } from "@/lib/utils";

const PRODUCT_LINKS = [
  { href: "/ask", label: "Research" },
  { href: "/community", label: "Community" },
  { href: "/stories", label: "Stories" },
  { href: "/insights", label: "Insights" },
  { href: "/log", label: "Log a decision" },
];

const BUSINESS_LINKS = [
  { href: "/business", label: "Network" },
  { href: "/partners/quick", label: "Quick match" },
  { href: "/room/new", label: "Live room" },
];

const BUSINESS_PREFIXES = ["/business", "/partners", "/connections", "/room"];

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
      <EyeMark size={30} />
      Hindsight
    </Link>
  );
}

export function SiteNav({ signedIn, userName = null }: { signedIn: boolean; userName?: string | null }) {
  const pathname = usePathname() ?? "/";
  const [open, setOpen] = useState(false);
  if (pathname.startsWith("/room/")) return null;
  if (pathname === "/login") return (<header className="w-full"><div className="container flex h-14 items-center"><Logo /></div></header>);

  const isHome = pathname === "/";
  const business = BUSINESS_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));
  const links = business ? BUSINESS_LINKS : PRODUCT_LINKS;
  const account = signedIn ? { href: "/connections", label: "Connections" } : { href: "/login", label: "Sign in" };
  const accountLinks = signedIn ? [{ href: "/connections", label: "Connections" }] : [];

  return (
    <header
      className={cn(
        "top-0 z-40 w-full",
        isHome ? "absolute border-transparent" : "sticky border-b border-white/5 bg-background/70 backdrop-blur-xl"
      )}
    >
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-4">
          <Logo />
          <div className="hidden items-center rounded-full border bg-card/60 p-0.5 text-xs sm:flex">
            {[
              { href: "/", label: "Advice", on: !business },
              { href: "/business", label: "Business", on: business },
            ].map((t) => (
              <Link
                key={t.label}
                href={t.href}
                className={cn("relative rounded-full px-3 py-1 transition-colors", t.on ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
              >
                {t.on && <motion.span layoutId="product-pill" className="absolute inset-0 -z-10 rounded-full bg-primary" transition={{ type: "spring", duration: 0.45 }} />}
                {t.label}
              </Link>
            ))}
          </div>
        </div>

        <nav className="hidden items-center gap-1 md:flex">
          {!isHome &&
            links.map((l) => {
              const active = pathname === l.href || pathname.startsWith(l.href + "/");
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={cn("relative rounded-lg px-3 py-1.5 text-sm transition-colors", active ? "text-foreground" : "text-muted-foreground hover:text-foreground")}
                >
                  {active && <motion.span layoutId="nav-pill" className="absolute inset-0 -z-10 rounded-lg bg-secondary" transition={{ type: "spring", duration: 0.45 }} />}
                  {l.label}
                </Link>
              );
            })}
          {!isHome && <span className="mx-2 h-5 w-px bg-border" />}
          {signedIn ? (
            <div className="flex items-center gap-1">
              {accountLinks.map((l) => (
                <Link key={l.href} href={l.href} className="rounded-lg px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground">
                  {l.label}
                </Link>
              ))}
              <form action="/auth/signout" method="post" className="flex items-center gap-2 rounded-full border py-1 pl-3 pr-1 text-sm">
                <span className="max-w-[110px] truncate text-foreground/90">{userName ?? "Signed in"}</span>
                <button className="rounded-full bg-secondary px-2.5 py-1 text-xs text-muted-foreground hover:text-foreground">Sign out</button>
              </form>
            </div>
          ) : (
            <Link href={account.href} className="rounded-lg border px-3 py-1.5 text-sm hover:bg-secondary">
              {account.label}
            </Link>
          )}
        </nav>

        <button className="md:hidden" aria-label="Menu" onClick={() => setOpen((v) => !v)}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {open && (
        <div className="border-t bg-background md:hidden">
          <div className="container flex flex-col py-2">
            {[{ href: "/", label: "Hindsight — Advice" }, { href: "/business", label: "Hindsight Business" }, ...links, ...accountLinks, ...(signedIn ? [] : [account])].map((l) => (
              <Link key={l.href + l.label} href={l.href} onClick={() => setOpen(false)} className="py-3 text-base text-muted-foreground hover:text-foreground">
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { Input } from "@/components/ui/input";
import type { DemoUser } from "@/lib/demo";

type Persona = Pick<DemoUser, "id" | "name" | "headline">;

/** Demo-only sign-in. Any email and password works; the personas below are one-click shortcuts. */
export function FakeLogin({ users, next }: { users: Persona[]; next: string }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function login(body: { id?: string; email?: string }, key: string) {
    setBusy(key);
    setError(null);
    try {
      const res = await fetch("/api/demo-login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      if (!res.ok) throw new Error();
      router.push(next);
      router.refresh();
    } catch {
      setError("Couldn't sign you in. Try again.");
      setBusy(null);
    }
  }

  return (
    <div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          login({ email: email.trim() }, "form");
        }}
        className="space-y-3"
      >
        <div>
          <label htmlFor="li-email" className="text-sm font-medium">Email</label>
          <Input id="li-email" type="email" required autoComplete="email" className="mt-1.5 bg-card" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        <div>
          <label htmlFor="li-pw" className="text-sm font-medium">Password</label>
          <Input id="li-pw" type="password" required minLength={1} autoComplete="current-password" className="mt-1.5 bg-card" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Anything works in the demo" />
        </div>
        <button disabled={busy !== null} className="flex h-11 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-semibold text-primary-foreground transition hover:brightness-110 disabled:opacity-60">
          {busy === "form" && <Loader2 className="h-4 w-4 animate-spin" />} Sign in
        </button>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-wider text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or continue as <span className="h-px flex-1 bg-border" />
      </div>

      <ul className="space-y-2">
        {users.map((u) => (
          <li key={u.id}>
            <button
              type="button"
              disabled={busy !== null}
              onClick={() => login({ id: u.id }, u.id)}
              className="flex w-full items-center gap-3 rounded-xl border bg-card p-3 text-left transition hover:border-primary/50 hover:shadow-sm disabled:opacity-60"
            >
              <Avatar name={u.name} size={36} />
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-medium">{u.name}</span>
                <span className="block truncate text-xs text-muted-foreground">{u.headline}</span>
              </span>
              {busy === u.id && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
            </button>
          </li>
        ))}
      </ul>
      {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
      <p className="mt-5 text-xs text-muted-foreground">Demo sign-in only. No account is created and nothing is sent anywhere.</p>
    </div>
  );
}

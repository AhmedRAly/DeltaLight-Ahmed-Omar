"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Mail } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getBrowserSupabase } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

type Mode = "password" | "link";

export function LoginForm({ next }: { next: string }) {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("password");
  const [creating, setCreating] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [state, setState] = useState<"idle" | "working" | "sent">("idle");
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = z.string().email().safeParse(email.trim());
    if (!parsed.success) return setError("Enter a valid email address.");
    const supabase = getBrowserSupabase();
    if (!supabase) return setError("Sign-in is unavailable right now.");
    setState("working");
    setError(null);

    if (mode === "link") {
      const { error: err } = await supabase.auth.signInWithOtp({
        email: parsed.data,
        options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}` },
      });
      if (err) {
        setError(err.message.toLowerCase().includes("rate") ? "Too many emails sent. Wait a bit, or use a password instead." : "Couldn't send the link. Try again.");
        return setState("idle");
      }
      return setState("sent");
    }

    if (password.length < 8) {
      setError("Use at least 8 characters for your password.");
      return setState("idle");
    }
    if (creating) {
      const { data, error: err } = await supabase.auth.signUp({
        email: parsed.data,
        password,
        options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}` },
      });
      if (err) {
        setError(err.message);
        return setState("idle");
      }
      if (!data.session) return setState("sent"); // email confirmation required
    } else {
      const { error: err } = await supabase.auth.signInWithPassword({ email: parsed.data, password });
      if (err) {
        setError(err.message.toLowerCase().includes("invalid") ? "That email and password don't match." : err.message);
        return setState("idle");
      }
    }
    router.push(next);
    router.refresh();
  }

  if (state === "sent") {
    return (
      <div className="rounded-2xl border border-primary/30 bg-primary/10 p-6">
        <Mail className="h-6 w-6 text-primary" />
        <p className="mt-3 text-lg">Check {email} to finish.</p>
        <p className="mt-1 text-sm text-muted-foreground">Open the email on this device to confirm and sign in.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-5 flex rounded-full border bg-card/60 p-0.5 text-sm">
        {(
          [
            ["password", "Password"],
            ["link", "Email link"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => {
              setMode(id);
              setError(null);
            }}
            className={cn("flex-1 rounded-full py-1.5 transition", mode === id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
          >
            {label}
          </button>
        ))}
      </div>
      <form onSubmit={submit} className="space-y-3">
        <Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" required />
        {mode === "password" && (
          <Input
            type="password"
            autoComplete={creating ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password (8+ characters)"
            required
          />
        )}
        {error && <p className="text-sm text-red-300">{error}</p>}
        <Button type="submit" size="lg" className="w-full" disabled={state === "working"}>
          {state === "working" && <Loader2 className="h-4 w-4 animate-spin" />}
          {mode === "link" ? "Email me a magic link" : creating ? "Create account" : "Sign in"}
        </Button>
      </form>
      {mode === "password" && (
        <button type="button" onClick={() => setCreating((v) => !v)} className="mt-4 text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
          {creating ? "Already have an account? Sign in" : "New here? Create an account"}
        </button>
      )}
    </div>
  );
}

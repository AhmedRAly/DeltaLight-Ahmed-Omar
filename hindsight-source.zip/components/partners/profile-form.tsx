"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Segmented, Slider, TagInput } from "@/components/ui/misc";
import { LOOKING_FOR, LOOKING_FOR_LABEL, PATHS, STAGES, STAGE_LABEL, type LookingFor, type PathKind, type Stage } from "@/lib/constants";
import { SKILL_SUGGESTIONS } from "@/lib/partners";
import { cn } from "@/lib/utils";

export type ProfileDraft = {
  name: string;
  headline: string;
  city: string;
  path: PathKind;
  stage: Stage;
  goals: string;
  skills_have: string[];
  skills_need: string[];
  hours_per_week: number;
  looking_for: LookingFor[];
};

export const EMPTY_PROFILE: ProfileDraft = {
  name: "",
  headline: "",
  city: "",
  path: "business",
  stage: "idea",
  goals: "",
  skills_have: [],
  skills_need: [],
  hours_per_week: 10,
  looking_for: ["cofounder"],
};

export const GUEST_KEY = "hs_profile_id";

export function ProfileForm({
  initial,
  signedIn,
  onSaved,
  submitLabel = "Find my matches",
}: {
  initial?: Partial<ProfileDraft>;
  signedIn: boolean;
  onSaved: (id: string) => void;
  submitLabel?: string;
}) {
  const [p, setP] = useState<ProfileDraft>({ ...EMPTY_PROFILE, ...initial });
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof ProfileDraft>(k: K, v: ProfileDraft[K]) => setP((prev) => ({ ...prev, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (p.goals.trim().length < 10) {
      setError("Tell us a bit more about your goal (at least a sentence).");
      return;
    }
    setPending(true);
    setError(null);
    try {
      let guestId: string | null = null;
      try {
        guestId = localStorage.getItem(GUEST_KEY);
      } catch {
        guestId = null;
      }
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...p, guest_id: signedIn ? null : guestId }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not save.");
      if (json.guest) {
        try {
          localStorage.setItem(GUEST_KEY, json.id);
        } catch {
          // ignore storage errors
        }
      }
      onSaved(json.id);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-7">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" value={p.name} onChange={(e) => set("name", e.target.value)} required maxLength={60} placeholder="Ada Lovelace" />
        </div>
        <div>
          <Label htmlFor="city">City</Label>
          <Input id="city" value={p.city} onChange={(e) => set("city", e.target.value)} maxLength={60} placeholder="Toronto" />
        </div>
      </div>
      <div>
        <Label htmlFor="headline">Headline</Label>
        <Input id="headline" value={p.headline} onChange={(e) => set("headline", e.target.value)} maxLength={120} placeholder="Backend engineer building a tool for freelance accountants" />
      </div>
      <div>
        <Label>Path</Label>
        <Segmented options={PATHS} value={p.path} onChange={(v) => set("path", v)} labels={{ business: "Business", corporate: "Corporate career", both: "Both" }} />
      </div>
      <div>
        <Label>Stage</Label>
        <Segmented options={STAGES} value={p.stage} onChange={(v) => set("stage", v)} labels={STAGE_LABEL} />
      </div>
      <div>
        <Label htmlFor="goals">What do you want to build or achieve?</Label>
        <Textarea
          id="goals"
          value={p.goals}
          onChange={(e) => set("goals", e.target.value)}
          maxLength={800}
          placeholder="Launch a SaaS for independent gyms and reach $10k MRR by next summer."
        />
      </div>
      <div>
        <Label>Skills you have</Label>
        <TagInput value={p.skills_have} onChange={(v) => set("skills_have", v)} placeholder="Type a skill and press Enter" suggestions={SKILL_SUGGESTIONS.filter((s) => !p.skills_need.includes(s))} />
      </div>
      <div>
        <Label>Skills you need</Label>
        <TagInput value={p.skills_need} onChange={(v) => set("skills_need", v)} placeholder="What's missing on your team?" suggestions={SKILL_SUGGESTIONS.filter((s) => !p.skills_have.includes(s))} />
      </div>
      <div>
        <Label>Hours per week you can commit</Label>
        <Slider value={p.hours_per_week} onChange={(v) => set("hours_per_week", v)} min={1} max={60} lowLabel="a few" highLabel="full-time" />
      </div>
      <div>
        <Label>Looking for</Label>
        <div className="flex flex-wrap gap-2">
          {LOOKING_FOR.map((l) => {
            const on = p.looking_for.includes(l);
            return (
              <button
                key={l}
                type="button"
                onClick={() => set("looking_for", on ? p.looking_for.filter((x) => x !== l) : [...p.looking_for, l])}
                className={cn("rounded-xl border px-3 py-2 text-sm transition", on ? "border-primary/60 bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground")}
              >
                {LOOKING_FOR_LABEL[l]}
              </button>
            );
          })}
        </div>
      </div>
      {error && <p className="rounded-xl border border-red-500/20 bg-red-500/5 p-3 text-sm text-red-200">{error}</p>}
      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending && <Loader2 className="h-4 w-4 animate-spin" />}
        {submitLabel}
      </Button>
    </form>
  );
}

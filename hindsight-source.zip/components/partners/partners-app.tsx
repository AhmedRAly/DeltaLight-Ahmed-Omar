"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Pencil, RefreshCw } from "lucide-react";
import { MatchCard, type MatchWithWhy } from "@/components/partners/match-card";
import { GUEST_KEY, ProfileForm, type ProfileDraft } from "@/components/partners/profile-form";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/misc";

type Props = {
  signedIn: boolean;
  ownProfileId: string | null;
  ownProfile: Partial<ProfileDraft> | null;
};

export function PartnersApp({ signedIn, ownProfileId, ownProfile }: Props) {
  const [profileId, setProfileId] = useState<string | null>(ownProfileId);
  const [ready, setReady] = useState(false);
  const [editing, setEditing] = useState(false);
  const [prefill, setPrefill] = useState<Partial<ProfileDraft> | null>(ownProfile);
  const [matches, setMatches] = useState<MatchWithWhy[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Resolve which profile to match for: signed-in profile, else a guest profile from localStorage.
  useEffect(() => {
    if (ownProfileId) {
      setReady(true);
      return;
    }
    let guest: string | null = null;
    try {
      guest = localStorage.getItem(GUEST_KEY);
    } catch {
      guest = null;
    }
    if (!guest) {
      setReady(true);
      return;
    }
    fetch(`/api/profile?id=${guest}`)
      .then((r) => r.json())
      .then((j: { profile: (Omit<ProfileDraft, "headline" | "city"> & { id: string; headline: string | null; city: string | null }) | null }) => {
        if (!j.profile) return;
        const { id: _id, headline, city, ...rest } = j.profile;
        const draft: Partial<ProfileDraft> = { ...rest, headline: headline ?? "", city: city ?? "" };
        if (signedIn) setPrefill(draft);
        else {
          setPrefill(draft);
          setProfileId(j.profile.id);
        }
      })
      .catch(() => undefined)
      .finally(() => setReady(true));
  }, [ownProfileId, signedIn]);

  const load = useCallback(async (id: string) => {
    setMatches(null);
    setError(null);
    try {
      const res = await fetch(`/api/partners/matches?profile_id=${id}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Matching failed.");
      setMatches(json.matches);
    } catch (err) {
      setError((err as Error).message);
      setMatches([]);
    }
  }, []);

  useEffect(() => {
    if (profileId && !editing) load(profileId);
  }, [profileId, editing, load]);

  if (!ready) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
    );
  }

  if (!profileId || editing) {
    return (
      <div className="rounded-3xl border bg-card/70 p-5 md:p-8">
        <h2 className="text-2xl font-semibold tracking-tight">{profileId ? "Edit your goal profile" : "Build your goal profile"}</h2>
        <p className="mt-2 text-muted-foreground">
          Matching weighs your goals (50%), complementary skills (35%) and path/stage/time fit (15%).
          {!signedIn && " You can match instantly as a guest — sign in when you want to connect."}
        </p>
        <div className="mt-8">
          <ProfileForm
            initial={prefill ?? undefined}
            signedIn={signedIn}
            submitLabel={profileId ? "Save and rematch" : "Find my matches"}
            onSaved={(id) => {
              setProfileId(id);
              setEditing(false);
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-semibold tracking-tight">Your matches</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => load(profileId)}>
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setEditing(true)}>
            <Pencil className="h-3.5 w-3.5" /> Edit profile
          </Button>
        </div>
      </div>
      {error && <p className="mt-4 rounded-xl border border-red-500/20 bg-red-500/5 p-3 text-sm text-red-200">{error}</p>}
      <div className="mt-6 space-y-4">
        {matches === null ? (
          <>
            <Skeleton className="h-64" />
            <Skeleton className="h-64" />
          </>
        ) : matches.length === 0 ? (
          <div className="rounded-2xl border bg-card/70 p-8 text-center text-muted-foreground">
            No matches yet — as more people join, they&apos;ll appear here.
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {matches.slice(0, 10).map((m) => (
              <MatchCard key={m.id} match={m} signedIn={signedIn} onSkip={() => setMatches((prev) => (prev ?? []).filter((x) => x.id !== m.id))} />
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}

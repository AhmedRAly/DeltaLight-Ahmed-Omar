import Link from "next/link";
import { Avatar } from "@/components/ui/misc";
import type { Json } from "@/lib/database.types";
import { num } from "@/lib/utils";

export type Circle = {
  id: string;
  slug: string;
  name: string;
  description: string;
  path: string;
  member_count: number;
  members: { id: string; name: string; headline: string | null }[];
};

export function parseCircles(json: Json | null): Circle[] {
  if (!Array.isArray(json)) return [];
  return json
    .filter((c): c is { [key: string]: Json | undefined } => Boolean(c) && typeof c === "object" && !Array.isArray(c))
    .map((c) => ({
      id: String(c.id ?? ""),
      slug: String(c.slug ?? ""),
      name: String(c.name ?? ""),
      description: String(c.description ?? ""),
      path: String(c.path ?? "both"),
      member_count: num(c.member_count) ?? 0,
      members: Array.isArray(c.members)
        ? c.members
            .filter((m): m is { [key: string]: Json | undefined } => Boolean(m) && typeof m === "object" && !Array.isArray(m))
            .map((m) => ({ id: String(m.id ?? ""), name: String(m.name ?? ""), headline: m.headline ? String(m.headline) : null }))
        : [],
    }));
}

export function Circles({ circles }: { circles: Circle[] }) {
  if (circles.length === 0) return null;
  return (
    <section>
      <h2 className="text-2xl font-semibold tracking-tight">Circles</h2>
      <p className="mt-1 text-muted-foreground">People auto-grouped by goal similarity.</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {circles.map((c) => (
          <div key={c.id} className="rounded-2xl border bg-card/70 p-5">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-semibold">{c.name}</h3>
              <span className="shrink-0 rounded-full border px-2 py-0.5 text-xs text-muted-foreground">{c.member_count} people</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{c.description}</p>
            <div className="mt-4 flex -space-x-2">
              {c.members.map((m) => (
                <Link key={m.id} href={`/partners/${m.id}`} title={m.name} className="rounded-full ring-2 ring-card">
                  <Avatar name={m.name} size={32} />
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

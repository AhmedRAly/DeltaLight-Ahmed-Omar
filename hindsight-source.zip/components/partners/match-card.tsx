"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Loader2, MapPin, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { Avatar } from "@/components/ui/misc";
import { LOOKING_FOR_LABEL, STAGE_LABEL, type LookingFor, type Stage } from "@/lib/constants";
import type { PartnerMatch } from "@/lib/database.types";
import type { MatchExplanation } from "@/lib/partners";

export type MatchWithWhy = PartnerMatch & { explanation: MatchExplanation };

function Bar({ label, value, weight }: { label: string; value: number; weight: string }) {
  return (
    <div>
      <div className="flex justify-between text-[11px] text-muted-foreground">
        <span>{label}</span>
        <span>{weight}</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
        <motion.div initial={{ width: 0 }} animate={{ width: `${Math.round(value * 100)}%` }} transition={{ duration: 0.9 }} className="h-full rounded-full bg-primary/80" />
      </div>
    </div>
  );
}

export function MatchCard({
  match,
  signedIn,
  onSkip,
  onConnected,
}: {
  match: MatchWithWhy;
  signedIn: boolean;
  onSkip: () => void;
  onConnected?: () => void;
}) {
  const [composing, setComposing] = useState(false);
  const [message, setMessage] = useState(
    `Hi ${match.name.split(" ")[0]} — Hindsight matched us${match.explanation.youNeed.length ? ` (you've got ${match.explanation.youNeed.slice(0, 2).join(" and ")}, which I need)` : ""}. Want to compare notes?`
  );
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState<string | null>(null);
  const pct = Math.round(match.score * 100);

  async function connect() {
    setState("sending");
    setError(null);
    try {
      const res = await fetch("/api/connections", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ to_user: match.id, message, match_score: Math.min(1, Math.max(0, match.score)) }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not connect.");
      setState("sent");
      onConnected?.();
    } catch (err) {
      setError((err as Error).message);
      setState("error");
    }
  }

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -40, transition: { duration: 0.2 } }}
      className="rounded-2xl border bg-card/80 p-5 md:p-6"
    >
      <div className="flex items-start gap-4">
        <Avatar name={match.name} src={match.avatar_url} size={56} />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <Link href={`/partners/${match.id}`} className="text-lg font-semibold hover:text-primary">
                {match.name}
              </Link>
              <p className="line-clamp-2 text-sm text-muted-foreground">{match.headline}</p>
            </div>
            <div className="shrink-0 text-right">
              <div className="text-3xl font-semibold tabular-nums text-primary">{pct}%</div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">match</div>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {match.city && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3 w-3" /> {match.city}
              </span>
            )}
            <span>{STAGE_LABEL[match.stage as Stage] ?? match.stage}</span>
            <span>{match.hours_per_week} h/week</span>
            {match.looking_for.slice(0, 2).map((l) => (
              <span key={l}>· {LOOKING_FOR_LABEL[l as LookingFor] ?? l}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-5 rounded-xl border bg-secondary/30 p-4">
        <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Why you match</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div>
            <p className="text-xs text-muted-foreground">You need → they have</p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {match.explanation.youNeed.length ? (
                match.explanation.youNeed.map((s) => (
                  <span key={s} className="rounded-md bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-300">{s}</span>
                ))
              ) : (
                <span className="text-xs text-muted-foreground">—</span>
              )}
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">They need → you have</p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {match.explanation.theyNeed.length ? (
                match.explanation.theyNeed.map((s) => (
                  <span key={s} className="rounded-md bg-primary/15 px-2 py-0.5 text-xs text-primary">{s}</span>
                ))
              ) : (
                <span className="text-xs text-muted-foreground">—</span>
              )}
            </div>
          </div>
        </div>
        <p className="mt-3 text-sm leading-relaxed text-foreground/85">{match.explanation.sentence}</p>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <Bar label="Goals" value={match.goal_score} weight="50%" />
          <Bar label="Skills" value={match.skill_score} weight="35%" />
          <Bar label="Fit" value={match.fit_score} weight="15%" />
        </div>
      </div>

      {state === "sent" ? (
        <div className="mt-4 flex items-center justify-between gap-2 text-sm text-emerald-300">
          <span className="flex items-center gap-2">
            <Check className="h-4 w-4" /> {match.is_seed ? "Connected — say hi in Connections." : "Request sent."}
          </span>
          <Link href="/connections" className="text-foreground/80 underline-offset-4 hover:underline">
            Open connections
          </Link>
        </div>
      ) : composing ? (
        <div className="mt-4 space-y-2">
          <Textarea value={message} onChange={(e) => setMessage(e.target.value)} maxLength={500} className="min-h-[80px]" />
          {error && (
            <p className="text-sm text-red-300">
              {error}{" "}
              {!signedIn && (
                <Link href="/login?next=/partners" className="text-primary underline">
                  Sign in
                </Link>
              )}
            </p>
          )}
          <div className="flex gap-2">
            <Button onClick={connect} disabled={state === "sending"} className="flex-1">
              {state === "sending" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Send intro
            </Button>
            <Button variant="ghost" onClick={() => setComposing(false)}>
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-4 flex gap-2">
          {signedIn ? (
            <Button className="flex-1" onClick={() => setComposing(true)}>
              Connect
            </Button>
          ) : (
            <Button asChild className="flex-1">
              <Link href="/login?next=/partners">Sign in to connect</Link>
            </Button>
          )}
          <Button variant="secondary" onClick={onSkip}>
            Skip
          </Button>
        </div>
      )}
    </motion.article>
  );
}

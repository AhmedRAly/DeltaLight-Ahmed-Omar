"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";

export function ConnectButton({
  toUser,
  name,
  signedIn,
  hasProfile,
  score,
}: {
  toUser: string;
  name: string;
  signedIn: boolean;
  hasProfile: boolean;
  score: number | null;
}) {
  const [msg, setMsg] = useState(`Hi ${name.split(" ")[0]} — I think we're working toward similar things. Want to compare notes?`);
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = useState<string | null>(null);

  if (!signedIn) {
    return (
      <Button asChild size="lg">
        <Link href={`/login?next=/partners/${toUser}`}>Sign in to connect</Link>
      </Button>
    );
  }
  if (!hasProfile) {
    return (
      <Button asChild size="lg">
        <Link href="/partners">Create your goal profile to connect</Link>
      </Button>
    );
  }
  if (state === "sent") {
    return (
      <div className="flex items-center gap-3 text-emerald-300">
        <Check className="h-5 w-5" /> Request sent.
        <Link href="/connections" className="text-foreground underline-offset-4 hover:underline">
          Open connections
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-3 rounded-2xl border bg-card/70 p-5">
      <Textarea value={msg} onChange={(e) => setMsg(e.target.value)} maxLength={500} />
      {error && <p className="text-sm text-red-300">{error}</p>}
      <Button
        size="lg"
        disabled={state === "sending"}
        onClick={async () => {
          setState("sending");
          setError(null);
          const res = await fetch("/api/connections", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ to_user: toUser, message: msg, match_score: score === null ? null : Math.min(1, Math.max(0, score)) }),
          }).catch(() => null);
          if (res && res.ok) setState("sent");
          else {
            const j = res ? await res.json().catch(() => ({})) : {};
            setError((j as { error?: string }).error ?? "Couldn't connect. Try again.");
            setState("idle");
          }
        }}
      >
        {state === "sending" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Connect with {name.split(" ")[0]}
      </Button>
    </div>
  );
}

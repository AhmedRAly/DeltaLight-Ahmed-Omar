"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import type { MatchWithWhy } from "@/components/partners/match-card";
import { GUEST_KEY } from "@/components/partners/profile-form";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Avatar, Segmented, TagInput } from "@/components/ui/misc";
import { PATHS, type PathKind } from "@/lib/constants";
import { SKILL_SUGGESTIONS } from "@/lib/partners";

export function QuickForm({ room }: { room?: string }) {
  const [name, setName] = useState("");
  const [path, setPath] = useState<PathKind>("business");
  const [goals, setGoals] = useState("");
  const [have, setHave] = useState<string[]>([]);
  const [need, setNeed] = useState<string[]>([]);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [matches, setMatches] = useState<MatchWithWhy[] | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);
    try {
      const res = await fetch("/api/partners/quick", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, path, goals, skills_have: have, skills_need: need, room_code: room || null }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not save.");
      try {
        localStorage.setItem(GUEST_KEY, json.id);
      } catch {
        // storage unavailable
      }
      setMatches(json.matches);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setPending(false);
    }
  }

  if (matches) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">You&apos;re in{room ? ` room ${room}` : ""}. Your top matches:</h2>
        {matches.length === 0 && <p className="text-muted-foreground">No matches yet — watch the big screen.</p>}
        {matches.map((m, i) => (
          <motion.div
            key={m.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="rounded-2xl border bg-card/80 p-4"
          >
            <div className="flex items-center gap-3">
              <Avatar name={m.name} size={44} />
              <div className="min-w-0 flex-1">
                <div className="font-medium">{m.name}</div>
                <div className="line-clamp-1 text-sm text-muted-foreground">{m.headline ?? m.goals}</div>
              </div>
              <div className="text-2xl font-semibold text-primary">{Math.round(m.score * 100)}%</div>
            </div>
            <p className="mt-3 text-sm text-foreground/85">{m.explanation.sentence}</p>
          </motion.div>
        ))}
        <Button asChild variant="secondary" className="w-full">
          <Link href="/partners">See all matches</Link>
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-6">
      <div>
        <Label htmlFor="qname">Your name</Label>
        <Input id="qname" value={name} onChange={(e) => setName(e.target.value)} required maxLength={60} placeholder="First name is fine" />
      </div>
      <div>
        <Label>Path</Label>
        <Segmented options={PATHS} value={path} onChange={setPath} labels={{ business: "Business", corporate: "Corporate", both: "Both" }} />
      </div>
      <div>
        <Label htmlFor="qgoals">What are you working toward?</Label>
        <Textarea id="qgoals" value={goals} onChange={(e) => setGoals(e.target.value)} required maxLength={400} placeholder="Launch my first SaaS and get 10 paying customers." />
      </div>
      <div>
        <Label>Skills you have</Label>
        <TagInput value={have} onChange={setHave} placeholder="e.g. react" suggestions={SKILL_SUGGESTIONS.slice(0, 8)} />
      </div>
      <div>
        <Label>Skills you need</Label>
        <TagInput value={need} onChange={setNeed} placeholder="e.g. sales" suggestions={SKILL_SUGGESTIONS.slice(3, 11)} />
      </div>
      {error && <p className="text-sm text-red-300">{error}</p>}
      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending && <Loader2 className="h-4 w-4 animate-spin" />} Match me
      </Button>
    </form>
  );
}

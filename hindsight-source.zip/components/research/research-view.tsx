"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight, ArrowUpRight, Check, CircleAlert, Clock, Database, Loader2, MessageSquarePlus, Minus, Search, Sparkles, Users } from "lucide-react";
import { ChartLegend, ForecastGapChart } from "@/components/ask/forecast-gap-chart";
import { RecentSearches } from "@/components/research/recent-searches";
import { SourceBadge } from "@/components/stories/source-badge";
import { StoryCard } from "@/components/stories/story-card";
import { CountUp, SampleDataNote, Skeleton } from "@/components/ui/misc";
import type { StoryMatch } from "@/lib/database.types";
import type { Insights } from "@/lib/hindsight";
import {
  hostOf,
  keywords,
  REJECT_LABEL,
  RESEARCH_SOURCES,
  SOURCE_LABEL,
  sortEvidence,
  type Evidence,
  type ResearchSourceKey,
  type SortMode,
  type SourceReport,
  type SourceResponse,
} from "@/lib/research";
import { cn, timeAgo } from "@/lib/utils";

type SourceState = { status: "loading" | "ok" | "error" | "skipped"; items: Evidence[]; report?: SourceReport };
type Community = { mode: "vector" | "text"; insights: Insights; stories: StoryMatch[] };

const KIND_LABEL = { story: "Post", comment: "Comment", question: "Question", post: "Post", answer: "Top answer" } as const;
const PAGE = 10;

export function ResearchView({ q }: { q: string }) {
  const router = useRouter();
  const [draft, setDraft] = useState(q);
  const [sources, setSources] = useState<Record<ResearchSourceKey, SourceState>>(initial());
  const [community, setCommunity] = useState<Community | null | undefined>(undefined);
  const [summary, setSummary] = useState<string | null | undefined>(undefined);
  const [sort, setSort] = useState<SortMode>("relevant");
  const [only, setOnly] = useState<string | null>(null);
  const [visible, setVisible] = useState(PAGE);

  useEffect(() => {
    setDraft(q);
    if (!q) return;
    let cancelled = false;
    setSources(initial());
    setCommunity(undefined);
    setSummary(undefined);
    setOnly(null);
    setVisible(PAGE);

    const results: Partial<Record<ResearchSourceKey, Evidence[]>> = {};
    let pending = RESEARCH_SOURCES.length;

    for (const key of RESEARCH_SOURCES) {
      fetch(`/api/research?source=${key}&q=${encodeURIComponent(q)}`)
        .then(async (res) => {
          if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? `HTTP ${res.status}`);
          return (await res.json()) as SourceResponse;
        })
        .then((r) => {
          if (cancelled) return;
          results[key] = r.items;
          setSources((s) => ({ ...s, [key]: { status: r.report.status, items: r.items, report: r.report } }));
        })
        .catch((e: Error) => {
          if (cancelled) return;
          results[key] = [];
          setSources((s) => ({
            ...s,
            [key]: { status: "error", items: [], report: errReport(key, q, e.message) },
          }));
        })
        .finally(() => {
          if (cancelled) return;
          pending -= 1;
          if (pending > 0) return;
          const merged = mergeEvidence(results);
          fetch("/api/history", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ q, count: merged.length }) }).catch(() => null);
          if (merged.length < 2) {
            setSummary(null);
            return;
          }
          fetch("/api/research/summary", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              q,
              items: merged.slice(0, 12).map((e) => ({ title: e.title.slice(0, 280), excerpt: e.excerpt.slice(0, 560), sourceName: e.sourceName })),
            }),
          })
            .then((r) => (r.ok ? r.json() : { summary: null }))
            .then((j) => !cancelled && setSummary(j.summary ?? null))
            .catch(() => !cancelled && setSummary(null));
        });
    }

    fetch("/api/ask", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ q }) })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => !cancelled && setCommunity(j))
      .catch(() => !cancelled && setCommunity(null));

    return () => {
      cancelled = true;
    };
  }, [q]);

  const allDone = RESEARCH_SOURCES.every((k) => sources[k].status !== "loading");
  const pool = useMemo(() => {
    const r: Partial<Record<ResearchSourceKey, Evidence[]>> = {};
    for (const k of RESEARCH_SOURCES) r[k] = sources[k].items;
    return mergeEvidence(r);
  }, [sources]);
  const evidence = useMemo(() => {
    const filtered = only ? pool.filter((e) => e.sourceId === only) : pool;
    return sortEvidence(filtered, sort);
  }, [pool, only, sort]);
  const sourceCounts = useMemo(() => {
    const m = new Map<string, { name: string; n: number }>();
    for (const e of pool) m.set(e.sourceId, { name: e.sourceName.replace(/ \(Stack Exchange\)/, " SE"), n: (m.get(e.sourceId)?.n ?? 0) + 1 });
    return Array.from(m.entries());
  }, [pool]);
  const kws = useMemo(() => keywords(q), [q]);

  return (
    <div className="container max-w-6xl py-8 md:py-12">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const v = draft.trim();
          if (v.length >= 3 && v !== q) router.push(`/ask?q=${encodeURIComponent(v)}`);
        }}
        className="mx-auto flex max-w-3xl items-center gap-2 rounded-full border bg-card/80 py-1.5 pl-5 pr-1.5 shadow-lg shadow-black/30 transition focus-within:border-primary/50"
      >
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="What do you need advice for?"
          aria-label="What do you need advice for?"
          className="h-10 min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground/60"
        />
        <button className="flex h-10 items-center gap-1.5 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground hover:brightness-110">
          Ask <ArrowRight className="h-4 w-4" />
        </button>
      </form>

      {!q ? (
        <div className="mt-24 text-center text-muted-foreground">
          <p className="font-serif text-3xl italic text-foreground">What do you need advice for?</p>
          <p className="mt-3">Ask anything you&apos;re deciding. We&apos;ll pull real posts from people who&apos;ve been there.</p>
          <RecentSearches className="mx-auto mt-10 max-w-2xl text-left" />
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1fr)_330px]">
          <main className="min-w-0 space-y-8">
            <header>
              <p className="text-xs uppercase tracking-[0.2em] text-primary">Your question</p>
              <h1 className="mt-2 font-serif text-3xl italic leading-tight tracking-tight md:text-4xl">{q}</h1>
              <div className="mt-5 flex flex-wrap gap-2">
                {RESEARCH_SOURCES.filter((k) => sources[k].status !== "skipped").map((k) => (
                  <SourceChip key={k} k={k} s={sources[k]} />
                ))}
              </div>
            </header>

            <AnswerCard summary={summary} evidence={pool} allDone={allDone} kws={kws} />

            <section>
              <div className="flex flex-wrap items-end justify-between gap-3">
                <h2 className="text-lg font-semibold tracking-tight">
                  Sources <span className="text-muted-foreground">{allDone ? evidence.length : ""}</span>
                </h2>
                <div className="flex items-center gap-1 rounded-full border bg-card/60 p-0.5 text-xs" role="group" aria-label="Sort sources">
                  {(
                    [
                      ["relevant", "Most relevant", Sparkles],
                      ["recent", "Most recent", Clock],
                    ] as const
                  ).map(([id, label, Icon]) => (
                    <button
                      key={id}
                      type="button"
                      aria-pressed={sort === id}
                      onClick={() => setSort(id)}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 transition",
                        sort === id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Icon className="h-3 w-3" /> {label}
                    </button>
                  ))}
                </div>
              </div>
              {sourceCounts.length > 1 && (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <FilterPill active={only === null} onClick={() => setOnly(null)} label="All" n={pool.length} />
                  {sourceCounts.map(([id, v]) => (
                    <FilterPill key={id} active={only === id} onClick={() => setOnly(only === id ? null : id)} label={v.name} n={v.n} />
                  ))}
                </div>
              )}
              <div className="mt-4 space-y-3">
                {evidence.slice(0, visible).map((e) => (
                  <EvidenceCard key={e.externalId} n={pool.indexOf(e) + 1} e={e} kws={kws} />
                ))}
                {evidence.length > visible && (
                  <button
                    onClick={() => setVisible((v) => v + PAGE)}
                    className="w-full rounded-xl border border-dashed py-3 text-sm text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
                  >
                    Show {Math.min(PAGE, evidence.length - visible)} more
                  </button>
                )}
                {!allDone && evidence.length === 0 && (
                  <>
                    <Skeleton className="h-36" />
                    <Skeleton className="h-36" />
                    <Skeleton className="h-36" />
                  </>
                )}
                {allDone && evidence.length === 0 && (
                  <div className="rounded-2xl border bg-card/60 p-8 text-center text-muted-foreground">
                    <CircleAlert className="mx-auto h-6 w-6" />
                    <p className="mt-3 text-foreground">No public posts matched closely enough.</p>
                    <p className="mt-1 text-sm">Try describing your situation with more specifics, like your role, field or what is at stake.</p>
                  </div>
                )}
              </div>
            </section>

            <CommunityPanel community={community} query={q} />
          </main>

          <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
            <Provenance sources={sources} allDone={allDone} />
            <Voices pool={pool} />
            <Link
              href={`/community/ask?title=${encodeURIComponent(q.slice(0, 200))}`}
              className="group block rounded-2xl border bg-card/70 p-5 transition hover:border-primary/40"
            >
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <MessageSquarePlus className="h-4 w-4 text-primary" /> Ask the community
              </div>
              <p className="mt-2 text-sm text-foreground/75">Want a direct answer? Post this question and let real people respond, anonymously.</p>
              <p className="mt-3 inline-flex items-center gap-1 text-sm text-primary">
                Post it <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </p>
            </Link>
            <Link
              href="/business"
              className="group block rounded-2xl border bg-gradient-to-br from-primary/10 to-transparent p-5 transition hover:border-primary/40"
            >
              <div className="flex items-center gap-2 text-sm font-medium text-primary">
                <Users className="h-4 w-4" /> Hindsight Business
              </div>
              <p className="mt-2 text-sm text-foreground/80">Find co-founders, mentors and accountability partners facing the same decision.</p>
              <p className="mt-3 inline-flex items-center gap-1 text-sm text-primary">
                Meet them <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </p>
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
}

function initial(): Record<ResearchSourceKey, SourceState> {
  return Object.fromEntries(RESEARCH_SOURCES.map((k) => [k, { status: "loading", items: [] }])) as unknown as Record<ResearchSourceKey, SourceState>;
}

function errReport(key: ResearchSourceKey, q: string, error: string): SourceReport {
  return { key, label: SOURCE_LABEL[key], requestUrl: "", status: "error", fetched: 0, kept: 0, stored: 0, rejected: 0, rejectedReasons: {}, ms: 0, error };
}

/** Rank by relevance but cap each site so one source cannot crowd out the rest. */
function mergeEvidence(by: Partial<Record<ResearchSourceKey, Evidence[]>>): Evidence[] {
  const all = Object.values(by).flat().filter((e): e is Evidence => Boolean(e));
  const seen = new Set<string>();
  const perSite = new Map<string, number>();
  return all
    .sort((a, b) => b.relevance - a.relevance)
    .filter((e) => {
      if (seen.has(e.externalId)) return false;
      seen.add(e.externalId);
      const n = perSite.get(e.sourceId) ?? 0;
      if (n >= 10) return false;
      perSite.set(e.sourceId, n + 1);
      return true;
    })
    .slice(0, 36);
}

function SourceChip({ k, s }: { k: ResearchSourceKey; s: SourceState }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs transition",
        s.status === "ok" && "border-emerald-500/25 bg-emerald-500/5 text-foreground/90",
        s.status === "error" && "border-red-500/25 bg-red-500/5 text-red-300",
        s.status === "skipped" && "border-dashed text-muted-foreground/70",
        s.status === "loading" && "text-muted-foreground"
      )}
      title={s.report?.error}
    >
      {s.status === "loading" && <Loader2 className="h-3 w-3 animate-spin" />}
      {s.status === "ok" && <Check className="h-3 w-3 text-emerald-400" />}
      {s.status === "error" && <CircleAlert className="h-3 w-3" />}
      {s.status === "skipped" && <Minus className="h-3 w-3" />}
      {SOURCE_LABEL[k]}
      {s.status === "ok" && <span className="text-muted-foreground">· {s.items.length}</span>}
    </span>
  );
}

function FilterPill({ active, onClick, label, n }: { active: boolean; onClick: () => void; label: string; n: number }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-full border px-2.5 py-1 text-xs transition",
        active ? "border-primary/50 bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {label} <span className="opacity-60">{n}</span>
    </button>
  );
}

function Voices({ pool }: { pool: Evidence[] }) {
  const seen = new Set<string>();
  const voices = pool
    .filter((e) => e.author && !seen.has(`${e.sourceId}:${e.author}`) && (seen.add(`${e.sourceId}:${e.author}`), true))
    .slice(0, 6);
  if (voices.length === 0) return null;
  return (
    <section className="rounded-2xl border bg-card/70 p-5">
      <h2 className="text-sm font-semibold tracking-tight">Voices in these sources</h2>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">Public handles of the people who wrote the matched posts. Read what they said in full.</p>
      <ul className="mt-3 space-y-2">
        {voices.map((e) => (
          <li key={`${e.sourceId}:${e.author}`}>
            <a
              href={e.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-sm transition hover:bg-secondary"
            >
              <span className="min-w-0 truncate">
                <span className="text-foreground/90">{e.author}</span>
                <span className="text-muted-foreground"> · {e.sourceName.replace(/ \(Stack Exchange\)/, " SE")}</span>
              </span>
              <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground transition group-hover:text-primary" />
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}

function AnswerCard({ summary, evidence, allDone, kws }: { summary: string | null | undefined; evidence: Evidence[]; allDone: boolean; kws: string[] }) {
  const sourcesUsed = new Set(evidence.map((e) => e.sourceName)).size;
  return (
    <section className="rounded-2xl border bg-gradient-to-br from-primary/[0.07] via-card/60 to-card/60 p-6">
      <div className="flex items-center gap-2 text-sm font-medium text-primary">
        <Sparkles className="h-4 w-4" /> What people who&apos;ve been there say
      </div>
      {!allDone || (summary === undefined && evidence.length >= 2) ? (
        <div className="mt-4 space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-11/12" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      ) : summary ? (
        <>
          <p className="mt-3 text-[17px] leading-relaxed text-foreground/90">{renderCited(summary, evidence.length)}</p>
          <p className="mt-3 text-xs text-muted-foreground">Written only from the excerpts below. Numbers link to the exact source.</p>
        </>
      ) : evidence.length > 0 ? (
        <Takeaways evidence={evidence} kws={kws} sourcesUsed={sourcesUsed} />
      ) : (
        <p className="mt-3 text-muted-foreground">Nothing close enough to summarize yet.</p>
      )}
    </section>
  );
}

function Takeaways({ evidence, kws, sourcesUsed }: { evidence: Evidence[]; kws: string[]; sourcesUsed: number }) {
  const quotes = pickQuotes(evidence, kws);
  const firsthand = evidence.filter((e) => e.firsthand).length;
  return (
    <>
      <p className="mt-3 text-[15px] text-foreground/80">
        <span className="font-medium text-foreground">{evidence.length}</span> relevant posts across{" "}
        <span className="font-medium text-foreground">{sourcesUsed}</span> sources
        {firsthand > 0 && (
          <>
            , <span className="font-medium text-foreground">{firsthand}</span> written firsthand
          </>
        )}
        . In their own words:
      </p>
      <ul className="mt-4 space-y-3">
        {quotes.map((q) => (
          <li key={q.n} className="border-l-2 border-primary/40 pl-4">
            <p className="text-[16px] leading-relaxed text-foreground/90">&ldquo;{q.text}&rdquo;</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {q.author ?? "Anonymous"}, {q.source}
              {renderCited(`[${q.n}]`, evidence.length)}
            </p>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-xs text-muted-foreground">Verbatim excerpts from the sources below. Numbers jump to the full post.</p>
    </>
  );
}

function pickQuotes(evidence: Evidence[], kws: string[]) {
  const quotes: { n: number; text: string; author: string | null; source: string }[] = [];
  const usedSources = new Map<string, number>();
  const ranked = evidence.map((e, i) => ({ e, n: i + 1 })).slice(0, 14);
  ranked.sort((a, b) => Number(b.e.firsthand) - Number(a.e.firsthand) || b.e.relevance - a.e.relevance);
  for (const { e, n } of ranked) {
    if (quotes.length >= 3) break;
    if ((usedSources.get(e.sourceId) ?? 0) >= 2) continue;
    const all = e.excerpt
      .replace(/^…\s*/, "")
      .split(/(?<=[.!?])\s+/)
      .map((x) => x.replace(/^[>\s"“”]+/, "").trim())
      .filter((x) => x.length >= 50 && x.length <= 280);
    // Prefer complete sentences (ending in punctuation) so quotes never trail off mid-thought.
    const complete = all.filter((x) => /[.!?]["”']?$/.test(x));
    const sentences = complete.length > 0 ? complete : all;
    if (sentences.length === 0) continue;
    const best = sentences
      .map((t) => ({ t, hits: kws.filter((k) => t.toLowerCase().includes(k)).length }))
      .sort((a, b) => b.hits - a.hits)[0];
    if (best.hits === 0 && quotes.length > 0) continue;
    quotes.push({ n, text: best.t.replace(/…$/, "").trim(), author: e.author, source: e.sourceName.replace(/ \(Stack Exchange\)/, "") });
    usedSources.set(e.sourceId, (usedSources.get(e.sourceId) ?? 0) + 1);
  }
  return quotes;
}

function renderCited(text: string, max: number) {
  return text.split(/(\[\d+\])/g).map((part, i) => {
    const m = part.match(/^\[(\d+)\]$/);
    if (!m) return <span key={i}>{part}</span>;
    const n = Number(m[1]);
    if (n < 1 || n > max) return null;
    return (
      <a
        key={i}
        href={`#src-${n}`}
        className="cite"
        onClick={(ev) => {
          ev.preventDefault();
          const el = document.getElementById(`src-${n}`);
          el?.scrollIntoView({ behavior: "smooth", block: "center" });
          el?.classList.add("ring-2", "ring-primary/60");
          setTimeout(() => el?.classList.remove("ring-2", "ring-primary/60"), 1600);
        }}
      >
        {n}
      </a>
    );
  });
}

function Highlighted({ text, kws }: { text: string; kws: string[] }) {
  if (kws.length === 0) return <>{text}</>;
  const re = new RegExp(`(${kws.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`, "gi");
  return (
    <>
      {text.split(re).map((part, i) =>
        i % 2 === 1 ? (
          <mark key={i} className="rounded bg-primary/20 px-0.5 text-foreground">
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </>
  );
}

function EvidenceCard({ n, e, kws }: { n: number; e: Evidence; kws: string[] }) {
  return (
    <motion.article
      id={`src-${n}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: Math.min(n, 6) * 0.04 }}
      className="scroll-mt-24 rounded-2xl border bg-card/70 p-5 transition-shadow hover:border-white/15"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary/15 text-xs font-semibold text-primary">{n}</span>
        <SourceBadge sourceId={e.sourceId} url={e.url} />
        <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">{KIND_LABEL[e.kind]}</span>
        {e.deep && (
          <span className="rounded-full border border-sky-500/25 bg-sky-500/5 px-2 py-0.5 text-[11px] text-sky-300" title="Pulled from inside the discussion, not just the headline">
            Deep read
          </span>
        )}
        {e.firsthand && (
          <span className="rounded-full border border-emerald-500/25 bg-emerald-500/5 px-2 py-0.5 text-[11px] text-emerald-400" title="Written in the first person and mentions what happened">
            Firsthand
          </span>
        )}
        <span className="ml-auto text-[11px] text-muted-foreground">{Math.round(e.relevance * 100)}% match</span>
      </div>
      <h3 className="mt-3 text-[17px] font-medium leading-snug tracking-tight">
        {e.kind === "comment" && <span className="font-normal text-muted-foreground">Comment on: </span>}
        {e.title}
      </h3>
      <p className="mt-2 text-[14.5px] leading-relaxed text-foreground/75">
        <Highlighted text={e.excerpt} kws={kws} />
      </p>
      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
        {e.author && <span>by {e.author}</span>}
        {e.postedAt && <span>{timeAgo(e.postedAt)}</span>}
        {e.score > 0 && <span>{e.score} pts</span>}
        <span className="ml-auto flex items-center gap-2">
          {e.rawId && (
            <Link
              href={`/source/${e.rawId}`}
              className="inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-foreground/80 transition hover:border-primary/40 hover:text-foreground"
            >
              <Database className="h-3.5 w-3.5" /> Raw record
            </Link>
          )}
          <a
            href={e.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-primary transition hover:bg-primary/20"
          >
            {hostOf(e.url)} <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </span>
      </div>
    </motion.article>
  );
}

function Provenance({ sources, allDone }: { sources: Record<ResearchSourceKey, SourceState>; allDone: boolean }) {
  const totals = RESEARCH_SOURCES.reduce(
    (t, k) => {
      const r = sources[k].report;
      return r ? { fetched: t.fetched + r.fetched, kept: t.kept + r.kept, rejected: t.rejected + r.rejected } : t;
    },
    { fetched: 0, kept: 0, rejected: 0 }
  );
  return (
    <section className="rounded-2xl border bg-card/70 p-5">
      <h2 className="text-sm font-semibold tracking-tight">How this was gathered</h2>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
        Live requests to public APIs, made when you asked. Every record is validated, then saved so you can inspect it.
      </p>
      {allDone && (
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[
            ["returned", totals.fetched],
            ["rejected", totals.rejected],
            ["kept", totals.kept],
          ].map(([label, n]) => (
            <div key={label as string} className="rounded-lg border bg-background/40 py-2">
              <div className="text-lg font-semibold tabular-nums">{n}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
            </div>
          ))}
        </div>
      )}
      <ul className="mt-4 space-y-4">
        {RESEARCH_SOURCES.filter((k) => sources[k].status !== "skipped").map((k) => {
          const s = sources[k];
          const r = s.report;
          const reasons = r ? Object.entries(r.rejectedReasons) : [];
          const linkable = r?.requestUrl && !r.requestUrl.includes("oauth.reddit.com");
          return (
            <li key={k} className="text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium text-foreground/90">{SOURCE_LABEL[k]}</span>
                {s.status === "loading" ? (
                  <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
                ) : (
                  <span className={s.status === "ok" ? "text-emerald-400" : s.status === "skipped" ? "text-muted-foreground" : "text-red-400"}>
                    {s.status === "ok" ? (r?.cached ? "ok · cached" : "ok") : s.status === "skipped" ? "off" : "failed"}
                  </span>
                )}
              </div>
              {r && r.status === "ok" && (
                <p className="mt-1 text-muted-foreground">
                  {r.fetched} returned · {r.rejected} rejected · {r.kept} kept · {r.ms} ms
                </p>
              )}
              {reasons.length > 0 && (
                <p className="mt-0.5 text-[11px] text-muted-foreground/80">
                  Rejected: {reasons.map(([why, n]) => `${n} ${REJECT_LABEL[why] ?? why}`).join(", ")}
                </p>
              )}
              {r?.error && <p className={cn("mt-1", s.status === "skipped" ? "text-muted-foreground" : "text-red-300/80")}>{r.error}</p>}
              {r?.requestUrl &&
                (linkable ? (
                  <a
                    href={r.requestUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 block truncate font-mono text-[11px] text-muted-foreground underline-offset-2 hover:text-primary hover:underline"
                    title={r.requestUrl}
                  >
                    {r.requestUrl.replace(/^https:\/\//, "")}
                  </a>
                ) : (
                  <p className="mt-1 truncate font-mono text-[11px] text-muted-foreground/70" title={r.requestUrl}>
                    {r.requestUrl.replace(/^https:\/\//, "")}
                  </p>
                ))}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function CommunityPanel({ community, query }: { community: Community | null | undefined; query: string }) {
  if (community === undefined) return <Skeleton className="h-48" />;
  if (!community) return null;
  const { insights: ins, stories } = community;
  const lastPoint = [...ins.by_horizon].reverse().find((p) => p.avg_actual !== null);

  return (
    <>
      {ins.n > 0 && (
        <section className="rounded-2xl border bg-card/70 p-5 md:p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-lg font-semibold tracking-tight">What happened to Hindsight members</h2>
            {ins.n_seed > 0 && <SampleDataNote />}
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            {ins.n} similar logged decisions · {ins.n_with_checkins} with follow-up check-ins.
          </p>
          <div className="mt-5 grid grid-cols-3 gap-3">
            <Stat label="would choose again" value={ins.would_choose_again_pct} suffix="%" />
            <Stat label="avg regret /10" value={ins.avg_regret} decimals={1} />
            <Stat
              label="forecast gap"
              value={ins.forecast_gap}
              decimals={1}
              prefix={ins.forecast_gap !== null && ins.forecast_gap > 0 ? "+" : ""}
            />
          </div>
          <div className="mt-5 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Predicted <span className="text-primary">{ins.avg_predicted?.toFixed(1) ?? "—"}</span>
              {lastPoint && (
                <>
                  , later felt <span className="text-foreground">{lastPoint.avg_actual?.toFixed(1)}</span>
                </>
              )}
            </p>
            <ChartLegend />
          </div>
          <div className="mt-3">
            <ForecastGapChart points={ins.by_horizon} height={240} />
          </div>
        </section>
      )}
      {stories.length > 0 && (
        <section>
          <div className="flex items-end justify-between">
            <h2 className="text-lg font-semibold tracking-tight">Structured stories</h2>
            <Link href="/stories" className="text-sm text-muted-foreground hover:text-foreground">
              All stories →
            </Link>
          </div>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            {stories.slice(0, 4).map((s) => (
              <StoryCard key={s.id} story={s} compact />
            ))}
          </div>
        </section>
      )}
      <div className="flex flex-col items-start justify-between gap-3 rounded-2xl border bg-card/60 p-5 sm:flex-row sm:items-center">
        <p className="text-sm text-foreground/85">Facing this right now? Log your prediction — it makes the next person&apos;s answer better.</p>
        <Link
          href={`/log?text=${encodeURIComponent(query)}`}
          className="shrink-0 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:brightness-110"
        >
          Log your decision
        </Link>
      </div>
    </>
  );
}

function Stat({ label, value, suffix = "", prefix = "", decimals = 0 }: { label: string; value: number | null; suffix?: string; prefix?: string; decimals?: number }) {
  return (
    <div className="rounded-xl border bg-background/40 p-4">
      <CountUp value={value} suffix={suffix} prefix={prefix} decimals={decimals} className="block text-3xl font-semibold tracking-tight" />
      <p className="mt-1 text-[11px] uppercase tracking-wider text-muted-foreground">{label}</p>
    </div>
  );
}

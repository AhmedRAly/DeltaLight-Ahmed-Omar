"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { History } from "lucide-react";

type Item = { q: string; result_count: number; created_at: string };

export function RecentSearches({ className }: { className?: string }) {
  const [items, setItems] = useState<Item[]>([]);
  useEffect(() => {
    fetch("/api/history")
      .then((r) => (r.ok ? r.json() : { items: [] }))
      .then((j) => setItems(j.items ?? []))
      .catch(() => setItems([]));
  }, []);
  if (items.length === 0) return null;
  return (
    <div className={className}>
      <p className="mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider text-muted-foreground">
        <History className="h-3.5 w-3.5" /> Your recent questions
      </p>
      <div className="flex flex-wrap gap-2">
        {items.map((it) => (
          <Link
            key={it.q}
            href={`/ask?q=${encodeURIComponent(it.q)}`}
            className="max-w-full truncate rounded-full border bg-white/[0.03] px-3.5 py-1.5 text-xs text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
          >
            {it.q}
          </Link>
        ))}
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Loader2, RefreshCw } from "lucide-react";

export function LiveRecord({ rawApiUrl }: { rawApiUrl: string }) {
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [json, setJson] = useState("");
  const [fetchedAt, setFetchedAt] = useState("");

  const run = async () => {
    setState("loading");
    try {
      const res = await fetch(rawApiUrl, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setJson(JSON.stringify(data, null, 2).slice(0, 40_000));
      setFetchedAt(new Date().toUTCString());
      setState("done");
    } catch (e) {
      setJson((e as Error).message);
      setState("error");
    }
  };

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Live raw JSON</h2>
          <p className="mt-1 break-all font-mono text-xs text-muted-foreground">{rawApiUrl}</p>
        </div>
        <button
          onClick={run}
          disabled={state === "loading"}
          className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm hover:bg-secondary disabled:opacity-50"
        >
          {state === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          Fetch live JSON
        </button>
      </div>
      {state === "done" && (
        <>
          <p className="mt-3 text-xs text-muted-foreground">Fetched directly from the public API in your browser at {fetchedAt}.</p>
          <pre className="mt-2 max-h-[420px] overflow-auto rounded-2xl border bg-black/40 p-5 font-mono text-xs leading-relaxed text-foreground/80">{json}</pre>
        </>
      )}
      {state === "error" && <p className="mt-3 text-sm text-red-400">Could not fetch it from the browser ({json}). Use the link above instead.</p>}
    </section>
  );
}

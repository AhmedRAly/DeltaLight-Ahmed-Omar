"use client";

import { Area, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { HORIZONS, HORIZON_LABEL, type Horizon } from "@/lib/constants";
import type { HorizonPoint } from "@/lib/hindsight";

type Row = { label: string; predicted: number | null; actual: number | null; n: number };

export function ForecastGapChart({
  points,
  height = 320,
  own,
}: {
  points: HorizonPoint[];
  height?: number;
  own?: { horizon: Horizon; actual: number; predicted: number }[];
}) {
  const byH = new Map(points.map((p) => [p.horizon, p]));
  const ownBy = new Map((own ?? []).map((o) => [o.horizon, o]));
  const data: (Row & { you: number | null })[] = HORIZONS.map((h) => {
    const p = byH.get(h);
    return {
      label: HORIZON_LABEL[h],
      predicted: p?.avg_predicted ?? null,
      actual: p?.avg_actual ?? null,
      n: p?.n ?? 0,
      you: ownBy.get(h)?.actual ?? null,
    };
  });

  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 12, right: 16, left: -16, bottom: 0 }}>
          <defs>
            <linearGradient id="gapFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(148 70% 45%)" stopOpacity={0.28} />
              <stop offset="100%" stopColor="hsl(148 70% 45%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="hsl(240 4% 16%)" strokeDasharray="3 6" vertical={false} />
          <XAxis dataKey="label" stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={13} />
          <YAxis domain={[1, 10]} ticks={[2, 4, 6, 8, 10]} stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={12} />
          <Tooltip
            cursor={{ stroke: "hsl(240 4% 30%)" }}
            contentStyle={{
              background: "hsl(240 5% 8%)",
              border: "1px solid hsl(240 4% 18%)",
              borderRadius: 12,
              color: "white",
              fontSize: 13,
            }}
            formatter={(value) => (typeof value === "number" ? value.toFixed(1) : String(value))}
          />
          <Area
            type="monotone"
            dataKey="predicted"
            name="Predicted happiness"
            stroke="hsl(148 70% 45%)"
            strokeWidth={2.5}
            strokeDasharray="6 6"
            fill="url(#gapFill)"
            connectNulls
            isAnimationActive
            animationDuration={900}
          />
          <Line
            type="monotone"
            dataKey="actual"
            name="Actual happiness"
            stroke="hsl(40 20% 96%)"
            strokeWidth={3}
            dot={{ r: 5, fill: "hsl(40 20% 96%)", strokeWidth: 0 }}
            activeDot={{ r: 7 }}
            connectNulls
            animationDuration={1300}
          />
          {own && own.length > 0 && (
            <Line
              type="monotone"
              dataKey="you"
              name="You"
              stroke="hsl(152 60% 50%)"
              strokeWidth={3}
              dot={{ r: 6, fill: "hsl(152 60% 50%)", strokeWidth: 0 }}
              connectNulls
            />
          )}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ChartLegend({ showYou = false }: { showYou?: boolean }) {
  return (
    <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
      <span className="flex items-center gap-2">
        <span className="h-0.5 w-6 border-t-2 border-dashed border-primary" /> Predicted
      </span>
      <span className="flex items-center gap-2">
        <span className="h-0.5 w-6 bg-foreground" /> Actually felt
      </span>
      {showYou && (
        <span className="flex items-center gap-2">
          <span className="h-0.5 w-6 bg-emerald-400" /> You
        </span>
      )}
    </div>
  );
}

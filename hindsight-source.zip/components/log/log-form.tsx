"use client";

import Link from "next/link";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Check, Loader2, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { CountUp, SampleDataNote, Segmented, Slider } from "@/components/ui/misc";
import { SourceBadge } from "@/components/stories/source-badge";
import { CATEGORIES, type Category } from "@/lib/constants";

type Peek = {
  similar_n: number;
  would_choose_again_pct: number | null;
  avg_actual: number | null;
  forecast_gap: number | null;
  n_seed: number;
  story: { id: string; title: string; url: string; source_id: string; tldr: string } | null;
};

export function LogForm({ initialText = "", room }: { initialText?: string; room?: string }) {
  const [text, setText] = useState(initialText);
  const [category, setCategory] = useState<Category>("career");
  const [options, setOptions] = useState<string[]>(["", ""]);
  const [chosen, setChosen] = useState(0);
  const [predicted, setPredicted] = useState(7);
  const [confidence, setConfidence] = useState(6);
  const [outcome, setOutcome] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ id: string; peek: Peek } | null>(null);

  const cleanOptions = options.map((o) => o.trim()).filter(Boolean);
  const valid = text.trim().length >= 5 && cleanOptions.length >= 1 && options[chosen]?.trim();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid) {
      setError("Describe the decision and at least the option you're choosing.");
      return;
    }
    setPending(true);
    setError(null);
    try {
      const res = await fetch("/api/decisions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          text,
          category,
          options: cleanOptions,
          chosen_option: options[chosen].trim(),
          predicted_happiness: predicted,
          predicted_outcome: outcome || null,
          confidence,
          room_code: room || null,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not save.");
      setResult(json);
      try {
        const mine = JSON.parse(localStorage.getItem("hs_decisions") ?? "[]") as string[];
        localStorage.setItem("hs_decisions", JSON.stringify([json.id, ...mine].slice(0, 20)));
      } catch {
        // localStorage unavailable (private mode) — non-essential
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setPending(false);
    }
  }

  if (result) return <Logged id={result.id} peek={result.peek} room={room} />;

  return (
    <form onSubmit={submit} className="space-y-8">
      <div>
        <Label htmlFor="text">What are you deciding?</Label>
        <Textarea
          id="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="e.g. Quit my consulting job to start a design agency"
          maxLength={600}
          className="min-h-[88px] text-lg md:text-base"
        />
      </div>

      <div>
        <Label>Category</Label>
        <Segmented options={CATEGORIES} value={category} onChange={setCategory} />
      </div>

      <div>
        <Label>Your options — tap the one you&apos;re choosing</Label>
        <div className="space-y-2">
          {options.map((o, i) => (
            <div key={i} className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setChosen(i)}
                aria-label={`Choose option ${i + 1}`}
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border transition ${chosen === i ? "border-primary bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              >
                {chosen === i ? <Check className="h-4 w-4" /> : i + 1}
              </button>
              <Input
                value={o}
                onChange={(e) => setOptions(options.map((x, j) => (j === i ? e.target.value : x)))}
                placeholder={i === 0 ? "e.g. Quit and go full-time" : "e.g. Stay and build on the side"}
                maxLength={120}
              />
              {options.length > 2 && (
                <button
                  type="button"
                  aria-label="Remove option"
                  onClick={() => {
                    setOptions(options.filter((_, j) => j !== i));
                    setChosen(0);
                  }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
          {options.length < 4 && (
            <button type="button" onClick={() => setOptions([...options, ""])} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
              <Plus className="h-4 w-4" /> Add option
            </button>
          )}
        </div>
      </div>

      <div className="rounded-2xl border bg-card/60 p-5">
        <Label>How happy do you predict you&apos;ll be with this choice a year from now?</Label>
        <Slider value={predicted} onChange={setPredicted} lowLabel="miserable" highLabel="thrilled" />
        <div className="mt-6">
          <Label>How confident are you in that prediction?</Label>
          <Slider value={confidence} onChange={setConfidence} lowLabel="wild guess" highLabel="certain" />
        </div>
      </div>

      <div>
        <Label htmlFor="outcome">What do you think will happen? (optional)</Label>
        <Textarea
          id="outcome"
          value={outcome}
          onChange={(e) => setOutcome(e.target.value)}
          placeholder="In a year I expect to have 20 paying clients and feel free."
          maxLength={500}
        />
      </div>

      {error && <p className="rounded-xl border border-red-500/20 bg-red-500/5 p-3 text-sm text-red-200">{error}</p>}

      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
        {pending ? "Matching you with people who already decided…" : "Log my decision"}
      </Button>
      <p className="text-center text-xs text-muted-foreground">Anonymous. We&apos;ll ask how it actually went at 1 week, 1 month, 6 months and 1 year.</p>
    </form>
  );
}

function Logged({ id, peek, room }: { id: string; peek: Peek; room?: string }) {
  return (
    <AnimatePresence>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="rounded-3xl border bg-gradient-to-br from-primary/15 to-transparent p-6 md:p-8">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <Check className="h-6 w-6" />
          </div>
          <h2 className="mt-5 text-3xl font-semibold tracking-tight">Logged{room ? ` to room ${room}` : ""}.</h2>
          {peek.similar_n > 0 ? (
            <p className="mt-3 text-lg text-foreground/85">
              <CountUp value={peek.similar_n} className="font-semibold text-primary" /> people made a decision like yours.
              {peek.would_choose_again_pct !== null && (
                <>
                  {" "}
                  <CountUp value={peek.would_choose_again_pct} suffix="%" className="font-semibold text-primary" /> would do it again
                  {peek.forecast_gap !== null && <>, and they were off by {peek.forecast_gap > 0 ? "+" : ""}{peek.forecast_gap.toFixed(1)} points vs. their prediction</>}.
                </>
              )}
            </p>
          ) : (
            <p className="mt-3 text-lg text-foreground/85">You&apos;re one of the first to make this decision here. Your check-ins will guide the next person.</p>
          )}
          {peek.n_seed > 0 && <SampleDataNote className="mt-3" />}
        </div>

        {peek.story && (
          <div className="rounded-2xl border bg-card/70 p-5">
            <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Closest real story</p>
            <h3 className="mt-2 text-lg font-medium">{peek.story.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{peek.story.tldr}</p>
            <div className="mt-3 flex items-center justify-between">
              <SourceBadge sourceId={peek.story.source_id} url={peek.story.url} />
              <a href={peek.story.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
                Original <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <Button asChild size="lg">
            <Link href={`/checkin/${id}`}>Open my check-in page</Link>
          </Button>
          <Button asChild size="lg" variant="secondary">
            <Link href={room ? `/partners/quick?room=${room}` : "/partners"}>Find people on the same path</Link>
          </Button>
        </div>
        <p className="text-center text-xs text-muted-foreground">Bookmark your check-in page — it&apos;s how you tell future-you&apos;s story.</p>
      </motion.div>
    </AnimatePresence>
  );
}

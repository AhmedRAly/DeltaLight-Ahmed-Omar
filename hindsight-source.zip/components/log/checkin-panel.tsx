"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { motion } from "framer-motion";
import { CalendarClock, Check, FastForward, Loader2 } from "lucide-react";
import { ChartLegend, ForecastGapChart } from "@/components/ask/forecast-gap-chart";
import { Button } from "@/components/ui/button";
import { Label, Textarea } from "@/components/ui/input";
import { SampleDataNote, Slider } from "@/components/ui/misc";
import { HORIZON_LABEL, type Horizon } from "@/lib/constants";
import type { Insights } from "@/lib/hindsight";
import { cn, timeAgo } from "@/lib/utils";

type Decision = {
  id: string;
  text: string;
  chosen_option: string | null;
  predicted_happiness: number;
  predicted_outcome: string | null;
  confidence: number;
  created_at: string;
};
type Checkin = {
  horizon: Horizon;
  actual_happiness: number;
  regret: number;
  would_choose_again: boolean;
  biggest_surprise: string | null;
  surprise_tags: string[];
  checkin_at: string;
};
type Sched = { horizon: Horizon; due_at: string; status: string; done: boolean };

export function CheckinPanel({ decision, checkins, schedule, crowd }: { decision: Decision; checkins: Checkin[]; schedule: Sched[]; crowd: Insights }) {
  const router = useRouter();
  const due = schedule.find((s) => !s.done && (s.status === "due" || new Date(s.due_at).getTime() <= Date.now()));
  const nextPending = schedule.find((s) => !s.done && !due);
  const [traveling, setTraveling] = useState(false);

  async function timeTravel() {
    setTraveling(true);
    try {
      await fetch("/api/time-travel", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ decision_id: decision.id }),
      });
      router.refresh();
    } finally {
      setTimeout(() => setTraveling(false), 400);
    }
  }

  const own = checkins.map((c) => ({ horizon: c.horizon, actual: c.actual_happiness, predicted: decision.predicted_happiness }));
  const latest = checkins[checkins.length - 1];

  return (
    <div className="space-y-8">
      <div>
        <p className="text-xs uppercase tracking-[0.18em] text-primary">Your decision · logged {timeAgo(decision.created_at)}</p>
        <h1 className="mt-3 text-3xl font-semibold leading-tight tracking-tight md:text-4xl">&ldquo;{decision.text}&rdquo;</h1>
        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted-foreground">
          {decision.chosen_option && <span>Chose: <span className="text-foreground">{decision.chosen_option}</span></span>}
          <span>Predicted happiness: <span className="text-primary">{decision.predicted_happiness}/10</span></span>
          <span>Confidence: {decision.confidence}/10</span>
        </div>
        {decision.predicted_outcome && <p className="mt-3 italic text-muted-foreground">You predicted: &ldquo;{decision.predicted_outcome}&rdquo;</p>}
      </div>

      <ol className="grid grid-cols-4 gap-2">
        {schedule.map((s) => (
          <li
            key={s.horizon}
            className={cn(
              "rounded-xl border p-3 text-center text-sm",
              s.done ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300" : due?.horizon === s.horizon ? "border-primary/50 bg-primary/10 text-primary" : "text-muted-foreground"
            )}
          >
            <div className="font-medium">{HORIZON_LABEL[s.horizon]}</div>
            <div className="mt-0.5 text-xs opacity-80">{s.done ? "done" : due?.horizon === s.horizon ? "due now" : "upcoming"}</div>
          </li>
        ))}
      </ol>

      {due ? (
        <CheckinForm key={due.horizon} decisionId={decision.id} horizon={due.horizon} onDone={() => router.refresh()} />
      ) : nextPending ? (
        <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border bg-card/70 p-6 md:flex-row md:items-center">
          <div className="flex items-center gap-3">
            <CalendarClock className="h-5 w-5 text-primary" />
            <p>
              Next check-in: <span className="font-medium">{HORIZON_LABEL[nextPending.horizon]}</span> — {new Date(nextPending.due_at).toLocaleDateString()}
            </p>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-emerald-200">
          Full loop complete. Your story is now part of what Hindsight tells the next person.
        </div>
      )}

      {nextPending || due ? (
        <button
          onClick={timeTravel}
          disabled={traveling || Boolean(due)}
          className="inline-flex items-center gap-2 rounded-lg border border-dashed px-3 py-1.5 text-xs text-muted-foreground transition hover:border-primary/50 hover:text-primary disabled:opacity-40"
          title="Skip ahead: make the next check-in due now"
        >
          {traveling ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FastForward className="h-3.5 w-3.5" />}
          Time travel to the next check-in
        </button>
      ) : null}

      {(checkins.length > 0 || crowd.by_horizon.length > 0) && (
        <section className="rounded-3xl border bg-card/70 p-5 md:p-8">
          <div className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.18em] text-primary">Your forecast gap vs. people like you</p>
              {latest ? (
                <h2 className="mt-2 text-2xl font-semibold tracking-tight">
                  You predicted {decision.predicted_happiness}. After {HORIZON_LABEL[latest.horizon]} you feel {latest.actual_happiness}.
                </h2>
              ) : (
                <h2 className="mt-2 text-2xl font-semibold tracking-tight">How people like you felt over time</h2>
              )}
            </div>
            <ChartLegend showYou={checkins.length > 0} />
          </div>
          <div className="mt-6">
            <ForecastGapChart points={crowd.by_horizon} own={own} height={280} />
          </div>
          {crowd.n > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span>Crowd line: {crowd.n} similar decisions.</span>
              {crowd.n_seed > 0 && <SampleDataNote />}
            </div>
          )}
        </section>
      )}

      {checkins.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold">Your check-ins</h2>
          {checkins.map((c) => (
            <div key={c.horizon} className="rounded-xl border bg-card/60 p-4">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                <span className="font-medium">{HORIZON_LABEL[c.horizon]}</span>
                <span className="text-muted-foreground">Happiness {c.actual_happiness}/10</span>
                <span className="text-muted-foreground">Regret {c.regret}/10</span>
                <span className={c.would_choose_again ? "text-emerald-400" : "text-red-400"}>
                  {c.would_choose_again ? "Would choose again" : "Wouldn't choose again"}
                </span>
              </div>
              {c.biggest_surprise && <p className="mt-2 text-foreground/85">&ldquo;{c.biggest_surprise}&rdquo;</p>}
              {c.surprise_tags.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {c.surprise_tags.map((t) => (
                    <span key={t} className="rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-xs text-primary">{t}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </section>
      )}
    </div>
  );
}

function CheckinForm({ decisionId, horizon, onDone }: { decisionId: string; horizon: Horizon; onDone: () => void }) {
  const [happiness, setHappiness] = useState(6);
  const [regret, setRegret] = useState(3);
  const [again, setAgain] = useState<boolean | null>(null);
  const [surprise, setSurprise] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string[] | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (again === null) {
      setError("Would you make the same choice again?");
      return;
    }
    setPending(true);
    setError(null);
    try {
      const res = await fetch("/api/checkins", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          decision_id: decisionId,
          horizon,
          actual_happiness: happiness,
          regret,
          would_choose_again: again,
          biggest_surprise: surprise || null,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Could not save.");
      setSaved(json.tags ?? []);
      setTimeout(onDone, 1200);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setPending(false);
    }
  }

  if (saved) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6">
        <div className="flex items-center gap-2 text-emerald-300">
          <Check className="h-5 w-5" /> {HORIZON_LABEL[horizon]} check-in saved.
        </div>
        {saved.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {saved.map((t) => (
              <span key={t} className="rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-xs text-primary">{t}</span>
            ))}
          </div>
        )}
      </motion.div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-6 rounded-2xl border border-primary/30 bg-card/80 p-5 md:p-6">
      <h2 className="text-xl font-semibold">It&apos;s been {HORIZON_LABEL[horizon]}. How did it actually go?</h2>
      <div>
        <Label>How happy are you with the choice right now?</Label>
        <Slider value={happiness} onChange={setHappiness} lowLabel="miserable" highLabel="thrilled" />
      </div>
      <div>
        <Label>How much do you regret it?</Label>
        <Slider value={regret} onChange={setRegret} min={0} lowLabel="not at all" highLabel="deeply" />
      </div>
      <div>
        <Label>Knowing what you know now, would you choose the same again?</Label>
        <div className="grid grid-cols-2 gap-2">
          {[true, false].map((v) => (
            <button
              key={String(v)}
              type="button"
              onClick={() => setAgain(v)}
              className={cn(
                "h-12 rounded-xl border text-base transition",
                again === v ? (v ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300" : "border-red-500/60 bg-red-500/15 text-red-300") : "text-muted-foreground"
              )}
            >
              {v ? "Yes, again" : "No"}
            </button>
          ))}
        </div>
      </div>
      <div>
        <Label htmlFor="surprise">What surprised you most?</Label>
        <Textarea
          id="surprise"
          value={surprise}
          onChange={(e) => setSurprise(e.target.value)}
          placeholder="I didn't expect how lonely working alone would feel — but the freedom is worth it."
          maxLength={600}
        />
      </div>
      {error && <p className="text-sm text-red-300">{error}</p>}
      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending && <Loader2 className="h-4 w-4 animate-spin" />} Save check-in
      </Button>
    </form>
  );
}

"use client";

import * as React from "react";
import { animate, motion, useInView } from "framer-motion";
import { X } from "lucide-react";
import { cn, initials } from "@/lib/utils";

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

export function CountUp({
  value,
  decimals = 0,
  suffix = "",
  prefix = "",
  className,
  duration = 1.1,
}: {
  value: number | null | undefined;
  decimals?: number;
  suffix?: string;
  prefix?: string;
  className?: string;
  duration?: number;
}) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const prev = React.useRef(0);

  React.useEffect(() => {
    const node = ref.current;
    if (!node || !inView || value === null || value === undefined) return;
    const controls = animate(prev.current, value, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate(v) {
        node.textContent = `${prefix}${v.toFixed(decimals)}${suffix}`;
      },
    });
    prev.current = value;
    return () => controls.stop();
  }, [value, inView, decimals, suffix, prefix, duration]);

  if (value === null || value === undefined) return <span className={className}>—</span>;
  return (
    <span ref={ref} className={cn("tabular-nums", className)}>
      {`${prefix}${(0).toFixed(decimals)}${suffix}`}
    </span>
  );
}

export function Avatar({ name, src, size = 44, className }: { name: string; src?: string | null; size?: number; className?: string }) {
  const hue = Array.from(name).reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={name} width={size} height={size} className={cn("rounded-full object-cover", className)} style={{ width: size, height: size }} />;
  }
  return (
    <div
      aria-hidden
      className={cn("flex shrink-0 items-center justify-center rounded-full font-semibold text-white/95 ring-1 ring-white/10", className)}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.36,
        background: `linear-gradient(135deg, hsl(${hue} 55% 45%), hsl(${(hue + 40) % 360} 60% 30%))`,
      }}
    >
      {initials(name)}
    </div>
  );
}

export function TagInput({
  value,
  onChange,
  placeholder,
  suggestions = [],
  max = 12,
}: {
  value: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  suggestions?: string[];
  max?: number;
}) {
  const [draft, setDraft] = React.useState("");
  const add = (raw: string) => {
    const t = raw.trim().toLowerCase();
    if (!t || value.includes(t) || value.length >= max) return;
    onChange([...value, t]);
    setDraft("");
  };
  const remaining = suggestions.filter((s) => !value.includes(s)).slice(0, 10);
  return (
    <div>
      <div className="flex min-h-11 flex-wrap items-center gap-1.5 rounded-xl border bg-secondary/60 px-2 py-1.5 focus-within:ring-2 focus-within:ring-ring/60">
        {value.map((t) => (
          <span key={t} className="inline-flex items-center gap-1 rounded-lg bg-primary/15 px-2 py-1 text-xs text-primary">
            {t}
            <button type="button" aria-label={`Remove ${t}`} onClick={() => onChange(value.filter((x) => x !== t))}>
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
        <input
          value={draft}
          onChange={(e) => {
            const v = e.target.value;
            if (v.endsWith(",")) add(v.slice(0, -1));
            else setDraft(v);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add(draft);
            } else if (e.key === "Backspace" && !draft && value.length) {
              onChange(value.slice(0, -1));
            }
          }}
          onBlur={() => draft && add(draft)}
          placeholder={value.length ? "" : placeholder}
          className="min-w-[8rem] flex-1 bg-transparent px-1.5 py-1 text-base outline-none placeholder:text-muted-foreground/70 md:text-sm"
        />
      </div>
      {remaining.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {remaining.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => add(s)}
              className="rounded-lg border border-dashed px-2 py-0.5 text-xs text-muted-foreground transition hover:border-primary/50 hover:text-foreground"
            >
              + {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function Slider({
  value,
  onChange,
  min = 1,
  max = 10,
  lowLabel,
  highLabel,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  lowLabel?: string;
  highLabel?: string;
}) {
  return (
    <div>
      <div className="flex items-center gap-4">
        <input
          type="range"
          className="range"
          min={min}
          max={max}
          step={1}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          style={{
            background: `linear-gradient(90deg, hsl(148 70% 45%) ${((value - min) / (max - min)) * 100}%, hsl(240 4% 14%) ${((value - min) / (max - min)) * 100}%)`,
          }}
        />
        <motion.span
          key={value}
          initial={{ scale: 1.25, opacity: 0.6 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-10 text-right text-2xl font-semibold tabular-nums text-primary"
        >
          {value}
        </motion.span>
      </div>
      {(lowLabel || highLabel) && (
        <div className="mt-1.5 flex justify-between pr-14 text-xs text-muted-foreground">
          <span>{lowLabel}</span>
          <span>{highLabel}</span>
        </div>
      )}
    </div>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  labels,
}: {
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
  labels?: Partial<Record<T, string>>;
}) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          onClick={() => onChange(o)}
          className={cn(
            "rounded-xl border px-3 py-2 text-sm capitalize transition",
            value === o ? "border-primary/60 bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
          )}
        >
          {labels?.[o] ?? o}
        </button>
      ))}
    </div>
  );
}

export function FadeIn({ children, delay = 0, className }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function SampleDataNote({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border border-sky-500/25 bg-sky-500/10 px-2.5 py-0.5 text-[11px] font-medium text-sky-300", className)}>
      <span className="h-1.5 w-1.5 rounded-full bg-sky-400" /> includes sample data
    </span>
  );
}

import { SOURCE_BY_ID, sourceLabel } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function SourceBadge({ sourceId, url, className }: { sourceId: string; url?: string; className?: string }) {
  const color = SOURCE_BY_ID[sourceId]?.color ?? "#a3a3a3";
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border bg-secondary/60 px-2.5 py-0.5 text-[11px] font-medium text-foreground/80", className)}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {sourceLabel(sourceId, url)}
    </span>
  );
}

const OUTCOME_STYLE: Record<string, string> = {
  success: "border-emerald-500/30 bg-emerald-500/10 text-emerald-400",
  mixed: "border-primary/30 bg-primary/10 text-primary",
  failure: "border-red-500/30 bg-red-500/10 text-red-400",
  ongoing: "border-sky-500/30 bg-sky-500/10 text-sky-300",
};

export function OutcomeBadge({ type, className }: { type: string; className?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium capitalize", OUTCOME_STYLE[type] ?? OUTCOME_STYLE.ongoing, className)}>
      {type}
    </span>
  );
}

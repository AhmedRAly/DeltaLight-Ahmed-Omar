import Link from "next/link";
import { ArrowUpRight, Clock } from "lucide-react";
import { OutcomeBadge, SourceBadge } from "@/components/stories/source-badge";
import { cn } from "@/lib/utils";

export type StoryCardData = {
  id: string;
  title: string;
  url: string;
  source_id: string;
  category: string;
  path: string;
  tldr: string;
  outcome_type: string;
  decision_text: string;
  what_they_chose: string | null;
  starting_point: string | null;
  outcome: string | null;
  lessons: string[];
  read_time_min: number;
};

export function StoryFlow({ story, className }: { story: Pick<StoryCardData, "starting_point" | "decision_text" | "what_they_chose" | "outcome">; className?: string }) {
  const steps = [
    { k: "Starting point", v: story.starting_point },
    { k: "Decision", v: story.what_they_chose || story.decision_text },
    { k: "Outcome", v: story.outcome },
  ];
  return (
    <ol className={cn("grid gap-2 md:grid-cols-3", className)}>
      {steps.map((s, i) => (
        <li key={s.k} className="relative rounded-xl border bg-secondary/30 p-3">
          <div className="mb-1 flex items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
            <span className={cn("flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-semibold", i === 2 ? "bg-primary text-primary-foreground" : "bg-muted text-foreground/80")}>
              {i + 1}
            </span>
            {s.k}
          </div>
          <p className="line-clamp-3 text-sm text-foreground/85">{s.v || <span className="text-muted-foreground">Not stated in the original</span>}</p>
        </li>
      ))}
    </ol>
  );
}

export function StoryCard({ story, compact = false, showLessons = true }: { story: StoryCardData; compact?: boolean; showLessons?: boolean }) {
  return (
    <article className="group relative flex h-full flex-col rounded-2xl border bg-card/70 p-5 transition hover:border-primary/30 hover:bg-card md:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <SourceBadge sourceId={story.source_id} url={story.url} />
        <OutcomeBadge type={story.outcome_type} />
        <span className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" /> {story.read_time_min} min
        </span>
      </div>
      <Link href={`/stories/${story.id}`} className="mt-3 block">
        <h3 className={cn("font-semibold tracking-tight transition group-hover:text-primary", compact ? "text-base leading-snug" : "text-xl leading-snug")}>
          {story.title}
        </h3>
      </Link>
      <p className={cn("mt-2 text-muted-foreground", compact ? "line-clamp-3 text-sm" : "text-[15px] leading-relaxed")}>{story.tldr}</p>
      {!compact && <StoryFlow story={story} className="mt-4" />}
      {!compact && showLessons && story.lessons.length > 0 && (
        <ul className="mt-4 space-y-1.5">
          {story.lessons.slice(0, 3).map((l) => (
            <li key={l} className="flex gap-2 text-sm text-foreground/80">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" />
              {l}
            </li>
          ))}
        </ul>
      )}
      <div className="mt-auto flex items-center justify-between pt-4 text-sm">
        <Link href={`/stories/${story.id}`} className="text-foreground/80 hover:text-foreground">
          Read story
        </Link>
        <a href={story.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-muted-foreground hover:text-primary">
          Read original <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </div>
    </article>
  );
}

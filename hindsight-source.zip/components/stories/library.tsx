import Link from "next/link";
import { ArrowUpRight, Database } from "lucide-react";
import { SourceBadge } from "@/components/stories/source-badge";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { hostOf } from "@/lib/research";
import { timeAgo } from "@/lib/utils";

/** Raw posts Hindsight has gathered so far, shown when there are no AI-structured stories yet. */
export async function Library({ q }: { q?: string }) {
  if (!hasSupabase()) return null;
  let query = createAdminClient()
    .from("raw_items")
    .select("id, source_id, url, title, body, author_handle, posted_at, score")
    .order("fetched_at", { ascending: false })
    .limit(12);
  if (q && q.trim().length >= 2) {
    const safe = q.trim().replace(/[%,()]/g, " ").slice(0, 80);
    query = query.or(`title.ilike.%${safe}%,body.ilike.%${safe}%`);
  }
  const { data } = await query;
  if (!data || data.length === 0) {
    return (
      <div className="mt-10 rounded-2xl border bg-card/70 p-8 text-center">
        <p className="text-lg">Nothing gathered yet.</p>
        <p className="mt-2 text-muted-foreground">
          Ask a question on the <Link href="/" className="text-primary hover:underline">home page</Link> and the posts Hindsight finds will collect here.
        </p>
      </div>
    );
  }
  return (
    <section className="mt-10">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Recently gathered posts</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Real public posts found by past questions. Open any raw record to compare it with the original.
          </p>
        </div>
      </div>
      <div className="mt-5 grid gap-4 md:grid-cols-2">
        {data.map((r) => (
          <article key={r.id} className="flex min-w-0 flex-col rounded-2xl border bg-card/70 p-5 [overflow-wrap:anywhere]">
            <div className="flex items-center gap-2">
              <SourceBadge sourceId={r.source_id} url={r.url} />
              {r.posted_at && <span className="text-xs text-muted-foreground">{timeAgo(r.posted_at)}</span>}
            </div>
            <h3 className="mt-3 line-clamp-2 text-[17px] font-medium leading-snug tracking-tight">{r.title}</h3>
            <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-foreground/70">{r.body}</p>
            <div className="mt-4 flex items-center gap-2 pt-1 text-xs">
              {r.author_handle && <span className="mr-auto truncate text-muted-foreground">by {r.author_handle}</span>}
              {!r.author_handle && <span className="mr-auto" />}
              <Link href={`/source/${r.id}`} className="inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-foreground/80 hover:border-primary/40">
                <Database className="h-3.5 w-3.5" /> Raw record
              </Link>
              <a
                href={r.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-primary hover:bg-primary/20"
              >
                {hostOf(r.url)} <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

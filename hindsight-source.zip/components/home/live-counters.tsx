import { num } from "@/lib/utils";

export type Counters = { decisions: number; stories: number; sources: number; sources_total: number; people: number; checkins: number };

export function parseCounters(v: unknown): Counters {
  const o = (v && typeof v === "object" ? v : {}) as Record<string, unknown>;
  return {
    decisions: num(o.decisions) ?? 0,
    stories: num(o.stories) ?? 0,
    sources: num(o.sources) ?? 0,
    sources_total: num(o.sources_total) ?? 10,
    people: num(o.people) ?? 0,
    checkins: num(o.checkins) ?? 0,
  };
}

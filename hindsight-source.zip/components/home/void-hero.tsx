"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { EyeLive } from "@/components/site/eye";
import { RecentSearches } from "@/components/research/recent-searches";
import { cn } from "@/lib/utils";

const EXAMPLES = [
  "Should I quit my job to start a company?",
  "Is it worth taking a counteroffer?",
  "Should I move cities for a better role?",
  "How do I know when to shut down my startup?",
  "Is an MBA worth it at my stage?",
];

export function VoidHero() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState("");
  const [focused, setFocused] = useState(false);
  const [entering, setEntering] = useState(false);
  const [ph, setPh] = useState(0);

  useEffect(() => {
    inputRef.current?.focus({ preventScroll: true });
    const t = setInterval(() => setPh((p) => (p + 1) % EXAMPLES.length), 3600);
    return () => clearInterval(t);
  }, []);

  const go = (value: string) => {
    const v = value.trim();
    if (v.length < 3 || entering) return;
    setEntering(true);
    setTimeout(() => router.push(`/ask?q=${encodeURIComponent(v)}`), 650);
  };

  const active = focused || q.length > 0;

  return (
    <section className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-4 pb-10 pt-16">
      <div className="stars pointer-events-none absolute inset-0 opacity-70" />
      <motion.div
        className="relative flex aspect-square w-[min(88vw,64dvh,620px)] items-center justify-center"
        animate={entering ? { scale: 14, opacity: 0 } : { scale: 1, opacity: 1 }}
        transition={entering ? { duration: 0.65, ease: [0.7, 0, 0.9, 0.4] } : { duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        initial={{ scale: 0.9, opacity: 0 }}
      >
        {/* outer halo */}
        <div
          className={cn(
            "void-halo void-motion absolute inset-[-6%] rounded-full transition-opacity duration-700 animate-[spin_40s_linear_infinite]",
            active ? "opacity-90" : "opacity-55"
          )}
        />
        {/* faint orbit rings */}
        <div className="void-motion absolute inset-[-9%] rounded-full border border-white/[0.04] animate-breathe" />
        <div className="void-motion absolute inset-[-18%] rounded-full border border-white/[0.025] animate-breathe [animation-delay:1.4s]" />
        {/* luminous ring */}
        <div className="void-ring void-motion absolute inset-0 rounded-full animate-[spin_22s_linear_infinite]" />
        {/* the void */}
        <div className="void-core absolute inset-[1.2%] rounded-full" />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            go(q);
          }}
          className="relative z-10 flex w-[72%] flex-col items-center text-center"
        >
          <EyeLive size={64} className="mb-4" />
          <label htmlFor="void-q" className="font-serif text-[clamp(1.5rem,4.6vw,2.6rem)] italic leading-[1.1] tracking-tight text-foreground [text-wrap:balance]">
            What do you need advice for?
          </label>
          <div className="relative mt-6 w-full">
            <input
              id="void-q"
              ref={inputRef}
              value={q}
              maxLength={400}
              autoComplete="off"
              onChange={(e) => setQ(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              placeholder={EXAMPLES[ph]}
              className="void-input w-full border-0 border-b border-white/10 bg-transparent px-2 pb-2.5 text-center text-base text-foreground outline-none transition placeholder:text-muted-foreground/45 focus:border-primary/60 md:text-lg"
            />
            <motion.button
              type="submit"
              aria-label="Search"
              initial={false}
              animate={{ opacity: q.trim().length >= 3 ? 1 : 0, y: q.trim().length >= 3 ? 0 : 6 }}
              disabled={q.trim().length < 3}
              className="absolute -bottom-14 left-1/2 flex h-10 -translate-x-1/2 items-center gap-2 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground shadow-[0_0_30px_hsl(148_70%_45%/0.35)] disabled:pointer-events-none"
            >
              Find out <ArrowRight className="h-4 w-4" />
            </motion.button>
          </div>
        </form>
      </motion.div>

      <motion.div
        animate={entering ? { opacity: 0 } : { opacity: 1 }}
        className="relative mt-14 flex max-w-2xl flex-col items-center gap-5 text-center"
      >
        <p className="max-w-md text-sm text-muted-foreground">
          We search public posts from people who already faced it, then show you exactly where every answer came from.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {EXAMPLES.slice(0, 3).map((ex) => (
            <button
              key={ex}
              type="button"
              onClick={() => {
                setQ(ex);
                go(ex);
              }}
              className="rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-1.5 text-xs text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
            >
              {ex}
            </button>
          ))}
        </div>
        <RecentSearches className="max-w-xl" />
        <Link href="/business" className="text-xs text-muted-foreground/80 underline-offset-4 hover:text-foreground hover:underline">
          Building something? Meet people on Hindsight Business →
        </Link>
      </motion.div>
    </section>
  );
}

import Link from "next/link";
import { MapPin } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { LOOKING_FOR_LABEL, STAGE_LABEL, type LookingFor, type Stage } from "@/lib/constants";
import { createAdminClient, hasSupabase } from "@/lib/supabase/admin";
import { cn } from "@/lib/utils";

const FILTERS = [
  { id: "all", label: "Everyone" },
  { id: "business", label: "Founders" },
  { id: "corporate", label: "Career" },
] as const;

export async function MemberGrid({ path }: { path: string }) {
  if (!hasSupabase()) return null;
  const active = FILTERS.some((f) => f.id === path) ? path : "all";
  let query = createAdminClient()
    .from("profiles")
    .select("id, name, headline, avatar_url, city, path, stage, skills_have, looking_for, is_seed")
    .eq("is_guest", false)
    .order("created_at", { ascending: false })
    .limit(9);
  if (active === "business") query = query.in("path", ["business", "both"]);
  if (active === "corporate") query = query.in("path", ["corporate", "both"]);
  const { data } = await query;
  if (!data || data.length === 0) return null;

  return (
    <section className="mt-12">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Members</h2>
          <p className="mt-1 text-sm text-muted-foreground">Founders, operators and career-switchers on Hindsight Business.</p>
        </div>
        <div className="flex gap-1.5">
          {FILTERS.map((f) => (
            <Link
              key={f.id}
              href={f.id === "all" ? "/business" : `/business?path=${f.id}`}
              scroll={false}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs transition",
                active === f.id ? "border-primary/50 bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {f.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {data.map((p) => (
          <Link
            key={p.id}
            href={`/partners/${p.id}`}
            className="group flex flex-col rounded-2xl border bg-card/70 p-5 transition hover:-translate-y-0.5 hover:border-primary/40"
          >
            <div className="flex items-center gap-3">
              <Avatar name={p.name} src={p.avatar_url} size={44} />
              <div className="min-w-0">
                <p className="truncate font-medium">{p.name}</p>
                {p.city && (
                  <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
                    <MapPin className="h-3 w-3" /> {p.city}
                  </p>
                )}
              </div>
            </div>
            {p.headline && <p className="mt-3 line-clamp-2 text-sm text-foreground/80">{p.headline}</p>}
            <div className="mt-3 flex flex-wrap gap-1.5">
              <span className="rounded-md bg-primary/10 px-2 py-0.5 text-[11px] text-primary">{STAGE_LABEL[p.stage as Stage] ?? p.stage}</span>
              {p.skills_have.slice(0, 3).map((s) => (
                <span key={s} className="rounded-md bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground">
                  {s}
                </span>
              ))}
            </div>
            {p.looking_for.length > 0 && (
              <p className="mt-3 text-xs text-muted-foreground">
                Looking for <span className="text-foreground/80">{p.looking_for.slice(0, 2).map((l) => LOOKING_FOR_LABEL[l as LookingFor] ?? l).join(", ")}</span>
              </p>
            )}
          </Link>
        ))}
      </div>
    </section>
  );
}

"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Users } from "lucide-react";
import { CountUp, FadeIn, Skeleton } from "@/components/ui/misc";
import { SourceBadge } from "@/components/stories/source-badge";
import { getBrowserSupabase } from "@/lib/supabase/client";
import type { Json } from "@/lib/database.types";
import { num } from "@/lib/utils";

type RoomStats = {
  decisions: number;
  profiles: number;
  avg_predicted: number | null;
  top_categories: { category: string; n: number }[];
  pairs: { a_name: string; b_name: string; score: number; a_gets: string[]; b_gets: string[] }[];
};

function parseStats(v: Json | null): RoomStats {
  const o = (v && typeof v === "object" ? v : {}) as Record<string, unknown>;
  return {
    decisions: num(o.decisions) ?? 0,
    profiles: num(o.profiles) ?? 0,
    avg_predicted: num(o.avg_predicted),
    top_categories: Array.isArray(o.top_categories)
      ? o.top_categories
          .filter((c): c is Record<string, unknown> => Boolean(c) && typeof c === "object")
          .map((c) => ({ category: String(c.category ?? ""), n: num(c.n) ?? 0 }))
      : [],
    pairs: Array.isArray(o.pairs)
      ? o.pairs
          .filter((p): p is Record<string, unknown> => Boolean(p) && typeof p === "object")
          .map((p) => ({
            a_name: String(p.a_name ?? ""),
            b_name: String(p.b_name ?? ""),
            score: num(p.score) ?? 0,
            a_gets: Array.isArray(p.a_gets) ? p.a_gets.map(String) : [],
            b_gets: Array.isArray(p.b_gets) ? p.b_gets.map(String) : [],
          }))
      : [],
  };
}

export function RoomView({ code }: { code: string }) {
  const [stats, setStats] = useState<RoomStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [live, setLive] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const supabase = getBrowserSupabase();
    if (!supabase) {
      setError("Rooms are unavailable right now.");
      return;
    }
    const load = async () => {
      try {
        const { data } = await supabase.rpc("room_stats", { code });
        if (!cancelled) setStats(parseStats(data));
      } catch {
        if (!cancelled) setError("Room stats unavailable.");
      }
    };
    load();
    const ch = supabase
      .channel(`room-${code}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "decisions", filter: `room_code=eq.${code}` }, () => {
        setLive((n) => n + 1);
        load();
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "profiles", filter: `room_code=eq.${code}` }, () => {
        load();
      })
      .subscribe();
    return () => {
      cancelled = true;
      supabase.removeChannel(ch);
    };
  }, [code]);

  if (error) return <p className="text-center text-red-300">{error}</p>;
  if (!stats) return <div className="grid gap-4 md:grid-cols-3"><Skeleton className="h-28" /><Skeleton className="h-28" /><Skeleton className="h-28" /></div>;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <FadeIn className="rounded-2xl border bg-card/80 p-6 text-center">
          <CountUp value={stats.decisions} className="block text-5xl font-semibold" />
          <p className="mt-2 text-sm text-muted-foreground">decisions in this room</p>
        </FadeIn>
        <FadeIn className="rounded-2xl border bg-card/80 p-6 text-center">
          <CountUp value={stats.profiles} className="block text-5xl font-semibold" />
          <p className="mt-2 text-sm text-muted-foreground">people in this room</p>
        </FadeIn>
        <FadeIn className="rounded-2xl border bg-card/80 p-6 text-center">
          <CountUp value={stats.avg_predicted} decimals={1} className="block text-5xl font-semibold text-primary" />
          <p className="mt-2 text-sm text-muted-foreground">avg predicted happiness</p>
        </FadeIn>
      </div>

      {stats.top_categories.length > 0 && (
        <FadeIn className="rounded-2xl border bg-card/80 p-6">
          <h3 className="text-sm uppercase tracking-[0.16em] text-muted-foreground">Top categories</h3>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.top_categories.map((c) => (
              <span key={c.category} className="rounded-full border px-3 py-1 text-sm text-foreground/85">
                {c.category} <span className="text-muted-foreground">{c.n}</span>
              </span>
            ))}
          </div>
        </FadeIn>
      )}

      {stats.pairs.length > 0 && (
        <FadeIn className="rounded-2xl border border-primary/30 bg-primary/5 p-6">
          <h3 className="text-sm uppercase tracking-[0.16em] text-primary">People who should talk</h3>
          <div className="mt-3 space-y-3">
            {stats.pairs.map((p, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border bg-card/70 p-4">
                <p className="font-medium">
                  {p.a_name} and {p.b_name} — <span className="text-primary">{Math.round(p.score * 100)}%</span> match
                </p>
                <p className="mt-1 text-sm text-foreground/85">
                  {p.a_name} needs {p.a_gets.join(", ")} — {p.b_name} has it. {p.b_name} needs {p.b_gets.join(", ")} — {p.a_name} has it.
                </p>
              </motion.div>
            ))}
          </div>
        </FadeIn>
      )}
    </div>
  );
}
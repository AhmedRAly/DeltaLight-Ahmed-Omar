"use client";

import { useMemo } from "react";
import { QRCodeSVG } from "qrcode.react";

export function RoomQR({ url }: { url: string }) {
  const dataUrl = useMemo(() => url, [url]);
  return (
    <div className="inline-flex flex-col items-center gap-3 rounded-2xl border bg-white p-4">
      <QRCodeSVG value={dataUrl} size={240} level="M" fgColor="#09090b" bgColor="#ffffff" marginSize={2} />
      <p className="text-[11px] text-black/60">Scan to join</p>
    </div>
  );
}
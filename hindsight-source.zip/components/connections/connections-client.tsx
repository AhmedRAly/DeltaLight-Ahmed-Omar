"use client";

import { useState } from "react";
import { Check, MessageSquare, X } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { ChatPanel } from "./chat-panel";

type Other = { id: string; name: string; headline: string | null; avatar_url: string | null; city: string | null };
type Conn = {
  id: string;
  status: "pending" | "accepted" | "declined";
  message: string | null;
  match_score: number | null;
  created_at: string;
  other: Other;
};

export function ConnectionsClient({ mine, meId }: { mine: Conn[]; meId: string }) {
  const [items, setItems] = useState<Conn[]>(mine);
  const [pending, setPending] = useState(mine.filter((c) => c.status === "pending"));
  const [chat, setChat] = useState<Conn | null>(mine.find((c) => c.status === "accepted") ?? null);

  async function accept(id: string) {
    const res = await fetch("/api/connections", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, status: "accepted" }),
    });
    if (!res.ok) return;
    setItems((prev) => prev.map((c) => (c.id === id ? { ...c, status: "accepted" } : c)));
    setPending((p) => p.filter((c) => c.id !== id));
  }

  async function decline(id: string) {
    const res = await fetch("/api/connections", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, status: "declined" }),
    });
    if (!res.ok) return;
    setItems((prev) => prev.filter((c) => c.id !== id));
    setPending((p) => p.filter((c) => c.id !== id));
  }

  return (
    <div className="mt-6 space-y-4">
      {pending.length > 0 && (
        <section>
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Requests waiting on you</h2>
          <div className="mt-3 space-y-3">
            {pending.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-2xl border bg-card/80 p-4">
                <Avatar name={c.other.name} src={c.other.avatar_url} />
                <div className="min-w-0 flex-1">
                  <div className="font-medium">{c.other.name}</div>
                  <div className="line-clamp-1 text-sm text-muted-foreground">{c.other.headline}</div>
                  {c.message && <p className="mt-1 line-clamp-2 text-sm text-foreground/80">&ldquo;{c.message}&rdquo;</p>}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => accept(c.id)}>
                    <Check className="h-4 w-4" /> Accept
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => decline(c.id)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Accepted ({items.filter((c) => c.status === "accepted").length})</h2>
        {items.filter((c) => c.status === "accepted").length === 0 ? (
          <p className="mt-3 text-muted-foreground">No accepted connections yet.</p>
        ) : (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {items.filter((c) => c.status === "accepted").map((c) => (
              <button
                key={c.id}
                onClick={() => setChat(c)}
                className="flex items-center gap-3 rounded-2xl border bg-card/80 p-4 text-left transition hover:border-primary/40"
              >
                <Avatar name={c.other.name} src={c.other.avatar_url} />
                <div className="min-w-0">
                  <div className="font-medium">{c.other.name}</div>
                  <div className="line-clamp-1 text-sm text-muted-foreground">{c.other.headline}</div>
                </div>
                <MessageSquare className="ml-auto h-4 w-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        )}
      </section>

      {chat && <ChatPanel conn={chat} meId={meId} onClose={() => setChat(null)} />}
    </div>
  );
}
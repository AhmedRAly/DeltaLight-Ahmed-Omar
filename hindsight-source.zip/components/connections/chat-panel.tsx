"use client";

import { cn } from "@/lib/utils";
import { useEffect, useRef, useState } from "react";
import { Loader2, Send, X } from "lucide-react";
import { motion } from "framer-motion";
import { Avatar } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getBrowserSupabase } from "@/lib/supabase/client";

type Other = { id: string; name: string; headline: string | null; avatar_url: string | null; city: string | null };
type Conn = { id: string; status: string; other: Other };

type MessageRow = { id: string; connection_id: string; sender: string; body: string; created_at: string };

export function ChatPanel({ conn, meId, onClose }: { conn: Conn; meId: string; onClose: () => void }) {
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const supabase = getBrowserSupabase();
      if (!supabase) return;
      const { data } = await supabase
        .from("messages")
        .select("id, connection_id, sender, body, created_at")
        .eq("connection_id", conn.id)
        .order("created_at", { ascending: true });
      setMessages(data ?? []);
      const ch = supabase
        .channel(`chat-${conn.id}`)
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `connection_id=eq.${conn.id}` }, (p) => {
          const row = p.new as MessageRow;
          setMessages((prev) => [...prev, row]);
        })
        .subscribe();
      return () => supabase.removeChannel(ch);
    })();
  }, [conn.id]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const body = draft.trim();
    if (!body) return;
    setSending(true);
    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ connection_id: conn.id, body }),
      });
      if (!res.ok) throw new Error("send failed");
      setDraft("");
    } catch {
      setMessages((prev) => [...prev, { id: "optimistic", connection_id: conn.id, sender: meId, body, created_at: new Date().toISOString() }]);
    } finally {
      setSending(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 right-4 z-50 flex h-[70vh] w-[92vw] max-w-md flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl"
    >
      <div className="flex items-center gap-3 border-b p-4">
        <Avatar name={conn.other.name} src={conn.other.avatar_url} size={40} />
        <div className="min-w-0 flex-1">
          <div className="font-medium">{conn.other.name}</div>
          <div className="text-xs text-muted-foreground">Hindsight chat</div>
        </div>
        <Button size="icon" variant="ghost" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4">
        {messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground">Say hello to {conn.other.name.split(" ")[0]}.</p>
        ) : (
          <div className="space-y-3">
            {messages.map((m) => {
              const mine = m.sender === meId;
              return (
                <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[80%] rounded-2xl px-3.5 py-2 text-sm",
                      mine ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                    )}
                  >
                    {m.body}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      <form onSubmit={send} className="flex items-center gap-2 border-t p-3">
        <Input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type a message" className="h-10 flex-1" />
        <Button size="icon" type="submit" disabled={sending || !draft.trim()}>
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </form>
    </motion.div>
  );
}
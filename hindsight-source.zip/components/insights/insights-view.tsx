"use client";

import Link from "next/link";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { SourceBadge, OutcomeBadge } from "@/components/stories/source-badge";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CountUp, FadeIn } from "@/components/ui/misc";
import { parseCounters } from "@/components/home/live-counters";
import type { Json } from "@/lib/database.types";
import { parseInsights, type GlobalInsights } from "@/lib/insights";

type Props = { data: { counters: Json | null; insights: Json | null } | null };

const OUTCOME_COLOR = {
  success: "hsl(152 60% 50%)",
  mixed: "hsl(148 70% 45%)",
  failure: "hsl(0 72% 58%)",
  ongoing: "hsl(199 80% 60%)",
} as const;

const tooltipStyle = {
  background: "hsl(240 5% 8%)",
  border: "1px solid hsl(240 4% 18%)",
  borderRadius: 12,
  color: "white",
  fontSize: 13,
};

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="py-8 text-center text-sm text-muted-foreground">{children}</p>;
}

export function InsightsView({ data }: Props) {
  if (!data) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="text-3xl font-semibold tracking-tight">Global insights</h1>
        <p className="mt-3 text-muted-foreground">
          Insights aren&apos;t available yet. Connect a Supabase project and apply the migration to see aggregate data here.
        </p>
      </main>
    );
  }

  const c = parseCounters(data.counters);
  const g: GlobalInsights = parseInsights(data.insights);
  const gapRows = g.gaps_by_category.filter((x) => x.gap !== null);
  const outcomeRows = g.story_outcomes.slice(0, 8);
  const maxTag = Math.max(1, ...g.story_tags.map((t) => t.n));

  const stats = [
    { label: "decisions logged", value: c.decisions, decimals: 0, suffix: "" },
    { label: "check-ins", value: c.checkins, decimals: 0, suffix: "" },
    { label: "real stories", value: c.stories, decimals: 0, suffix: "" },
    { label: "avg happiness gap", value: g.totals.avg_gap, decimals: 1, suffix: "" },
    { label: "would choose again", value: g.totals.again_pct, decimals: 0, suffix: "%" },
  ];

  return (
    <main className="mx-auto max-w-6xl space-y-8 px-4 py-12 md:py-16">
      <FadeIn>
        <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">Global insights</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          What people predicted versus what they actually felt, and what real stories say happened.
        </p>
      </FadeIn>

      <FadeIn delay={0.05}>
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border bg-border md:grid-cols-5">
          {stats.map((s) => (
            <div key={s.label} className="bg-card px-5 py-5 text-center">
              <CountUp value={s.value} decimals={s.decimals} suffix={s.suffix} className="block text-2xl font-semibold tracking-tight md:text-3xl" />
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </FadeIn>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Prediction gap by category</CardTitle>
            <CardDescription>Actual minus predicted happiness. Negative means reality fell short of the forecast.</CardDescription>
          </CardHeader>
          <CardContent>
            {gapRows.length === 0 ? (
              <Empty>No check-ins yet.</Empty>
            ) : (
              <div style={{ height: Math.max(220, gapRows.length * 44) }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gapRows} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                    <CartesianGrid stroke="hsl(240 4% 16%)" strokeDasharray="3 6" horizontal={false} />
                    <XAxis type="number" stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={12} />
                    <YAxis type="category" dataKey="category" width={90} stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={12} />
                    <Tooltip
                      cursor={{ fill: "hsl(240 4% 14% / 0.6)" }}
                      contentStyle={tooltipStyle}
                      formatter={(v, _n, p) => [`${Number(v).toFixed(2)} (n=${p.payload.n})`, "Gap"]}
                    />
                    <Bar dataKey="gap" radius={4}>
                      {gapRows.map((r) => (
                        <Cell key={r.category} fill={(r.gap ?? 0) < 0 ? "hsl(0 72% 58%)" : "hsl(152 60% 50%)"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>How real stories ended</CardTitle>
            <CardDescription>Outcomes of ingested public stories, by category.</CardDescription>
          </CardHeader>
          <CardContent>
            {outcomeRows.length === 0 ? (
              <Empty>No stories ingested yet.</Empty>
            ) : (
              <>
                <div style={{ height: Math.max(220, outcomeRows.length * 44) }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={outcomeRows} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                      <CartesianGrid stroke="hsl(240 4% 16%)" strokeDasharray="3 6" horizontal={false} />
                      <XAxis type="number" stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={12} />
                      <YAxis type="category" dataKey="category" width={90} stroke="hsl(240 5% 55%)" tickLine={false} axisLine={false} fontSize={12} />
                      <Tooltip cursor={{ fill: "hsl(240 4% 14% / 0.6)" }} contentStyle={tooltipStyle} />
                      <Bar dataKey="success" stackId="o" fill={OUTCOME_COLOR.success} name="Success" />
                      <Bar dataKey="mixed" stackId="o" fill={OUTCOME_COLOR.mixed} name="Mixed" />
                      <Bar dataKey="failure" stackId="o" fill={OUTCOME_COLOR.failure} name="Failure" />
                      <Bar dataKey="ongoing" stackId="o" fill={OUTCOME_COLOR.ongoing} name="Ongoing" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
                  {(Object.keys(OUTCOME_COLOR) as (keyof typeof OUTCOME_COLOR)[]).map((k) => (
                    <span key={k} className="flex items-center gap-1.5 capitalize">
                      <span className="h-2 w-2 rounded-full" style={{ background: OUTCOME_COLOR[k] }} /> {k}
                    </span>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Most regretted choices</CardTitle>
            <CardDescription>Options chosen at least 3 times, ranked by average regret.</CardDescription>
          </CardHeader>
          <CardContent>
            {g.most_regretted.length === 0 ? (
              <Empty>Not enough repeated choices yet.</Empty>
            ) : (
              <ul className="divide-y">
                {g.most_regretted.map((r, i) => (
                  <li key={`${i}-${r.category}-${r.option}`} className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <div className="truncate font-medium capitalize">{r.option}</div>
                      <div className="text-xs text-muted-foreground">{r.category} · {r.n} people</div>
                    </div>
                    <Badge variant="danger">regret {r.avg_regret?.toFixed(1) ?? "—"}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Would do again</CardTitle>
            <CardDescription>Choices people say they&apos;d make a second time.</CardDescription>
          </CardHeader>
          <CardContent>
            {g.would_do_again.length === 0 ? (
              <Empty>Not enough repeated choices yet.</Empty>
            ) : (
              <ul className="divide-y">
                {g.would_do_again.map((r, i) => (
                  <li key={`${i}-${r.category}-${r.option}`} className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <div className="truncate font-medium capitalize">{r.option}</div>
                      <div className="text-xs text-muted-foreground">{r.category} · {r.n} people</div>
                    </div>
                    <Badge variant="success">{r.would_choose_again_pct !== null ? `${Math.round(r.would_choose_again_pct)}%` : "—"} again</Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {g.story_tags.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>What surprised people</CardTitle>
            <CardDescription>Most common surprise tags across stories.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {g.story_tags.map((t) => (
                <span
                  key={t.tag}
                  className="rounded-xl border bg-secondary/60 px-3 py-1.5 text-sm"
                  style={{ opacity: 0.55 + 0.45 * (t.n / maxTag) }}
                >
                  {t.tag} <span className="text-muted-foreground">{t.n}</span>
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Lessons from real stories</CardTitle>
          <CardDescription>One distilled takeaway per story.</CardDescription>
        </CardHeader>
        <CardContent>
          {g.top_lessons.length === 0 ? (
            <Empty>No lessons extracted yet.</Empty>
          ) : (
            <ul className="grid gap-4 md:grid-cols-2">
              {g.top_lessons.map((l) => (
                <li key={l.story_id}>
                  <Link href={`/stories/${l.story_id}`} className="block h-full rounded-xl border p-4 transition hover:border-primary/40">
                    <p className="text-sm leading-relaxed">&ldquo;{l.lesson}&rdquo;</p>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <SourceBadge sourceId={l.source_id} />
                      <OutcomeBadge type={l.outcome_type} />
                    </div>
                    <p className="mt-2 line-clamp-1 text-xs text-muted-foreground">{l.title}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </main>
  );
}

"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Activity, Database, ExternalLink, Info, KeyRound, Loader2, Play, Radio, Square, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CountUp } from "@/components/ui/misc";
import { SOURCE_BY_ID } from "@/lib/constants";
import type { Tables } from "@/lib/database.types";
import { getBrowserSupabase } from "@/lib/supabase/client";
import { cn, timeAgo } from "@/lib/utils";

export type SourceRow = Tables<"sources">;
export type IngestRunRow = Tables<"ingest_runs">;

type Summary = {
  source_id: string;
  status: string;
  fetched: number;
  new_items: number;
  processed: number;
  stories_created: number;
  message: string;
};

type RealtimeState = "connecting" | "live" | "off";

const TOKEN_KEY = "hindsight-admin-token";
const MAX_OPTIONS = [5, 8, 12, 20] as const;
const MAX_RUNS = 30;

function statusVariant(status: string | null): "success" | "danger" | "warning" | "info" | "secondary" {
  switch (status) {
    case "done":
      return "success";
    case "error":
      return "danger";
    case "skipped":
      return "warning";
    case "running":
      return "info";
    default:
      return "secondary";
  }
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function toSummary(v: unknown): Summary | null {
  if (!isRecord(v) || typeof v.source_id !== "string" || typeof v.status !== "string") return null;
  const n = (x: unknown) => (typeof x === "number" && Number.isFinite(x) ? x : 0);
  return {
    source_id: v.source_id,
    status: v.status,
    fetched: n(v.fetched),
    new_items: n(v.new_items),
    processed: n(v.processed),
    stories_created: n(v.stories_created),
    message: typeof v.message === "string" ? v.message : "",
  };
}

function upsertRun(list: IngestRunRow[], row: IngestRunRow): IngestRunRow[] {
  const without = list.filter((r) => r.id !== row.id);
  return [row, ...without]
    .sort((a, b) => new Date(b.started_at).getTime() - new Date(a.started_at).getTime())
    .slice(0, MAX_RUNS);
}

export function IngestConsole({
  initialSources,
  initialRuns,
  initialStoryCount,
  loadError,
  adminTokenRequired,
}: {
  initialSources: SourceRow[];
  initialRuns: IngestRunRow[];
  initialStoryCount: number | null;
  loadError: string | null;
  adminTokenRequired: boolean;
}) {
  const [sources, setSources] = React.useState<SourceRow[]>(initialSources);
  const [runs, setRuns] = React.useState<IngestRunRow[]>(initialRuns);
  const [storyCount, setStoryCount] = React.useState<number | null>(initialStoryCount);
  const [busy, setBusy] = React.useState<Set<string>>(() => new Set());
  const [results, setResults] = React.useState<Record<string, Summary>>({});
  const [requestErrors, setRequestErrors] = React.useState<Record<string, string>>({});
  const [token, setToken] = React.useState("");
  const [maxProcess, setMaxProcess] = React.useState<number>(8);
  const [rt, setRt] = React.useState<RealtimeState>("connecting");
  const [batch, setBatch] = React.useState<{ done: number; total: number; current: string | null } | null>(null);
  const stopRef = React.useRef(false);

  // Restore the admin token.
  React.useEffect(() => {
    try {
      const saved = window.localStorage.getItem(TOKEN_KEY);
      if (saved) setToken(saved);
    } catch {
      // localStorage unavailable (private mode); token stays in memory only.
    }
  }, []);

  const saveToken = (value: string) => {
    setToken(value);
    try {
      if (value) window.localStorage.setItem(TOKEN_KEY, value);
      else window.localStorage.removeItem(TOKEN_KEY);
    } catch {
      // ignore
    }
  };

  // Realtime: live run counters, source status, and story count.
  React.useEffect(() => {
    const sb = getBrowserSupabase();
    if (!sb) {
      setRt("off");
      return;
    }
    const channel = sb
      .channel("admin-ingest-console")
      .on<IngestRunRow>("postgres_changes", { event: "INSERT", schema: "public", table: "ingest_runs" }, (payload) => {
        setRuns((prev) => upsertRun(prev, payload.new));
      })
      .on<IngestRunRow>("postgres_changes", { event: "UPDATE", schema: "public", table: "ingest_runs" }, (payload) => {
        setRuns((prev) => upsertRun(prev, payload.new));
      })
      .on<SourceRow>("postgres_changes", { event: "UPDATE", schema: "public", table: "sources" }, (payload) => {
        const row = payload.new;
        setSources((prev) => prev.map((s) => (s.id === row.id ? { ...s, ...row } : s)));
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "stories" }, () => {
        setStoryCount((c) => (c ?? 0) + 1);
      })
      .subscribe((status) => {
        const s = String(status);
        if (s === "SUBSCRIBED") setRt("live");
        else if (s === "CHANNEL_ERROR" || s === "TIMED_OUT" || s === "CLOSED") setRt("off");
      });
    return () => {
      void sb.removeChannel(channel);
    };
  }, []);

  // Fallback refresh (works without Realtime because sources/ingest_runs are publicly readable).
  const refresh = React.useCallback(async () => {
    const sb = getBrowserSupabase();
    if (!sb) return;
    try {
      const [srcRes, runRes, countRes] = await Promise.all([
        sb.from("sources").select("*"),
        sb.from("ingest_runs").select("*").order("started_at", { ascending: false }).limit(MAX_RUNS),
        sb.from("stories").select("id", { count: "exact", head: true }),
      ]);
      if (srcRes.data) {
        const byId = new Map(srcRes.data.map((r): [string, SourceRow] => [r.id, r]));
        setSources((prev) => prev.map((s) => byId.get(s.id) ?? s));
      }
      if (runRes.data) setRuns(runRes.data);
      if (!countRes.error && typeof countRes.count === "number") setStoryCount(countRes.count);
    } catch {
      // Keep current state on network errors.
    }
  }, []);

  const runOne = React.useCallback(
    async (id: string): Promise<void> => {
      setBusy((prev) => new Set(prev).add(id));
      setRequestErrors((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      try {
        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (token) headers["x-admin-token"] = token;
        const res = await fetch("/api/admin/ingest", {
          method: "POST",
          headers,
          body: JSON.stringify({ source: id, max_process: maxProcess }),
        });
        let json: unknown = null;
        try {
          json = await res.json();
        } catch {
          json = null;
        }
        if (!res.ok) {
          const msg = isRecord(json) && typeof json.error === "string" ? json.error : `Request failed (${res.status})`;
          setRequestErrors((prev) => ({ ...prev, [id]: msg }));
          return;
        }
        const list = isRecord(json) && Array.isArray(json.summaries) ? json.summaries : [];
        const summaries = list.map(toSummary).filter((s): s is Summary => s !== null);
        setResults((prev) => {
          const next = { ...prev };
          for (const s of summaries) next[s.source_id] = s;
          return next;
        });
        // Reflect the outcome immediately even if Realtime is unavailable.
        setSources((prev) =>
          prev.map((s) => {
            const sum = summaries.find((x) => x.source_id === s.id);
            if (!sum) return s;
            return {
              ...s,
              last_status: sum.status,
              last_error: sum.status === "done" ? null : sum.message,
              last_synced_at: new Date().toISOString(),
              items_count: rt === "live" ? s.items_count : s.items_count + sum.stories_created,
            };
          })
        );
        if (rt !== "live") await refresh();
      } catch (err) {
        setRequestErrors((prev) => ({ ...prev, [id]: err instanceof Error ? err.message : "Network error" }));
      } finally {
        setBusy((prev) => {
          const next = new Set(prev);
          next.delete(id);
          return next;
        });
      }
    },
    [token, maxProcess, rt, refresh]
  );

  const runAll = async () => {
    stopRef.current = false;
    const ids = sources.map((s) => s.id);
    setBatch({ done: 0, total: ids.length, current: ids[0] ?? null });
    for (let i = 0; i < ids.length; i++) {
      if (stopRef.current) break;
      setBatch({ done: i, total: ids.length, current: ids[i] });
      await runOne(ids[i]);
    }
    setBatch((b) => (b ? { ...b, done: stopRef.current ? b.done : b.total, current: null } : b));
    window.setTimeout(() => setBatch(null), 2500);
  };

  const latestBySource = React.useMemo(() => {
    const map = new Map<string, IngestRunRow>();
    for (const r of runs) {
      const cur = map.get(r.source_id);
      if (!cur || new Date(r.started_at).getTime() > new Date(cur.started_at).getTime()) map.set(r.source_id, r);
    }
    return map;
  }, [runs]);

  const runningCount = Array.from(latestBySource.values()).filter((r) => r.status === "running").length;
  const syncedSources = sources.filter((s) => s.last_synced_at).length;
  const batchRunning = batch !== null && batch.current !== null;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-primary">Admin · Ingestion</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight md:text-4xl">
            <span className="text-gradient">Real stories, pulled live</span>
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Fetch public posts from 10 sources, keep first-person decision stories with real outcomes, and structure them
            with AI. Progress streams in over Supabase Realtime.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <RealtimeBadge state={rt} />
          {batchRunning ? (
            <Button variant="secondary" onClick={() => (stopRef.current = true)}>
              <Square className="h-4 w-4" /> Stop after current
            </Button>
          ) : (
            <Button onClick={() => void runAll()} disabled={busy.size > 0}>
              <Zap className="h-4 w-4" /> Run all
            </Button>
          )}
        </div>
      </div>

      {/* Notice */}
      <div className="flex items-start gap-3 rounded-2xl border border-primary/20 bg-primary/5 p-4 text-sm">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p className="text-foreground/85">
          Real stories only come from ingestion — nothing here is generated or invented. Each story credits its original
          author handle and links back to the source post. Posts without a first-person decision and an outcome are
          discarded.
        </p>
      </div>

      {loadError && (
        <div className="rounded-2xl border border-red-500/25 bg-red-500/5 p-4 text-sm text-red-300">{loadError}</div>
      )}

      {/* Stats + controls */}
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Stories in library" value={storyCount} icon={<Database className="h-4 w-4" />} />
        <StatCard label="Sources synced" value={syncedSources} suffix={` / ${sources.length}`} icon={<Radio className="h-4 w-4" />} />
        <StatCard label="Runs in progress" value={runningCount} icon={<Activity className="h-4 w-4" />} />
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Items to AI-process per run</p>
          <div className="mt-3 flex gap-1.5">
            {MAX_OPTIONS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMaxProcess(m)}
                className={cn(
                  "flex-1 rounded-lg border px-2 py-1.5 text-sm tabular-nums transition",
                  maxProcess === m ? "border-primary/60 bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {m}
              </button>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">Smaller batches keep each request short.</p>
        </Card>
      </div>

      {/* Token */}
      <Card className="flex flex-col gap-3 p-5 md:flex-row md:items-center">
        <div className="flex items-center gap-2 text-sm">
          <KeyRound className="h-4 w-4 text-primary" />
          <span className="font-medium">Admin token</span>
          <Badge variant={adminTokenRequired ? "warning" : "secondary"}>{adminTokenRequired ? "required" : "optional"}</Badge>
        </div>
        <Input
          type="password"
          autoComplete="off"
          placeholder={adminTokenRequired ? "Paste ADMIN_TOKEN to run ingestion" : "Not required on this deployment"}
          value={token}
          onChange={(e) => saveToken(e.target.value)}
          className="md:max-w-sm"
        />
        <p className="text-xs text-muted-foreground">Stored only in this browser and sent as the x-admin-token header.</p>
      </Card>

      {/* Batch progress */}
      <AnimatePresence>
        {batch && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="surface p-5"
          >
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2">
                {batch.current ? <Loader2 className="h-4 w-4 animate-spin text-primary" /> : <Zap className="h-4 w-4 text-primary" />}
                {batch.current
                  ? `Running ${SOURCE_BY_ID[batch.current]?.name ?? batch.current}…`
                  : stopRef.current
                    ? "Stopped"
                    : "All sources finished"}
              </span>
              <span className="tabular-nums text-muted-foreground">
                {batch.done}/{batch.total}
              </span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary">
              <motion.div
                className="h-full rounded-full bg-primary shadow-[0_0_16px_hsl(148_70%_45%/0.6)]"
                initial={false}
                animate={{ width: `${batch.total ? (batch.done / batch.total) * 100 : 0}%` }}
                transition={{ ease: [0.16, 1, 0.3, 1], duration: 0.6 }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sources grid */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {sources.map((s) => (
          <SourceCard
            key={s.id}
            source={s}
            latestRun={latestBySource.get(s.id) ?? null}
            result={results[s.id] ?? null}
            requestError={requestErrors[s.id] ?? null}
            busy={busy.has(s.id)}
            disabled={batchRunning}
            onRun={() => void runOne(s.id)}
          />
        ))}
      </div>

      {/* Live log */}
      <Card className="p-0">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <h2 className="flex items-center gap-2 text-sm font-semibold">
            <Activity className="h-4 w-4 text-primary" /> Recent runs
          </h2>
          <span className="text-xs text-muted-foreground">last {MAX_RUNS}</span>
        </div>
        {runs.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-muted-foreground">
            No ingestion runs yet. Run a source above to start building the story library.
          </p>
        ) : (
          <ul className="divide-y">
            <AnimatePresence initial={false}>
              {runs.map((r) => (
                <motion.li
                  key={r.id}
                  layout
                  initial={{ opacity: 0, backgroundColor: "hsl(148 70% 45% / 0.08)" }}
                  animate={{ opacity: 1, backgroundColor: "hsl(148 70% 45% / 0)" }}
                  transition={{ duration: 0.8 }}
                  className="flex flex-col gap-1 px-5 py-3 text-sm md:flex-row md:items-center md:gap-4"
                >
                  <div className="flex min-w-[220px] items-center gap-2">
                    <Badge variant={statusVariant(r.status)}>
                      {r.status === "running" && <Loader2 className="h-3 w-3 animate-spin" />}
                      {r.status}
                    </Badge>
                    <span className="truncate font-medium">{SOURCE_BY_ID[r.source_id]?.name ?? r.source_id}</span>
                  </div>
                  <div className="flex gap-4 text-xs tabular-nums text-muted-foreground">
                    <span>fetched {r.fetched}</span>
                    <span>new {r.new_items}</span>
                    <span>processed {r.processed}</span>
                    <span className="text-primary">+{r.stories_created} stories</span>
                  </div>
                  <p className="min-w-0 flex-1 truncate text-xs text-muted-foreground" title={r.message ?? undefined}>
                    {r.message}
                  </p>
                  <span className="shrink-0 text-xs text-muted-foreground">{timeAgo(r.started_at)}</span>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
      </Card>
    </div>
  );
}

function RealtimeBadge({ state }: { state: RealtimeState }) {
  if (state === "live")
    return (
      <Badge variant="success">
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
        </span>
        Live
      </Badge>
    );
  if (state === "connecting") return <Badge variant="secondary">Connecting…</Badge>;
  return (
    <Badge variant="secondary" title="Realtime unavailable — the console refreshes after each run instead">
      Realtime off
    </Badge>
  );
}

function StatCard({
  label,
  value,
  suffix,
  icon,
}: {
  label: string;
  value: number | null;
  suffix?: string;
  icon: React.ReactNode;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between text-muted-foreground">
        <p className="text-xs uppercase tracking-wider">{label}</p>
        <span className="text-primary">{icon}</span>
      </div>
      <p className="mt-3 text-3xl font-semibold">
        <CountUp value={value} />
        {suffix && value !== null && <span className="text-base font-normal text-muted-foreground">{suffix}</span>}
      </p>
    </Card>
  );
}

function SourceCard({
  source,
  latestRun,
  result,
  requestError,
  busy,
  disabled,
  onRun,
}: {
  source: SourceRow;
  latestRun: IngestRunRow | null;
  result: Summary | null;
  requestError: string | null;
  busy: boolean;
  disabled: boolean;
  onRun: () => void;
}) {
  const meta = SOURCE_BY_ID[source.id];
  const live = latestRun && latestRun.status === "running" ? latestRun : null;
  const showRun = live ?? (busy ? null : latestRun);
  const status = live ? "running" : busy ? "running" : source.last_status;
  const message = requestError ?? (status === "done" ? result?.message ?? null : source.last_error ?? result?.message ?? null);

  return (
    <Card
      className={cn(
        "relative overflow-hidden p-5 transition-colors",
        (live || busy) && "border-primary/40 shadow-[0_0_0_1px_hsl(148_70%_45%/0.25),0_10px_40px_-12px_hsl(148_70%_45%/0.35)]"
      )}
    >
      {(live || busy) && (
        <motion.div
          aria-hidden
          className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"
          animate={{ x: ["-100%", "100%"] }}
          transition={{ repeat: Infinity, duration: 1.6, ease: "linear" }}
        />
      )}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: meta?.color ?? "hsl(148 70% 45%)" }} />
            <h3 className="truncate font-semibold">{source.name}</h3>
          </div>
          <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
            <span className="rounded-md bg-secondary px-1.5 py-0.5 font-mono">{source.type}</span>
            <a
              href={source.base_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 hover:text-foreground"
            >
              visit <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
        <Badge variant={statusVariant(status)}>
          {status === "running" && <Loader2 className="h-3 w-3 animate-spin" />}
          {status ?? "never run"}
        </Badge>
      </div>

      <div className="mt-5 flex items-end justify-between">
        <div>
          <p className="text-3xl font-semibold leading-none">
            <CountUp value={source.items_count} />
          </p>
          <p className="mt-1 text-xs text-muted-foreground">stories</p>
        </div>
        <p className="text-right text-xs text-muted-foreground">
          {source.last_synced_at ? `synced ${timeAgo(source.last_synced_at)}` : "not synced yet"}
        </p>
      </div>

      {showRun && (
        <div className="mt-4 grid grid-cols-4 gap-2 rounded-xl border bg-secondary/40 p-2.5 text-center">
          <MiniStat label="fetched" value={showRun.fetched} />
          <MiniStat label="new" value={showRun.new_items} />
          <MiniStat label="processed" value={showRun.processed} />
          <MiniStat label="stories" value={showRun.stories_created} highlight />
        </div>
      )}

      {message && (
        <p
          className={cn(
            "mt-3 line-clamp-2 text-xs",
            requestError || status === "error" ? "text-red-300" : status === "skipped" ? "text-primary" : "text-muted-foreground"
          )}
          title={message}
        >
          {message}
        </p>
      )}

      <Button
        size="sm"
        variant={busy ? "secondary" : "outline"}
        className="mt-4 w-full"
        disabled={busy || disabled}
        onClick={onRun}
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
        {busy ? "Running…" : "Run"}
      </Button>
    </Card>
  );
}

function MiniStat({ label, value, highlight }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div>
      <p className={cn("text-base font-semibold", highlight && "text-primary")}>
        <CountUp value={value} duration={0.6} />
      </p>
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
    </div>
  );
}

// The Workplace (Stack Exchange) via the public Stack Exchange API.
import { asArray, asNumber, asRecord, asString, clampText, decodeEntities, fetchJson, politeDelay, stripHtml, toIso } from "./http";
import type { RawItemInput, SourceDef } from "./types";

const QUERIES = ["promotion", "career change", "quit", "got promoted"];

export const source: SourceDef = {
  id: "workplace-se",
  name: "The Workplace (Stack Exchange)",
  async fetchItems(ctx) {
    const out: RawItemInput[] = [];
    const seen = new Set<string>();
    const errors: string[] = [];
    let backoffMs = 0;
    for (let i = 0; i < QUERIES.length; i++) {
      const q = QUERIES[i];
      if (i > 0) await politeDelay(Math.max(500, backoffMs));
      backoffMs = 0;
      const url =
        "https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=votes&site=workplace&filter=withbody&pagesize=40" +
        `&q=${encodeURIComponent(q)}`;
      try {
        const json = asRecord(await fetchJson(url));
        const backoff = asNumber(json?.backoff);
        if (backoff && backoff > 0) {
          backoffMs = Math.min(backoff, 30) * 1000;
          ctx.log(`workplace-se: API requested backoff of ${backoff}s`);
        }
        const items = asArray(json?.items);
        let kept = 0;
        for (const raw of items) {
          const it = asRecord(raw);
          if (!it) continue;
          const id = asString(it.question_id);
          const title = asString(it.title);
          const link = asString(it.link);
          const body = asString(it.body);
          if (!id || !title || !link || !body) continue;
          const externalId = `se-workplace:${id}`;
          if (seen.has(externalId)) continue;
          seen.add(externalId);
          const owner = asString(asRecord(it.owner)?.display_name);
          out.push({
            external_id: externalId,
            url: link,
            title: decodeEntities(title).trim(),
            body: clampText(stripHtml(body), 20_000),
            author_handle: owner ? decodeEntities(owner) : null,
            posted_at: toIso(it.creation_date),
            score: Math.round(asNumber(it.score) ?? 0),
          });
          kept++;
        }
        ctx.log(`workplace-se: "${q}" → ${items.length} questions, kept ${kept}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(`${q}: ${msg}`);
        ctx.log(`workplace-se: "${q}" failed — ${msg}`);
      }
    }
    if (out.length === 0 && errors.length > 0) throw new Error(`Stack Exchange fetch failed (${errors[0]})`);
    return out;
  },
};

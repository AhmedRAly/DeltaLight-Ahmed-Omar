// Dev.to (public API) + Medium (public tag RSS feeds).
import { asArray, asNumber, asRecord, asString, clampText, fetchJson, fetchText, parseFeed, politeDelay, stripHtml, toIso } from "./http";
import type { FetchContext, RawItemInput, SourceDef } from "./types";

const DEVTO_TAGS = ["career", "startup"];
const DEVTO_BODY_CAP = 25;
const MEDIUM_FEEDS = ["https://medium.com/feed/tag/entrepreneurship", "https://medium.com/feed/tag/career-change"];

type DevtoListing = { id: number; title: string; url: string; author: string | null; posted_at: string | null; score: number };

async function fetchDevto(ctx: FetchContext, errors: string[]): Promise<RawItemInput[]> {
  const listings: DevtoListing[] = [];
  const seen = new Set<number>();
  for (let i = 0; i < DEVTO_TAGS.length; i++) {
    const tag = DEVTO_TAGS[i];
    if (i > 0) await politeDelay(400);
    try {
      const json = await fetchJson(`https://dev.to/api/articles?tag=${encodeURIComponent(tag)}&per_page=20&top=365`);
      for (const raw of asArray(json)) {
        const a = asRecord(raw);
        const id = asNumber(a?.id);
        const title = asString(a?.title);
        const url = asString(a?.url);
        if (!a || id === null || !title || !url || seen.has(id)) continue;
        seen.add(id);
        const username = asString(asRecord(a.user)?.username);
        listings.push({
          id,
          title,
          url,
          author: username ? `@${username}` : null,
          posted_at: toIso(a.published_at),
          score: Math.round(asNumber(a.positive_reactions_count) ?? asNumber(a.public_reactions_count) ?? 0),
        });
      }
      ctx.log(`devto: tag "${tag}" → ${listings.length} articles so far`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`dev.to ${tag}: ${msg}`);
      ctx.log(`devto: tag "${tag}" failed — ${msg}`);
    }
  }

  const out: RawItemInput[] = [];
  const toFetch = listings.sort((a, b) => b.score - a.score).slice(0, DEVTO_BODY_CAP);
  for (let i = 0; i < toFetch.length; i++) {
    const l = toFetch[i];
    await politeDelay(400);
    try {
      const detail = asRecord(await fetchJson(`https://dev.to/api/articles/${l.id}`));
      const markdown = asString(detail?.body_markdown) ?? "";
      const body = markdown
        .replace(/^---[\s\S]*?---\s*/, "")
        .replace(/\{%[\s\S]*?%\}/g, " ")
        .trim();
      if (!body) continue;
      out.push({
        external_id: `devto:${l.id}`,
        url: l.url,
        title: l.title,
        body: clampText(body, 20_000),
        author_handle: l.author,
        posted_at: l.posted_at,
        score: l.score,
      });
    } catch (err) {
      ctx.log(`devto: article ${l.id} failed — ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  ctx.log(`devto: fetched ${out.length} article bodies`);
  return out;
}

async function fetchMedium(ctx: FetchContext, errors: string[]): Promise<RawItemInput[]> {
  const out: RawItemInput[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < MEDIUM_FEEDS.length; i++) {
    const feedUrl = MEDIUM_FEEDS[i];
    if (i > 0) await politeDelay(600);
    try {
      const xml = await fetchText(feedUrl, { headers: { Accept: "application/rss+xml, application/xml;q=0.9" } });
      const entries = parseFeed(xml);
      let kept = 0;
      for (const e of entries) {
        const url = e.link.replace(/\?.*$/, "");
        const idMatch = (e.guid ?? url).match(/([0-9a-f]{10,14})(?:$|[/?#])/i);
        const externalId = `medium:${idMatch ? idMatch[1] : url.replace(/^https?:\/\//i, "")}`;
        if (seen.has(externalId)) continue;
        const body = stripHtml(e.html);
        if (!body) continue;
        seen.add(externalId);
        out.push({
          external_id: externalId,
          url,
          title: e.title,
          body: clampText(body, 20_000),
          author_handle: e.author,
          posted_at: e.published,
          score: 0,
        });
        kept++;
      }
      ctx.log(`medium: ${feedUrl} → ${entries.length} entries, kept ${kept}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`medium: ${msg}`);
      ctx.log(`medium: ${feedUrl} failed — ${msg}`);
    }
  }
  return out;
}

export const source: SourceDef = {
  id: "devto-medium",
  name: "Dev.to + Medium",
  async fetchItems(ctx) {
    const errors: string[] = [];
    const devto = await fetchDevto(ctx, errors);
    const medium = await fetchMedium(ctx, errors);
    const all = [...devto, ...medium];
    if (all.length === 0 && errors.length > 0) throw new Error(`Dev.to/Medium fetch failed (${errors[0]})`);
    return all;
  },
};

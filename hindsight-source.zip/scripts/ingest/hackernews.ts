// Hacker News via the public Algolia search API.
import { asArray, asNumber, asRecord, asString, clampText, decodeEntities, fetchJson, politeDelay, stripHtml, toIso } from "./http";
import type { RawItemInput, SourceDef } from "./types";

const QUERIES = [
  "Ask HN quit my job",
  "Show HN",
  "post-mortem",
  "lessons from my startup",
  "I quit my job",
  "shutting down my startup",
];
const MIN_STORY_TEXT = 400;

export const source: SourceDef = {
  id: "hackernews",
  name: "Hacker News",
  async fetchItems(ctx) {
    const out: RawItemInput[] = [];
    const seen = new Set<string>();
    const errors: string[] = [];
    for (let i = 0; i < QUERIES.length; i++) {
      const q = QUERIES[i];
      if (i > 0) await politeDelay(400);
      const url = `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(q)}&tags=story&hitsPerPage=40`;
      try {
        const json = await fetchJson(url);
        const hits = asArray(asRecord(json)?.hits);
        let kept = 0;
        for (const h of hits) {
          const hit = asRecord(h);
          if (!hit) continue;
          const id = asString(hit.objectID);
          const title = asString(hit.title);
          const storyText = asString(hit.story_text) ?? "";
          if (!id || !title || storyText.length < MIN_STORY_TEXT) continue;
          const externalId = `hn:${id}`;
          if (seen.has(externalId)) continue;
          seen.add(externalId);
          const author = asString(hit.author);
          out.push({
            external_id: externalId,
            url: `https://news.ycombinator.com/item?id=${id}`,
            title: decodeEntities(title).trim(),
            body: clampText(stripHtml(storyText), 20_000),
            author_handle: author || null,
            posted_at: toIso(hit.created_at) ?? toIso(hit.created_at_i),
            score: Math.round(asNumber(hit.points) ?? 0),
          });
          kept++;
        }
        ctx.log(`hn: "${q}" → ${hits.length} hits, kept ${kept}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(`${q}: ${msg}`);
        ctx.log(`hn: "${q}" failed — ${msg}`);
      }
    }
    if (out.length === 0 && errors.length > 0) throw new Error(`Hacker News fetch failed (${errors[0]})`);
    return out;
  },
};

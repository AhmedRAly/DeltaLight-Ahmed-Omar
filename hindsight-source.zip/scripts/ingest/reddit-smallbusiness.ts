import { fetchSubreddits } from "./reddit";
import type { SourceDef } from "./types";

export const source: SourceDef = {
  id: "reddit-smallbusiness",
  name: "r/smallbusiness",
  fetchItems: (ctx) => fetchSubreddits(ctx, { subreddits: ["smallbusiness"] }),
};

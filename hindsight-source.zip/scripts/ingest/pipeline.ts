// Ingestion pipeline: fetch → store raw items → prefilter → AI classify → AI extract → embed → store story.
// Never throws out of runSource: every DB/AI call is wrapped so a bad item never aborts a run.
// Relative imports only (used by tsx scripts and by Next.js route handlers).
import { chatJSON, embed, hasOpenAI } from "../../lib/ai";
import type { Database } from "../../lib/database.types";
import { storyClassifierSchema, storyExtractionSchema } from "../../lib/schemas";
import { createAdminClient, hasSupabase, type AdminClient } from "../../lib/supabase/admin";
import { toVector } from "../../lib/utils";
import { clampText } from "./http";
import { getSourceDef, SOURCE_DEFS } from "./registry";
import { errorMessage, isSkipError, type RawItemInput } from "./types";

export type RunStatus = "done" | "error" | "skipped";

export type RunSummary = {
  source_id: string;
  status: RunStatus;
  fetched: number;
  new_items: number;
  processed: number;
  stories_created: number;
  message: string;
};

export type RunOptions = {
  maxProcess?: number;
  log?: (m: string) => void;
};

type RunUpdate = Database["public"]["Tables"]["ingest_runs"]["Update"];
type RawItemInsert = Database["public"]["Tables"]["raw_items"]["Insert"];
type RawItemUpdate = Database["public"]["Tables"]["raw_items"]["Update"];
type StoryInsert = Database["public"]["Tables"]["stories"]["Insert"];
type RawItemRow = Database["public"]["Tables"]["raw_items"]["Row"];

const UPSERT_CHUNK = 50;
const DEFAULT_MAX_PROCESS = 15;
const MIN_BODY_CHARS = 400;
const FIRST_PERSON = /\b(i|i'm|i've|my|we|our)\b/i;
const OUTCOME_WORDS =
  /quit|launched|revenue|mrr|promot|fired|laid off|failed|shut down|hired|raised|lessons|years? later|months? later|salary|customers|profit|switched/i;
const NO_AI_MESSAGE = "OPENAI_API_KEY missing — raw items stored, stories need AI parsing";

const CLASSIFIER_SYSTEM =
  'Answer whether the text is a FIRST-PERSON account by the author of a real decision they made AND what happened after (an outcome, even partial). Questions asking for advice with no outcome = false. Return JSON {"is_story": boolean, "reason": string}';

const EXTRACTION_SYSTEM = [
  "You extract a structured decision story from a public first-person post. Rules:",
  "- Extract only what is explicitly stated in the text. Use null when something is unknown. Never invent numbers, dates, names or outcomes.",
  "- revenue_or_salary_mentioned must be a short quote copied verbatim from the text (e.g. \"$4k MRR\"), or null if the text states no revenue/salary figure.",
  "- lessons: 1-5 short imperative sentences (e.g. \"Validate demand before building\") grounded in what the author says they learned or what clearly happened.",
  "- path: \"corporate\" for employment, promotion, or career switches within employment; otherwise \"business\" (starting, running or selling a business/product).",
  "- surprise_tags: 1-4 lowercase tags of 1-3 words each describing what surprised the author or was unexpected (e.g. \"slow growth\", \"burnout\", \"easier than expected\").",
  "- tldr: exactly 2 sentences, neutral third person, summarising the decision and what happened.",
  "- decision_text: one sentence phrased as the decision the author faced (e.g. \"Quit a stable job to work on a SaaS full-time\").",
  "",
  "Return a single JSON object with exactly these keys:",
  "title (string, short descriptive headline),",
  "category (one of: business, career, money, education, relationships, location, other),",
  "path (one of: business, corporate),",
  "decision_text (string),",
  "what_they_chose (string or null),",
  "starting_point (string or null — their situation before deciding),",
  "outcome (string or null — what happened after),",
  "outcome_type (one of: success, mixed, failure, ongoing),",
  "revenue_or_salary_mentioned (string quoted from text, or null),",
  "timeline (string or null, e.g. \"18 months\"),",
  "lessons (array of strings),",
  "surprise_tags (array of strings),",
  "tldr (string).",
].join("\n");

function defaultLog(sourceId: string) {
  return (m: string) => console.log(`[${sourceId}] ${m}`);
}

function wordCount(text: string): number {
  const m = text.match(/\S+/g);
  return m ? m.length : 0;
}

function dedupeItems(items: RawItemInput[]): RawItemInput[] {
  const map = new Map<string, RawItemInput>();
  for (const it of items) {
    if (!it.external_id || !it.url || !it.title) continue;
    if (!map.has(it.external_id)) map.set(it.external_id, it);
  }
  return Array.from(map.values());
}

function normalizeTags(tags: string[]): string[] {
  const out = new Set<string>();
  for (const t of tags) {
    const n = t.trim().toLowerCase().replace(/[^a-z0-9 \-']/g, "").replace(/\s+/g, " ").trim();
    if (n && n.split(" ").length <= 3) out.add(n.slice(0, 40));
  }
  return Array.from(out).slice(0, 5);
}

export async function runSource(sourceId: string, opts: RunOptions = {}): Promise<RunSummary> {
  const log = opts.log ?? defaultLog(sourceId);
  const maxProcess = Math.max(1, Math.min(60, opts.maxProcess ?? DEFAULT_MAX_PROCESS));
  const summary: RunSummary = {
    source_id: sourceId,
    status: "done",
    fetched: 0,
    new_items: 0,
    processed: 0,
    stories_created: 0,
    message: "",
  };

  const def = getSourceDef(sourceId);
  if (!def) return { ...summary, status: "error", message: `Unknown source: ${sourceId}` };
  if (!hasSupabase()) return { ...summary, status: "error", message: "Supabase is not configured" };

  let maybeDb: AdminClient | null = null;
  try {
    maybeDb = createAdminClient();
  } catch (err) {
    return { ...summary, status: "error", message: errorMessage(err) };
  }
  const db: AdminClient = maybeDb;

  // 1. Create the run row (drives the live admin console via Realtime).
  let runId: string | null = null;
  try {
    const { data, error } = await db
      .from("ingest_runs")
      .insert({ source_id: sourceId, status: "running" })
      .select("id")
      .single();
    if (error) log(`could not create ingest_runs row: ${error.message}`);
    runId = data?.id ?? null;
  } catch (err) {
    log(`could not create ingest_runs row: ${errorMessage(err)}`);
  }

  const updateRun = async (patch: RunUpdate): Promise<void> => {
    if (!runId) return;
    try {
      const { error } = await db.from("ingest_runs").update(patch).eq("id", runId);
      if (error) log(`ingest_runs update failed: ${error.message}`);
    } catch (err) {
      log(`ingest_runs update failed: ${errorMessage(err)}`);
    }
  };

  const progress = (): RunUpdate => ({
    fetched: summary.fetched,
    new_items: summary.new_items,
    processed: summary.processed,
    stories_created: summary.stories_created,
  });

  const finish = async (): Promise<RunSummary> => {
    const now = new Date().toISOString();
    await updateRun({ ...progress(), status: summary.status, message: summary.message || null, finished_at: now });
    let itemsCount: number | null = null;
    try {
      const { count, error } = await db
        .from("stories")
        .select("id", { count: "exact", head: true })
        .eq("source_id", sourceId);
      if (error) log(`story count failed: ${error.message}`);
      else itemsCount = count ?? 0;
    } catch (err) {
      log(`story count failed: ${errorMessage(err)}`);
    }
    try {
      const patch: Database["public"]["Tables"]["sources"]["Update"] = {
        last_synced_at: now,
        last_status: summary.status,
        last_error: summary.status === "done" ? null : summary.message || null,
      };
      if (itemsCount !== null) patch.items_count = itemsCount;
      const { error } = await db.from("sources").update(patch).eq("id", sourceId);
      if (error) log(`sources update failed: ${error.message}`);
    } catch (err) {
      log(`sources update failed: ${errorMessage(err)}`);
    }
    log(
      `${summary.status}: fetched ${summary.fetched}, new ${summary.new_items}, processed ${summary.processed}, stories ${summary.stories_created}${summary.message ? ` — ${summary.message}` : ""}`
    );
    return { ...summary };
  };

  // 2. Fetch from the source.
  let items: RawItemInput[];
  try {
    log(`fetching from ${def.name}…`);
    items = dedupeItems(await def.fetchItems({ log }));
    summary.fetched = items.length;
    log(`fetched ${items.length} items`);
    await updateRun(progress());
  } catch (err) {
    summary.status = isSkipError(err) ? "skipped" : "error";
    summary.message = clampText(errorMessage(err), 500);
    return finish();
  }

  // 3. Store raw items (ignore ones we already have).
  for (let i = 0; i < items.length; i += UPSERT_CHUNK) {
    const rows: RawItemInsert[] = items.slice(i, i + UPSERT_CHUNK).map((it) => ({
      source_id: sourceId,
      external_id: it.external_id,
      url: it.url,
      title: clampText(it.title, 300),
      body: it.body,
      author_handle: it.author_handle,
      posted_at: it.posted_at,
      score: Number.isFinite(it.score) ? Math.round(it.score) : 0,
    }));
    try {
      const { data, error } = await db
        .from("raw_items")
        .upsert(rows, { onConflict: "external_id", ignoreDuplicates: true })
        .select("id");
      if (error) log(`raw_items upsert failed: ${error.message}`);
      else summary.new_items += data?.length ?? 0;
    } catch (err) {
      log(`raw_items upsert failed: ${errorMessage(err)}`);
    }
  }
  log(`stored ${summary.new_items} new raw items`);
  await updateRun(progress());

  // 4. Process the highest-scoring unprocessed items.
  let queue: RawItemRow[] = [];
  try {
    const { data, error } = await db
      .from("raw_items")
      .select("*")
      .eq("source_id", sourceId)
      .eq("processed", false)
      .order("score", { ascending: false })
      .limit(maxProcess);
    if (error) log(`loading unprocessed items failed: ${error.message}`);
    queue = data ?? [];
  } catch (err) {
    log(`loading unprocessed items failed: ${errorMessage(err)}`);
  }

  const markItem = async (id: string, patch: RawItemUpdate): Promise<void> => {
    try {
      const { error } = await db.from("raw_items").update(patch).eq("id", id);
      if (error) log(`raw_items update failed: ${error.message}`);
    } catch (err) {
      log(`raw_items update failed: ${errorMessage(err)}`);
    }
  };

  let consecutiveAiFailures = 0;
  for (const item of queue) {
    try {
      const text = `${item.title}\n\n${item.body}`;

      // 4a. Cheap keyword prefilter.
      let reject: string | null = null;
      if (item.body.length < MIN_BODY_CHARS) reject = "prefilter: too short";
      else if (!FIRST_PERSON.test(text)) reject = "prefilter: not first-person";
      else if (!OUTCOME_WORDS.test(text)) reject = "prefilter: no outcome keywords";
      if (reject) {
        await markItem(item.id, { processed: true, is_story: false, process_note: reject });
        summary.processed++;
        await updateRun(progress());
        continue;
      }

      if (!hasOpenAI()) {
        summary.message = NO_AI_MESSAGE;
        log(NO_AI_MESSAGE);
        break;
      }

      // 4b. Classify.
      const verdict = await chatJSON({
        system: CLASSIFIER_SYSTEM,
        user: `Title: ${item.title}\n\n${clampText(item.body, 9000)}`,
        schema: storyClassifierSchema,
        maxTokens: 150,
      });
      if (!verdict) {
        consecutiveAiFailures++;
        if (consecutiveAiFailures >= 3) {
          summary.message = "AI classification is failing repeatedly; stopped early";
          log(summary.message);
          break;
        }
        await markItem(item.id, { processed: true, is_story: null, process_note: "classifier returned no result" });
        summary.processed++;
        await updateRun(progress());
        continue;
      }
      consecutiveAiFailures = 0;
      if (!verdict.is_story) {
        await markItem(item.id, {
          processed: true,
          is_story: false,
          process_note: clampText(`classifier: ${verdict.reason ?? "not a decision story"}`, 300),
        });
        summary.processed++;
        await updateRun(progress());
        continue;
      }

      // 4c. Extract.
      const story = await chatJSON({
        system: EXTRACTION_SYSTEM,
        user: `Title: ${item.title}\nSource URL: ${item.url}\n\n${clampText(item.body, 12000)}`,
        schema: storyExtractionSchema,
        maxTokens: 900,
      });
      if (!story) {
        await markItem(item.id, { processed: true, is_story: true, process_note: "extraction failed" });
        summary.processed++;
        await updateRun(progress());
        continue;
      }

      // 4d. Embed + insert.
      const vector = await embed(`${story.tldr}\n${story.decision_text}`);
      const row: StoryInsert = {
        source_id: sourceId,
        raw_item_id: item.id,
        url: item.url,
        title: clampText(item.title.trim() || story.title, 160),
        category: story.category,
        path: story.path,
        decision_text: story.decision_text,
        what_they_chose: story.what_they_chose,
        starting_point: story.starting_point,
        outcome: story.outcome,
        outcome_type: story.outcome_type,
        revenue_or_salary_mentioned: story.revenue_or_salary_mentioned,
        timeline: story.timeline,
        lessons: story.lessons.map((l) => l.trim()).filter(Boolean).slice(0, 5),
        surprise_tags: normalizeTags(story.surprise_tags),
        tldr: story.tldr,
        read_time_min: Math.max(1, Math.round(wordCount(item.body) / 220)),
        author_handle: item.author_handle,
        embedding: vector ? toVector(vector) : null,
      };
      let created = false;
      try {
        const { error } = await db.from("stories").insert(row);
        if (error) {
          if (error.code === "23505") log(`story for ${item.external_id} already exists`);
          else log(`story insert failed for ${item.external_id}: ${error.message}`);
        } else {
          created = true;
        }
      } catch (err) {
        log(`story insert failed for ${item.external_id}: ${errorMessage(err)}`);
      }
      await markItem(item.id, {
        processed: true,
        is_story: true,
        process_note: created ? (vector ? "story created" : "story created (no embedding)") : "story insert failed or duplicate",
      });
      summary.processed++;
      if (created) {
        summary.stories_created++;
        log(`+ story: ${row.title}`);
      }
      await updateRun(progress());
    } catch (err) {
      log(`item ${item.external_id} failed: ${errorMessage(err)}`);
    }
  }

  if (!summary.message) {
    summary.message =
      queue.length === 0
        ? "No unprocessed items"
        : `Processed ${summary.processed} item(s), created ${summary.stories_created} stor${summary.stories_created === 1 ? "y" : "ies"}`;
  }
  return finish();
}

export async function runAll(opts: RunOptions = {}): Promise<RunSummary[]> {
  const out: RunSummary[] = [];
  for (const def of SOURCE_DEFS) {
    try {
      out.push(await runSource(def.id, opts));
    } catch (err) {
      out.push({
        source_id: def.id,
        status: "error",
        fetched: 0,
        new_items: 0,
        processed: 0,
        stories_created: 0,
        message: errorMessage(err),
      });
    }
  }
  return out;
}

export const SOURCE_IDS: string[] = SOURCE_DEFS.map((s) => s.id);

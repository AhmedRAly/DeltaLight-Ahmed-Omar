// Product Hunt GraphQL API v2 (requires a developer token).
import { asArray, asNumber, asRecord, asString, clampText, fetchJson, toIso } from "./http";
import { SkipError, type RawItemInput, type SourceDef } from "./types";

const QUERY = `
query TopPosts {
  posts(order: VOTES, first: 30) {
    edges {
      node {
        id
        name
        tagline
        description
        url
        votesCount
        createdAt
        makers { username }
        comments(first: 10) {
          edges { node { body user { username } } }
        }
      }
    }
  }
}`;

export const source: SourceDef = {
  id: "producthunt",
  name: "Product Hunt",
  async fetchItems(ctx) {
    const token = process.env.PRODUCTHUNT_TOKEN;
    if (!token) throw new SkipError("PRODUCTHUNT_TOKEN not set");
    const json = asRecord(
      await fetchJson("https://api.producthunt.com/v2/api/graphql", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ query: QUERY }),
      })
    );
    const errors = asArray(json?.errors);
    if (errors.length > 0) {
      const first = asString(asRecord(errors[0])?.message) ?? "unknown GraphQL error";
      throw new Error(`Product Hunt API error: ${first}`);
    }
    const edges = asArray(asRecord(asRecord(json?.data)?.posts)?.edges);
    const out: RawItemInput[] = [];
    for (const e of edges) {
      const node = asRecord(asRecord(e)?.node);
      if (!node) continue;
      const id = asString(node.id);
      const name = asString(node.name);
      const url = asString(node.url);
      if (!id || !name || !url) continue;
      const tagline = asString(node.tagline) ?? "";
      const description = asString(node.description) ?? "";
      const makers = asArray(node.makers)
        .map((m) => asString(asRecord(m)?.username))
        .filter((u): u is string => Boolean(u));
      const makerSet = new Set(makers.map((m) => m.toLowerCase()));
      const makerComments = asArray(asRecord(node.comments)?.edges)
        .map((c) => asRecord(asRecord(c)?.node))
        .filter((c): c is Record<string, unknown> => c !== null)
        .filter((c) => {
          const u = asString(asRecord(c.user)?.username);
          return u !== null && makerSet.has(u.toLowerCase());
        })
        .map((c) => asString(c.body) ?? "")
        .filter((b) => b.trim().length > 0);
      const body = [description, ...makerComments.map((b) => `Maker comment: ${b}`)].join("\n\n").trim();
      out.push({
        external_id: `ph:${id}`,
        url,
        title: tagline ? `${name} — ${tagline}` : name,
        body: clampText(body, 20_000),
        author_handle: makers[0] ?? null,
        posted_at: toIso(node.createdAt),
        score: Math.round(asNumber(node.votesCount) ?? 0),
      });
    }
    ctx.log(`producthunt: ${edges.length} posts, kept ${out.length}`);
    return out;
  },
};

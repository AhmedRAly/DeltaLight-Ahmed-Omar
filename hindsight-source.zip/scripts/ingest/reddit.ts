// Shared Reddit fetcher. Uses OAuth (client_credentials) when REDDIT_CLIENT_ID/SECRET are set,
// otherwise the public .json listing. Only self-text posts are kept; only public handles are stored.
import { asArray, asNumber, asRecord, asString, clampText, decodeEntities, fetchJson, politeDelay, toIso } from "./http";
import type { FetchContext, RawItemInput } from "./types";

const SUBREDDIT_DELAY_MS = 1200;
const MAX_BODY_CHARS = 20_000;

type Token = { value: string; expiresAt: number };
let cachedToken: Token | null = null;

async function getRedditToken(): Promise<string | null> {
  const id = process.env.REDDIT_CLIENT_ID;
  const secret = process.env.REDDIT_CLIENT_SECRET;
  if (!id || !secret) return null;
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) return cachedToken.value;
  const basic = Buffer.from(`${id}:${secret}`).toString("base64");
  const json = await fetchJson("https://www.reddit.com/api/v1/access_token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const rec = asRecord(json);
  const token = asString(rec?.access_token);
  if (!token) throw new Error("Reddit OAuth did not return an access token");
  const expiresIn = asNumber(rec?.expires_in) ?? 3600;
  cachedToken = { value: token, expiresAt: Date.now() + expiresIn * 1000 };
  return token;
}

function mapPost(raw: unknown): RawItemInput | null {
  const post = asRecord(asRecord(raw)?.data);
  if (!post) return null;
  const id = asString(post.id);
  const title = asString(post.title);
  const selftext = asString(post.selftext) ?? "";
  const permalink = asString(post.permalink);
  const author = asString(post.author);
  if (!id || !title || !permalink) return null;
  if (post.is_self !== true) return null;
  if (post.over_18 === true || post.stickied === true) return null;
  if (post.removed_by_category !== null && post.removed_by_category !== undefined) return null;
  const body = selftext.trim();
  if (!body || body === "[removed]" || body === "[deleted]") return null;
  return {
    external_id: `reddit:${id}`,
    url: `https://www.reddit.com${permalink}`,
    title: decodeEntities(title).trim(),
    body: clampText(decodeEntities(body), MAX_BODY_CHARS),
    author_handle: author && author !== "[deleted]" ? `u/${author}` : null,
    posted_at: toIso(post.created_utc),
    score: Math.round(asNumber(post.score) ?? 0),
  };
}

export type RedditOptions = {
  subreddits: string[];
  /** Optional keyword filter applied to title + body. */
  keywordFilter?: RegExp;
  limit?: number;
};

export async function fetchSubreddits(ctx: FetchContext, opts: RedditOptions): Promise<RawItemInput[]> {
  const limit = opts.limit ?? 100;
  const token = await getRedditToken();
  ctx.log(token ? "reddit: using OAuth API" : "reddit: using public JSON listing");
  const out: RawItemInput[] = [];
  const seen = new Set<string>();
  const errors: string[] = [];

  for (let i = 0; i < opts.subreddits.length; i++) {
    const sub = opts.subreddits[i];
    if (i > 0) await politeDelay(SUBREDDIT_DELAY_MS);
    const url = token
      ? `https://oauth.reddit.com/r/${encodeURIComponent(sub)}/top?t=year&limit=${limit}&raw_json=1`
      : `https://www.reddit.com/r/${encodeURIComponent(sub)}/top.json?t=year&limit=${limit}&raw_json=1`;
    try {
      const json = await fetchJson(url, token ? { headers: { Authorization: `Bearer ${token}` } } : {});
      const children = asArray(asRecord(asRecord(json)?.data)?.children);
      let kept = 0;
      for (const child of children) {
        const item = mapPost(child);
        if (!item || seen.has(item.external_id)) continue;
        if (opts.keywordFilter && !opts.keywordFilter.test(`${item.title}\n${item.body}`)) continue;
        seen.add(item.external_id);
        out.push(item);
        kept++;
      }
      ctx.log(`reddit: r/${sub} → ${children.length} posts, kept ${kept}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`r/${sub}: ${msg}`);
      ctx.log(`reddit: r/${sub} failed — ${msg}`);
    }
  }

  if (out.length === 0 && errors.length > 0) {
    throw new Error(`Reddit fetch failed (${errors.join("; ")})`);
  }
  return out;
}

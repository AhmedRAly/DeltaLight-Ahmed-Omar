// Ordered list of source definitions (same order as lib/constants SOURCES).
import { source as redditEntrepreneur } from "./reddit-entrepreneur";
import { source as redditStartups } from "./reddit-startups";
import { source as redditSmallbusiness } from "./reddit-smallbusiness";
import { source as redditCareer } from "./reddit-career";
import { source as redditSideproject } from "./reddit-sideproject";
import { source as hackernews } from "./hackernews";
import { source as indiehackers } from "./indiehackers";
import { source as producthunt } from "./producthunt";
import { source as workplaceSe } from "./workplace-se";
import { source as devtoMedium } from "./devto-medium";
import type { SourceDef } from "./types";

export const SOURCE_DEFS: SourceDef[] = [
  redditEntrepreneur,
  redditStartups,
  redditSmallbusiness,
  redditCareer,
  redditSideproject,
  hackernews,
  indiehackers,
  producthunt,
  workplaceSe,
  devtoMedium,
];

export function getSourceDef(id: string): SourceDef | undefined {
  return SOURCE_DEFS.find((s) => s.id === id);
}

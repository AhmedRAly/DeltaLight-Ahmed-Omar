import { fetchSubreddits } from "./reddit";
import type { SourceDef } from "./types";

export const source: SourceDef = {
  id: "reddit-startups",
  name: "r/startups",
  fetchItems: (ctx) => fetchSubreddits(ctx, { subreddits: ["startups"] }),
};

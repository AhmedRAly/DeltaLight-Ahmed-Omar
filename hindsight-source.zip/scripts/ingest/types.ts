// Shared types for the ingestion pipeline. Relative imports only (scripts run via tsx).

export type RawItemInput = {
  /** Globally unique id, prefixed with the source, e.g. "hn:123". */
  external_id: string;
  url: string;
  title: string;
  body: string;
  /** Public handle only (e.g. "u/name"); never real names or emails. */
  author_handle: string | null;
  /** ISO timestamp or null when unknown. */
  posted_at: string | null;
  score: number;
};

export type FetchContext = {
  log: (msg: string) => void;
};

export type SourceDef = {
  id: string;
  name: string;
  fetchItems: (ctx: FetchContext) => Promise<RawItemInput[]>;
};

/** Thrown when a source is not configured (missing token, no public feed). The pipeline marks it "skipped". */
export class SkipError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SkipError";
  }
}

export function isSkipError(err: unknown): err is SkipError {
  return err instanceof SkipError || (err instanceof Error && err.name === "SkipError");
}

export function errorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;
  try {
    return JSON.stringify(err);
  } catch {
    return "Unknown error";
  }
}

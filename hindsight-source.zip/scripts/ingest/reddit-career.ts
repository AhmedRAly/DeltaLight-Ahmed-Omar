import { fetchSubreddits } from "./reddit";
import type { SourceDef } from "./types";

export const source: SourceDef = {
  id: "reddit-career",
  name: "r/careerguidance + r/careeradvice",
  fetchItems: (ctx) => fetchSubreddits(ctx, { subreddits: ["careerguidance", "careeradvice"] }),
};

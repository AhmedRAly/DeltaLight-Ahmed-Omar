import { fetchSubreddits } from "./reddit";
import type { SourceDef } from "./types";

const OUTCOME_KEYWORDS = /update|revenue|mrr|launched|failed|lessons/i;

export const source: SourceDef = {
  id: "reddit-sideproject",
  name: "r/SideProject + r/SaaS",
  fetchItems: (ctx) =>
    fetchSubreddits(ctx, { subreddits: ["sideproject", "SaaS"], keywordFilter: OUTCOME_KEYWORDS }),
};

// Usage:
//   npm run ingest                       # all sources
//   npm run ingest -- --source hackernews --max 20
import { config } from "dotenv";

config({ path: ".env.local" });
config();

function parseArgs(argv: string[]): { source: string | null; max: number } {
  let source: string | null = null;
  let max = 40;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--source" && argv[i + 1]) {
      source = argv[++i];
    } else if (arg.startsWith("--source=")) {
      source = arg.slice("--source=".length);
    } else if (arg === "--max" && argv[i + 1]) {
      const n = Number(argv[++i]);
      if (Number.isFinite(n) && n > 0) max = Math.floor(n);
    } else if (arg.startsWith("--max=")) {
      const n = Number(arg.slice("--max=".length));
      if (Number.isFinite(n) && n > 0) max = Math.floor(n);
    } else if (!arg.startsWith("--") && source === null) {
      source = arg;
    }
  }
  return { source, max: Math.min(60, max) };
}

function pad(value: string | number, width: number): string {
  const s = String(value);
  return s.length >= width ? s.slice(0, width) : s + " ".repeat(width - s.length);
}

async function main(): Promise<void> {
  const { runSource, runAll, SOURCE_IDS } = await import("./pipeline");
  const { source, max } = parseArgs(process.argv.slice(2));

  if (source && source !== "all" && !SOURCE_IDS.includes(source)) {
    console.error(`Unknown source "${source}". Valid ids: ${SOURCE_IDS.join(", ")}`);
    process.exitCode = 0;
    return;
  }

  console.log(`Hindsight ingestion — ${source && source !== "all" ? source : "all sources"} (max ${max} items processed per source)\n`);
  const summaries = source && source !== "all" ? [await runSource(source, { maxProcess: max })] : await runAll({ maxProcess: max });

  console.log("\nSummary");
  const header = `${pad("source", 22)} ${pad("status", 8)} ${pad("fetched", 8)} ${pad("new", 6)} ${pad("processed", 10)} ${pad("stories", 8)} message`;
  console.log(header);
  console.log("-".repeat(header.length + 20));
  for (const s of summaries) {
    console.log(
      `${pad(s.source_id, 22)} ${pad(s.status, 8)} ${pad(s.fetched, 8)} ${pad(s.new_items, 6)} ${pad(s.processed, 10)} ${pad(s.stories_created, 8)} ${s.message}`
    );
  }
  const totalStories = summaries.reduce((a, s) => a + s.stories_created, 0);
  const failed = summaries.filter((s) => s.status === "error").length;
  console.log(`\n${totalStories} new stories. ${failed} source(s) errored.`);
}

main()
  .catch((err: unknown) => {
    console.error("Ingestion crashed:", err instanceof Error ? err.message : String(err));
  })
  .finally(() => {
    process.exitCode = 0;
  });

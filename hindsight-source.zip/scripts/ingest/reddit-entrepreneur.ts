import { fetchSubreddits } from "./reddit";
import type { SourceDef } from "./types";

export const source: SourceDef = {
  id: "reddit-entrepreneur",
  name: "r/Entrepreneur",
  fetchItems: (ctx) => fetchSubreddits(ctx, { subreddits: ["Entrepreneur"] }),
};

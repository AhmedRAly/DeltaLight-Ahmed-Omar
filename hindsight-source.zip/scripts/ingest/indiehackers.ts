// Indie Hackers — best-effort public RSS. Indie Hackers has no official public API; we try a short
// list of candidate feed URLs and skip the source cleanly if none is reachable.
import { clampText, fetchText, parseFeed, politeDelay, stripHtml } from "./http";
import { SkipError, type RawItemInput, type SourceDef } from "./types";

const CANDIDATE_FEEDS = [
  "https://www.indiehackers.com/feed.xml",
  "https://feed.indiehackers.world/posts.rss",
];

export const source: SourceDef = {
  id: "indiehackers",
  name: "Indie Hackers",
  async fetchItems(ctx) {
    const attempts: string[] = [];
    for (let i = 0; i < CANDIDATE_FEEDS.length; i++) {
      const feedUrl = CANDIDATE_FEEDS[i];
      if (i > 0) await politeDelay(500);
      try {
        const xml = await fetchText(feedUrl, {
          headers: { Accept: "application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.8" },
        });
        const entries = parseFeed(xml);
        if (entries.length === 0) {
          attempts.push(`${feedUrl}: empty feed`);
          continue;
        }
        const out: RawItemInput[] = [];
        const seen = new Set<string>();
        for (const e of entries) {
          const key = e.link.replace(/[?#].*$/, "");
          const externalId = `ih:${key.replace(/^https?:\/\/(www\.)?/i, "")}`;
          if (seen.has(externalId)) continue;
          seen.add(externalId);
          out.push({
            external_id: externalId,
            url: e.link,
            title: e.title,
            body: clampText(stripHtml(e.html), 20_000),
            author_handle: e.author,
            posted_at: e.published,
            score: 0,
          });
        }
        ctx.log(`indiehackers: ${feedUrl} → ${out.length} entries`);
        return out;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        attempts.push(`${feedUrl}: ${msg}`);
        ctx.log(`indiehackers: ${feedUrl} failed — ${msg}`);
      }
    }
    throw new SkipError(`Indie Hackers: no public feed reachable (${attempts.join("; ")})`);
  },
};

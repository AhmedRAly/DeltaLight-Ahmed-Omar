// Polite HTTP helpers for ingestion: descriptive User-Agent, timeouts, one retry with backoff.
import { XMLParser } from "fast-xml-parser";

export const USER_AGENT = "Hindsight/1.0 (hackathon research app; attributes and links original public posts)";

const TIMEOUT_MS = 15_000;
const MAX_RETRY_WAIT_MS = 10_000;

export class HttpError extends Error {
  readonly status: number | null;
  readonly url: string;
  constructor(message: string, url: string, status: number | null) {
    super(message);
    this.name = "HttpError";
    this.status = status;
    this.url = url;
  }
}

export function politeDelay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export type RequestOptions = {
  method?: "GET" | "POST";
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
};

function retryWaitMs(res: Response | null, attempt: number): number {
  const header = res?.headers.get("retry-after");
  if (header) {
    const secs = Number(header);
    if (Number.isFinite(secs)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(0, secs * 1000));
    const date = Date.parse(header);
    if (Number.isFinite(date)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(0, date - Date.now()));
  }
  return Math.min(MAX_RETRY_WAIT_MS, 1500 * (attempt + 1));
}

function shortUrl(url: string): string {
  try {
    const u = new URL(url);
    return `${u.host}${u.pathname}`;
  } catch {
    return url.slice(0, 120);
  }
}

async function request(url: string, opts: RequestOptions = {}): Promise<Response> {
  let lastError: HttpError | null = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? TIMEOUT_MS);
    let res: Response | null = null;
    try {
      res = await fetch(url, {
        method: opts.method ?? "GET",
        headers: { "User-Agent": USER_AGENT, ...(opts.headers ?? {}) },
        body: opts.body,
        signal: controller.signal,
      });
    } catch (err) {
      const aborted = err instanceof Error && err.name === "AbortError";
      lastError = new HttpError(
        aborted ? `Request timed out: ${shortUrl(url)}` : `Network error for ${shortUrl(url)}: ${err instanceof Error ? err.message : String(err)}`,
        url,
        null
      );
    } finally {
      clearTimeout(timer);
    }

    if (res) {
      if (res.ok) return res;
      lastError = new HttpError(`HTTP ${res.status} from ${shortUrl(url)}`, url, res.status);
      const retryable = res.status === 429 || res.status >= 500;
      if (!retryable) throw lastError;
    }
    if (attempt === 0) await politeDelay(retryWaitMs(res, attempt));
  }
  throw lastError ?? new HttpError(`Request failed: ${shortUrl(url)}`, url, null);
}

export async function fetchText(url: string, opts: RequestOptions = {}): Promise<string> {
  const res = await request(url, opts);
  return res.text();
}

export async function fetchJson(url: string, opts: RequestOptions = {}): Promise<unknown> {
  const res = await request(url, {
    ...opts,
    headers: { Accept: "application/json", ...(opts.headers ?? {}) },
  });
  const text = await res.text();
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new HttpError(`Invalid JSON from ${shortUrl(url)}`, url, res.status);
  }
}

// ---------------------------------------------------------------------------
// Text helpers
// ---------------------------------------------------------------------------

const NAMED_ENTITIES: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
  ndash: "–",
  mdash: "—",
  hellip: "…",
  lsquo: "‘",
  rsquo: "’",
  ldquo: "“",
  rdquo: "”",
  bull: "•",
  middot: "·",
  copy: "©",
  reg: "®",
  trade: "™",
  euro: "€",
  pound: "£",
};

export function decodeEntities(text: string): string {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (match, code: string) => {
    if (code[0] === "#") {
      const n = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
      if (Number.isFinite(n) && n > 0 && n < 0x110000) {
        try {
          return String.fromCodePoint(n);
        } catch {
          return match;
        }
      }
      return match;
    }
    return NAMED_ENTITIES[code.toLowerCase()] ?? match;
  });
}

export function stripHtml(html: string): string {
  if (!html) return "";
  const text = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<\s*br\s*\/?>/gi, "\n")
    .replace(/<\/\s*(p|div|li|h[1-6]|blockquote|pre|tr)\s*>/gi, "\n\n")
    .replace(/<\s*li[^>]*>/gi, "• ")
    .replace(/<[^>]+>/g, " ");
  return decodeEntities(text)
    .replace(/[ \t\f\v\u00a0]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function clampText(text: string, max: number): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.8 ? cut.slice(0, lastSpace) : cut).trimEnd()}…`;
}

/** Narrowing helpers for untyped JSON. */
export function asRecord(v: unknown): Record<string, unknown> | null {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
}

export function asArray(v: unknown): unknown[] {
  return Array.isArray(v) ? v : [];
}

export function asString(v: unknown): string | null {
  if (typeof v === "string") return v;
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return null;
}

export function asNumber(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

// ---------------------------------------------------------------------------
// RSS / Atom parsing
// ---------------------------------------------------------------------------

export type FeedEntry = {
  guid: string | null;
  title: string;
  link: string;
  /** Raw HTML/text content (content:encoded > content > description > summary). */
  html: string;
  author: string | null;
  published: string | null;
};

function textOf(v: unknown): string | null {
  const s = asString(v);
  if (s !== null) return s;
  const rec = asRecord(v);
  if (rec) return asString(rec["#text"]) ?? asString(rec["@_href"]);
  if (Array.isArray(v)) {
    for (const x of v) {
      const t = textOf(x);
      if (t) return t;
    }
  }
  return null;
}

function linkOf(v: unknown): string | null {
  if (Array.isArray(v)) {
    // Atom: prefer rel="alternate" (or no rel)
    for (const x of v) {
      const rec = asRecord(x);
      const rel = asString(rec?.["@_rel"]);
      const href = asString(rec?.["@_href"]);
      if (href && (!rel || rel === "alternate")) return href;
    }
    for (const x of v) {
      const t = linkOf(x);
      if (t) return t;
    }
    return null;
  }
  const rec = asRecord(v);
  if (rec) return asString(rec["@_href"]) ?? asString(rec["#text"]);
  return asString(v);
}

function toList(v: unknown): unknown[] {
  if (v === undefined || v === null) return [];
  return Array.isArray(v) ? v : [v];
}

/** Parses RSS 2.0 or Atom XML. Throws if the document is not a recognizable feed. */
export function parseFeed(xml: string): FeedEntry[] {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: "@_",
    textNodeName: "#text",
    parseTagValue: false,
    trimValues: true,
  });
  const doc = asRecord(parser.parse(xml) as unknown);
  if (!doc) throw new Error("Feed is not valid XML");
  const rss = asRecord(doc.rss);
  const channel = asRecord(rss?.channel) ?? asRecord(asRecord(doc["rdf:RDF"])?.channel);
  const atom = asRecord(doc.feed);
  let rawItems: unknown[];
  if (channel || doc["rdf:RDF"]) {
    rawItems = toList(channel?.item ?? asRecord(doc["rdf:RDF"])?.item);
  } else if (atom) {
    rawItems = toList(atom.entry);
  } else {
    throw new Error("Document is not an RSS or Atom feed");
  }
  const out: FeedEntry[] = [];
  for (const raw of rawItems) {
    const it = asRecord(raw);
    if (!it) continue;
    const title = textOf(it.title);
    const link = linkOf(it.link) ?? textOf(it.guid);
    if (!title || !link || !/^https?:\/\//i.test(link)) continue;
    const html =
      textOf(it["content:encoded"]) ?? textOf(it.content) ?? textOf(it.description) ?? textOf(it.summary) ?? "";
    const authorRec = asRecord(it.author);
    const author = textOf(it["dc:creator"]) ?? (authorRec ? textOf(authorRec.name) : textOf(it.author));
    out.push({
      guid: textOf(it.guid) ?? textOf(it.id),
      title: decodeEntities(title).trim(),
      link: link.trim(),
      html,
      author: author ? decodeEntities(author).trim() : null,
      published: toIso(textOf(it.pubDate) ?? textOf(it.published) ?? textOf(it.updated) ?? textOf(it["dc:date"])),
    });
  }
  return out;
}

export function toIso(v: unknown): string | null {
  if (typeof v === "number" && Number.isFinite(v)) {
    // Unix seconds vs milliseconds
    const ms = v < 1e12 ? v * 1000 : v;
    const d = new Date(ms);
    return Number.isNaN(d.getTime()) ? null : d.toISOString();
  }
  if (typeof v === "string" && v.trim()) {
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? null : d.toISOString();
  }
  return null;
}

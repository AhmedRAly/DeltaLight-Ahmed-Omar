/*
 * Hindsight seed script.
 *
 *   npm run seed   (tsx scripts/seed.ts)
 *
 * Seeds ~200 anonymous demo decisions (+ realistic check-ins), ~40 demo goal
 * profiles, the goal circles and the 10 ingestion sources. Deterministic
 * (mulberry32 PRNG with a fixed seed) and idempotent (deletes previous seed
 * rows first, upserts circles/sources).
 *
 * Stories are NEVER generated here — real stories only come from ingestion.
 */
import { config } from "dotenv";

config({ path: ".env.local" });
config();

import type { AdminClient } from "../lib/supabase/admin";
import type { Database } from "../lib/database.types";
import type { Category, Horizon, LookingFor, PathKind, Stage } from "../lib/constants";

type Tables = Database["public"]["Tables"];
type DecisionInsert = Tables["decisions"]["Insert"];
type CheckinInsert = Tables["checkins"]["Insert"];
type ProfileInsert = Tables["profiles"]["Insert"];
type CircleInsert = Tables["circles"]["Insert"];
type SourceInsert = Tables["sources"]["Insert"];

// ---------------------------------------------------------------------------
// Deterministic randomness
// ---------------------------------------------------------------------------
const SEED = 20261113;

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(SEED);

function gauss(): number {
  let u = 0;
  while (u === 0) u = rand();
  const v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

function clampInt(n: number, min: number, max: number): number {
  return clamp(Math.round(n), min, max);
}

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(rand() * arr.length)];
}

function shuffle<T>(arr: readonly T[]): T[] {
  const out = arr.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function uuid(): string {
  const h: string[] = [];
  for (let i = 0; i < 32; i++) h.push(Math.floor(rand() * 16).toString(16));
  h[12] = "4";
  h[16] = ((parseInt(h[16], 16) & 0x3) | 0x8).toString(16);
  const s = h.join("");
  return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20, 32)}`;
}

function chunk<T>(arr: readonly T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

const DAY_MS = 24 * 60 * 60 * 1000;
const NOW = Date.now();

const HORIZON_ORDER: readonly Horizon[] = ["1w", "1m", "6m", "1y"];
const HORIZON_DAYS: Record<Horizon, number> = { "1w": 7, "1m": 30, "6m": 180, "1y": 365 };

// ---------------------------------------------------------------------------
// Decision templates
// ---------------------------------------------------------------------------
type Surprise = { text: string; tags: string[] };

function s(text: string, ...tags: string[]): Surprise {
  return { text, tags: tags.map((t) => t.toLowerCase()) };
}

type OptionModel = {
  label: string;
  /** probability this option is chosen (option B gets 1 - share of option A) */
  share: number;
  predicted: number;
  /** mean actual happiness at 1w, 1m, 6m, 1y */
  actual: [number, number, number, number];
  again: number;
  regret: number;
  outcomes: string[];
  surprises: Surprise[];
};

type Template = {
  key: string;
  category: Category;
  count: number;
  confidence: number;
  variants: [string, string, string];
  options: [OptionModel, OptionModel];
};

const TEMPLATES: Template[] = [
  // ----------------------------- business -----------------------------
  {
    key: "quit-for-saas",
    category: "business",
    count: 14,
    confidence: 7,
    variants: [
      "Quit my $140k product manager job to go full-time on my B2B SaaS",
      "Leave my senior engineering job to work full-time on my SaaS that's at $2k MRR",
      "Quit my corporate job to go all-in on the startup I've been building on weekends",
    ],
    options: [
      {
        label: "Quit and go full-time",
        share: 0.6,
        predicted: 8.4,
        actual: [7.2, 5.6, 6.4, 7.1],
        again: 0.74,
        regret: 3.2,
        outcomes: [
          "I'll finally have the focus to get to product-market fit within 6 months.",
          "Going full-time should triple my shipping speed and get me to ramen profitability in a year.",
        ],
        surprises: [
          s("How lonely it is working alone all day without a team around me.", "loneliness"),
          s("Sales took three times longer than I planned and the runway shrank fast.", "slower sales", "cash flow"),
          s("I didn't expect to lose part of my identity when I stopped saying where I work.", "identity"),
          s("The freedom to set my own schedule made me way more productive than I thought.", "freedom"),
          s("My partner and family were far more supportive than I feared.", "family support"),
          s("Health insurance and taxes cost a lot more than I budgeted.", "cash flow", "health"),
          s("Having full days to think led to a better pivot than any weekend sprint.", "focus", "freedom"),
        ],
      },
      {
        label: "Keep the job, build nights and weekends",
        share: 0.4,
        predicted: 7.0,
        actual: [6.6, 6.2, 5.9, 6.1],
        again: 0.58,
        regret: 4.6,
        outcomes: [
          "I'll keep my salary safe and still make steady progress on the product.",
          "Building on the side lets me validate without risking my savings.",
        ],
        surprises: [
          s("Burnout hit around month three; nights and weekends aren't sustainable.", "burnout", "health"),
          s("Progress was much slower than I thought — I shipped one feature a month.", "slower progress"),
          s("I kept wondering what would have happened if I'd gone all in.", "what if"),
          s("The steady paycheck took a lot of pressure off pricing decisions.", "financial security"),
          s("My manager found out and was surprisingly supportive.", "support"),
          s("I lost most of my social life to the side project.", "loneliness", "burnout"),
        ],
      },
    ],
  },
  {
    key: "bootstrap-vs-raise",
    category: "business",
    count: 12,
    confidence: 6,
    variants: [
      "Bootstrap my SaaS instead of raising a pre-seed round",
      "Decide whether to raise a $750k pre-seed or keep bootstrapping my startup",
      "Raise money from angels or keep growing my product on revenue alone",
    ],
    options: [
      {
        label: "Bootstrap",
        share: 0.55,
        predicted: 7.5,
        actual: [7.4, 7.0, 6.8, 7.4],
        again: 0.8,
        regret: 2.4,
        outcomes: [
          "I'll keep full control and grow slower but more sustainably.",
          "Staying lean will force us to find paying customers early.",
        ],
        surprises: [
          s("Growth was slower than I hoped, but every customer actually paid.", "slower growth"),
          s("Owning 100% of the company felt more freeing than I expected.", "freedom", "control"),
          s("Cash flow was tight every month; I paid myself nothing for 8 months.", "cash flow"),
          s("Customers cared about support, not about our funding status.", "customers"),
          s("I had to say no to a big feature because we couldn't afford a hire.", "constraints", "hiring"),
        ],
      },
      {
        label: "Raise a pre-seed round",
        share: 0.45,
        predicted: 8.2,
        actual: [8.0, 6.6, 6.0, 6.3],
        again: 0.6,
        regret: 4.1,
        outcomes: [
          "The money will let us hire two engineers and move twice as fast.",
          "Investors will open doors to customers and the next round.",
        ],
        surprises: [
          s("Fundraising took four months of my full attention instead of four weeks.", "fundraising", "time"),
          s("Investor updates and board expectations added real pressure.", "pressure", "investors"),
          s("Hiring with money in the bank was still slow and hard.", "hiring"),
          s("We burned money faster than planned and the runway felt short.", "cash flow", "burn rate"),
          s("Our lead investor's intros landed us two of our biggest customers.", "network"),
          s("I started optimizing for the next round instead of for customers.", "pressure", "identity"),
        ],
      },
    ],
  },
  {
    key: "cofounder",
    category: "business",
    count: 10,
    confidence: 6,
    variants: [
      "Bring on a technical cofounder for 30% equity instead of hiring contractors",
      "Give a cofounder equity or keep building my startup solo",
      "Take on a business-side cofounder for my side project",
    ],
    options: [
      {
        label: "Bring on a cofounder",
        share: 0.55,
        predicted: 8.0,
        actual: [8.1, 7.3, 6.5, 6.8],
        again: 0.66,
        regret: 3.6,
        outcomes: [
          "Splitting the work will double our speed and keep me sane.",
          "A cofounder with complementary skills will cover my blind spots.",
        ],
        surprises: [
          s("We disagreed about the vision far more than I expected after month four.", "cofounder conflict"),
          s("Having someone to share the lows with made a huge difference.", "support", "loneliness"),
          s("Equity conversations were more awkward than any customer negotiation.", "equity"),
          s("Our skills overlapped more than we thought, so roles were blurry.", "roles"),
          s("Shipping speed genuinely doubled.", "speed"),
        ],
      },
      {
        label: "Stay solo founder",
        share: 0.45,
        predicted: 7.0,
        actual: [7.0, 6.4, 6.2, 6.6],
        again: 0.64,
        regret: 3.8,
        outcomes: [
          "I'll move faster without having to align with anyone.",
          "Keeping 100% equity is worth the extra workload.",
        ],
        surprises: [
          s("The loneliness of making every decision alone wore me down.", "loneliness"),
          s("I could make decisions in minutes instead of meetings.", "speed", "freedom"),
          s("I had to learn sales myself, and it was painful at first.", "sales", "learning"),
          s("Contractors cost more than giving up equity would have.", "cash flow"),
          s("Investors asked about the missing cofounder in every meeting.", "fundraising"),
        ],
      },
    ],
  },
  {
    key: "start-agency",
    category: "business",
    count: 12,
    confidence: 6,
    variants: [
      "Leave my consulting job to start a design agency",
      "Quit my marketing manager role to start my own content agency",
      "Leave corporate to launch a small branding studio with two clients lined up",
    ],
    options: [
      {
        label: "Start the agency now",
        share: 0.6,
        predicted: 8.3,
        actual: [7.8, 6.0, 6.6, 7.3],
        again: 0.76,
        regret: 3.0,
        outcomes: [
          "I'll replace my salary within 6 months from referrals.",
          "Owning the client relationships will finally make the work feel like mine.",
        ],
        surprises: [
          s("Clients paid on 60-90 day terms, which wrecked my cash flow.", "cash flow", "late payments"),
          s("Selling took more of my week than doing the actual work.", "sales", "more admin"),
          s("Referrals from my old employer kept us alive for the first quarter.", "network"),
          s("I underpriced every project for the first six months.", "pricing"),
          s("I loved the freedom to pick clients and say no.", "freedom"),
          s("Imposter syndrome hit hard when pitching big brands.", "imposter syndrome"),
        ],
      },
      {
        label: "Stay and freelance on the side",
        share: 0.4,
        predicted: 6.8,
        actual: [6.7, 6.3, 5.8, 5.7],
        again: 0.52,
        regret: 5.0,
        outcomes: [
          "I'll test demand with side clients before giving up a salary.",
          "Freelancing on the side keeps risk low while I build a portfolio.",
        ],
        surprises: [
          s("I was exhausted juggling client calls during lunch breaks.", "burnout"),
          s("My employer's moonlighting policy limited which clients I could take.", "constraints"),
          s("The side income made a real dent in my savings goals.", "financial security"),
          s("I turned down a great client because I didn't have time.", "missed opportunity", "what if"),
          s("I resented my day job more as the side work grew.", "resentment"),
        ],
      },
    ],
  },
  {
    key: "pivot",
    category: "business",
    count: 10,
    confidence: 5,
    variants: [
      "Pivot my B2C app to a B2B product after 9 months of slow growth",
      "Pivot my startup to the idea customers keep asking for",
      "Abandon my current product and pivot to a new market",
    ],
    options: [
      {
        label: "Pivot to the new idea",
        share: 0.5,
        predicted: 7.6,
        actual: [7.5, 6.4, 6.9, 7.2],
        again: 0.7,
        regret: 3.2,
        outcomes: [
          "Customers are already asking for this, so traction should come faster.",
          "A fresh start will restore my motivation.",
        ],
        surprises: [
          s("Telling our early users we were pivoting was harder emotionally than I expected.", "guilt", "users"),
          s("B2B sales cycles were 3x longer than consumer signups.", "slower sales"),
          s("Our first paying customers came within weeks of the pivot.", "traction"),
          s("Rebuilding the product took twice as long as planned.", "scope creep"),
          s("The team's energy came back almost immediately.", "motivation"),
        ],
      },
      {
        label: "Keep pushing the current product",
        share: 0.5,
        predicted: 6.8,
        actual: [6.6, 6.0, 5.5, 5.6],
        again: 0.5,
        regret: 5.2,
        outcomes: [
          "More iteration on onboarding should fix retention.",
          "Switching now would waste everything we've learned.",
        ],
        surprises: [
          s("Retention barely moved despite three onboarding redesigns.", "slower growth"),
          s("Sunk cost kept me going longer than the data justified.", "sunk cost"),
          s("One niche segment started to genuinely love the product.", "niche"),
          s("My motivation dropped month after month.", "motivation", "burnout"),
          s("A competitor raised money and launched the same features.", "competition"),
        ],
      },
    ],
  },
  {
    key: "raise-prices",
    category: "business",
    count: 8,
    confidence: 5,
    variants: [
      "Double the price of my SaaS from $29 to $59 a month",
      "Raise prices 40% for new customers on my B2B product",
      "Move my product from a cheap monthly plan to higher annual pricing",
    ],
    options: [
      {
        label: "Raise prices",
        share: 0.6,
        predicted: 6.8,
        actual: [6.5, 7.4, 7.8, 8.0],
        again: 0.86,
        regret: 1.6,
        outcomes: [
          "I'll lose some signups but revenue per customer will make up for it.",
          "Higher prices will attract more serious customers.",
        ],
        surprises: [
          s("Almost nobody churned; I should have done it a year earlier.", "pricing", "confidence"),
          s("Better customers came with fewer support tickets.", "customer quality"),
          s("Conversion dropped by less than 10%.", "pricing"),
          s("Two loud customers complained publicly but stayed anyway.", "backlash"),
          s("Revenue jumped enough to hire my first contractor.", "revenue", "hiring"),
        ],
      },
      {
        label: "Keep current pricing",
        share: 0.4,
        predicted: 6.5,
        actual: [6.6, 6.2, 5.8, 5.6],
        again: 0.45,
        regret: 5.0,
        outcomes: [
          "Keeping prices low will help us grow faster.",
          "Our users are price sensitive and would churn.",
        ],
        surprises: [
          s("Low prices attracted customers who needed tons of support.", "customer success", "support load"),
          s("Margins were too thin to invest in growth.", "cash flow"),
          s("Competitors charging 3x more were growing faster.", "competition", "pricing"),
          s("I avoided the decision out of fear more than data.", "fear"),
          s("Growth didn't actually speed up.", "slower growth"),
        ],
      },
    ],
  },
  {
    key: "first-hire",
    category: "business",
    count: 10,
    confidence: 6,
    variants: [
      "Hire my first full-time employee at $85k instead of using contractors",
      "Make my first full-time hire for my small business",
      "Hire a full-time engineer or keep relying on freelancers",
    ],
    options: [
      {
        label: "Hire the first full-time employee",
        share: 0.55,
        predicted: 7.8,
        actual: [7.6, 6.4, 7.0, 7.5],
        again: 0.72,
        regret: 3.0,
        outcomes: [
          "Having a dedicated person will free up 20 hours of my week.",
          "A full-time hire will care about the product more than contractors do.",
        ],
        surprises: [
          s("Onboarding and managing took far more of my time than I expected.", "more meetings", "management"),
          s("Running payroll every two weeks changed how I thought about cash.", "cash flow"),
          s("It was amazing to have someone else who cared about the business.", "support"),
          s("Hiring took three months and 60 interviews.", "hiring"),
          s("I had to learn how to give feedback — fast.", "management", "leadership"),
        ],
      },
      {
        label: "Keep using contractors",
        share: 0.45,
        predicted: 7.0,
        actual: [7.0, 6.6, 6.2, 6.1],
        again: 0.56,
        regret: 4.4,
        outcomes: [
          "Contractors keep costs flexible while revenue is uncertain.",
          "I can scale up and down without the risk of payroll.",
        ],
        surprises: [
          s("Contractors kept disappearing mid-project.", "reliability"),
          s("Knowledge kept walking out the door with each contractor.", "churn"),
          s("The flexibility saved us during a slow quarter.", "cash flow", "flexibility"),
          s("Quality varied wildly from person to person.", "quality"),
          s("I stayed the bottleneck for everything.", "burnout"),
        ],
      },
    ],
  },
  {
    key: "sell-business",
    category: "business",
    count: 8,
    confidence: 5,
    variants: [
      "Accept a $250k acquisition offer for my side project",
      "Sell my small e-commerce business or keep running it",
      "Take an acquisition offer from a competitor for my SaaS",
    ],
    options: [
      {
        label: "Accept the offer",
        share: 0.5,
        predicted: 8.0,
        actual: [8.6, 7.4, 6.8, 7.2],
        again: 0.72,
        regret: 3.2,
        outcomes: [
          "The money will give me the freedom to start something bigger.",
          "I'll finally be free of the support burden.",
        ],
        surprises: [
          s("I felt strangely empty the week after the deal closed.", "identity", "loss"),
          s("Due diligence took four months and nearly fell through.", "deal process"),
          s("The earn-out terms were more stressful than running the business.", "stress"),
          s("Having savings gave me the freedom to take my time on the next idea.", "freedom", "financial security"),
          s("Watching the new owner change things was painful.", "loss", "control"),
        ],
      },
      {
        label: "Keep running it",
        share: 0.5,
        predicted: 7.2,
        actual: [7.0, 6.8, 6.6, 6.4],
        again: 0.55,
        regret: 4.5,
        outcomes: ["It will be worth more in two years.", "I still enjoy running it and it pays my bills."],
        surprises: [
          s("Revenue plateaued and the next offer never came.", "slower growth", "what if"),
          s("I kept thinking about what I'd do with the money.", "what if"),
          s("Owning it longer taught me more than any course.", "learning"),
          s("I got bored of the day-to-day work.", "boredom"),
          s("A platform algorithm change cut our traffic by 30%.", "platform risk"),
        ],
      },
    ],
  },
  {
    key: "second-location",
    category: "business",
    count: 8,
    confidence: 6,
    variants: [
      "Open a second location of my coffee shop",
      "Sign a lease for a second location of my bakery",
      "Expand my restaurant to a second neighborhood",
    ],
    options: [
      {
        label: "Open the second location",
        share: 0.55,
        predicted: 8.0,
        actual: [7.4, 5.8, 6.2, 6.6],
        again: 0.6,
        regret: 4.0,
        outcomes: [
          "Two locations will double revenue and let me pay myself properly.",
          "We can share overhead and buy supplies in bulk.",
        ],
        surprises: [
          s("Buildout costs ran 40% over budget.", "cash flow", "cost overruns"),
          s("I couldn't be in two places, and quality slipped at the first shop.", "quality", "management"),
          s("Finding a good manager was the hardest part.", "hiring"),
          s("The new neighborhood took much longer to find us.", "slower sales"),
          s("Bulk purchasing really did improve margins.", "margins"),
        ],
      },
      {
        label: "Optimize the first location",
        share: 0.45,
        predicted: 6.8,
        actual: [6.8, 6.9, 7.1, 7.0],
        again: 0.74,
        regret: 2.8,
        outcomes: [
          "Improving margins here is safer than a second lease.",
          "I'll grow catering and online orders instead.",
        ],
        surprises: [
          s("Catering grew faster than walk-in sales ever did.", "new revenue"),
          s("I had more time for my family.", "family", "health"),
          s("I felt like I was playing it too safe.", "what if"),
          s("Small menu changes boosted margins more than expected.", "margins"),
          s("A competitor opened in the spot I'd been eyeing.", "missed opportunity"),
        ],
      },
    ],
  },
  // ------------------------------ career ------------------------------
  {
    key: "manager-vs-ic",
    category: "career",
    count: 14,
    confidence: 7,
    variants: [
      "Take the promotion to engineering manager instead of staying a senior engineer",
      "Accept the team lead role and move into management",
      "Become a people manager or stay on the individual contributor track",
    ],
    options: [
      {
        label: "Take the manager role",
        share: 0.6,
        predicted: 8.0,
        actual: [7.6, 6.6, 6.1, 6.0],
        again: 0.55,
        regret: 4.8,
        outcomes: [
          "I'll have more impact and a faster path to director.",
          "The raise and title will be worth giving up coding.",
        ],
        surprises: [
          s("My calendar became wall-to-wall meetings with no time for deep work.", "more meetings"),
          s("I missed hands-on work much more than I thought.", "identity", "loss of craft"),
          s("Imposter syndrome every time I gave feedback to a former peer.", "imposter syndrome"),
          s("Helping someone get promoted felt more rewarding than shipping.", "fulfillment"),
          s("Being stuck between leadership and my team was exhausting.", "pressure", "stress"),
          s("The raise was smaller than I expected after taxes.", "compensation"),
        ],
      },
      {
        label: "Stay on the IC track",
        share: 0.4,
        predicted: 7.0,
        actual: [7.0, 7.1, 7.2, 7.3],
        again: 0.78,
        regret: 2.6,
        outcomes: [
          "I'll keep doing work I love and grow toward staff level.",
          "I'll avoid burnout from people management.",
        ],
        surprises: [
          s("I got more influence as a senior IC than I expected.", "influence"),
          s("Compensation kept pace with the manager track.", "compensation"),
          s("I occasionally wondered if I'd capped my career.", "what if"),
          s("I got to mentor people without the politics.", "mentorship"),
          s("My new manager was great, which made staying easy.", "manager quality"),
        ],
      },
    ],
  },
  {
    key: "bootcamp-switch",
    category: "career",
    count: 12,
    confidence: 6,
    variants: [
      "Leave my teaching job to do a coding bootcamp and switch into tech",
      "Quit accounting to do a 16-week bootcamp and become a developer",
      "Switch careers from hospitality into software engineering",
    ],
    options: [
      {
        label: "Do the bootcamp and switch",
        share: 0.6,
        predicted: 8.2,
        actual: [7.8, 6.2, 5.8, 7.0],
        again: 0.7,
        regret: 3.4,
        outcomes: [
          "I'll land a junior developer job within 3 months of finishing.",
          "Tech will give me better pay and remote flexibility.",
        ],
        surprises: [
          s("The job search took 7 months, not 3.", "job search", "cash flow"),
          s("I'd forgotten how good it feels to be learning every day.", "learning", "growth"),
          s("Imposter syndrome around CS grads was intense.", "imposter syndrome"),
          s("My savings ran out before the first offer arrived.", "cash flow"),
          s("My old career skills turned out to be a real advantage.", "transferable skills"),
          s("My first salary was lower than I'd hoped, but it grew fast.", "compensation"),
        ],
      },
      {
        label: "Stay in my current career",
        share: 0.4,
        predicted: 6.4,
        actual: [6.3, 6.0, 5.6, 5.5],
        again: 0.44,
        regret: 5.6,
        outcomes: [
          "Staying keeps my income stable while I learn on the side.",
          "The tech job market is too uncertain right now.",
        ],
        surprises: [
          s("I kept feeling stuck and resentful at work.", "stuck", "resentment"),
          s("Self-teaching after work went slower than I planned.", "slower progress"),
          s("My employer offered to pay for a part-time course.", "support"),
          s("Watching friends switch made me regret waiting.", "what if"),
          s("Stability mattered more to my family than I realized.", "family support", "financial security"),
        ],
      },
    ],
  },
  {
    key: "startup-vs-bigtech",
    category: "career",
    count: 10,
    confidence: 6,
    variants: [
      "Take a startup offer with equity over a higher-paying big tech offer",
      "Join a 20-person startup instead of Google",
      "Choose between a FAANG offer and an early-stage startup role",
    ],
    options: [
      {
        label: "Join the startup",
        share: 0.5,
        predicted: 8.1,
        actual: [8.0, 7.2, 6.6, 6.4],
        again: 0.62,
        regret: 4.0,
        outcomes: [
          "I'll learn 3x faster and the equity could be life changing.",
          "I'll have real ownership instead of being a cog.",
        ],
        surprises: [
          s("I learned more in 6 months than in 3 years at my old job.", "learning", "growth"),
          s("The startup's runway was shorter than they told me.", "cash flow", "job security"),
          s("Chaos and constant priority changes were exhausting.", "chaos", "burnout"),
          s("The equity is worth far less than I hoped after the last round.", "equity"),
          s("I loved the ownership and direct access to the founders.", "ownership"),
        ],
      },
      {
        label: "Take the big tech offer",
        share: 0.5,
        predicted: 7.6,
        actual: [7.8, 7.2, 6.8, 6.9],
        again: 0.7,
        regret: 3.4,
        outcomes: [
          "The salary will let me pay off loans and save aggressively.",
          "A big brand on my resume opens doors later.",
        ],
        surprises: [
          s("My impact felt tiny inside a giant org.", "impact", "boredom"),
          s("The pay really did change my financial life.", "financial security"),
          s("Promotions were slower and more political than expected.", "politics", "slower progress"),
          s("The perks and work-life balance were real.", "work-life balance"),
          s("Layoff anxiety hung over the whole year.", "job security", "stress"),
        ],
      },
    ],
  },
  {
    key: "counteroffer",
    category: "career",
    count: 8,
    confidence: 5,
    variants: [
      "Accept my employer's counteroffer instead of leaving for a new job",
      "Leave for a 25% raise or take the counteroffer to stay",
      "Stay at my company after they matched an outside offer",
    ],
    options: [
      {
        label: "Accept the counteroffer",
        share: 0.45,
        predicted: 7.2,
        actual: [7.4, 6.4, 5.4, 5.0],
        again: 0.38,
        regret: 6.0,
        outcomes: [
          "I get the raise without the risk of a new team.",
          "They clearly value me now, so things will improve.",
        ],
        surprises: [
          s("Nothing about the actual job changed besides pay.", "stuck"),
          s("My manager started treating me as a flight risk.", "trust", "politics"),
          s("I was job hunting again within 6 months.", "what if"),
          s("The extra money was nice but didn't fix my motivation.", "motivation", "compensation"),
          s("Leadership finally gave me the project I wanted.", "growth"),
        ],
      },
      {
        label: "Leave for the new job",
        share: 0.55,
        predicted: 7.8,
        actual: [7.2, 7.0, 7.5, 7.6],
        again: 0.8,
        regret: 2.4,
        outcomes: [
          "A fresh team and a bigger scope will reignite my motivation.",
          "The raise compounds over my whole career.",
        ],
        surprises: [
          s("The first month of onboarding was humbling.", "imposter syndrome"),
          s("I didn't realize how burned out I'd been until I left.", "burnout", "health"),
          s("My old colleagues stayed in touch more than expected.", "network"),
          s("The new company's culture was better than the interviews showed.", "culture"),
          s("I missed my old team a lot.", "loneliness"),
        ],
      },
    ],
  },
  {
    key: "remote-vs-office",
    category: "career",
    count: 8,
    confidence: 6,
    variants: [
      "Take a fully remote job for 15% less pay",
      "Leave my hybrid job for a remote role with a lower salary",
      "Choose a remote job over a higher-paying in-office role",
    ],
    options: [
      {
        label: "Take the remote job",
        share: 0.6,
        predicted: 8.3,
        actual: [8.4, 7.6, 7.2, 7.3],
        again: 0.78,
        regret: 2.6,
        outcomes: [
          "I'll get 10 hours a week back and more time with family.",
          "Remote work will let me move somewhere cheaper.",
        ],
        surprises: [
          s("I got lonely without coworkers around.", "loneliness"),
          s("Getting my commute time back changed my health.", "health", "time"),
          s("Visibility for promotions was harder remotely.", "visibility", "career growth"),
          s("My family loved having me around for dinner.", "family"),
          s("I had to build discipline to stop working at 9pm.", "boundaries"),
        ],
      },
      {
        label: "Stay at the higher-paying office job",
        share: 0.4,
        predicted: 6.8,
        actual: [6.6, 6.4, 6.2, 6.3],
        again: 0.58,
        regret: 4.2,
        outcomes: ["The extra salary accelerates my savings goals.", "Being in person helps my career more."],
        surprises: [
          s("The commute drained me more than the money was worth.", "commute", "health"),
          s("In-person relationships did help me get promoted.", "visibility"),
          s("I resented the commute every single rainy day.", "resentment"),
          s("The extra money went into savings faster than expected.", "financial security"),
          s("Half the office was empty most days anyway.", "culture"),
        ],
      },
    ],
  },
  {
    key: "job-hop",
    category: "career",
    count: 8,
    confidence: 6,
    variants: [
      "Switch jobs for a 30% raise instead of waiting for a promotion",
      "Job hop after 18 months to get a bigger title",
      "Leave my company for more money instead of pushing for a promotion internally",
    ],
    options: [
      {
        label: "Job hop for the raise",
        share: 0.55,
        predicted: 7.8,
        actual: [7.6, 7.0, 7.2, 7.4],
        again: 0.76,
        regret: 2.6,
        outcomes: ["The raise is guaranteed; the promotion isn't.", "A new title will reset my career trajectory."],
        surprises: [
          s("Negotiating was easier than I feared and I got more than I asked for.", "negotiation"),
          s("I had to rebuild trust and reputation from scratch.", "reputation"),
          s("The new manager was less supportive than my old one.", "manager quality"),
          s("My old company tried to rehire me a year later.", "validation"),
          s("The money made a real difference for my family.", "family", "financial security"),
        ],
      },
      {
        label: "Stay and push for promotion",
        share: 0.45,
        predicted: 7.0,
        actual: [6.8, 6.4, 6.6, 6.8],
        again: 0.6,
        regret: 3.8,
        outcomes: ["I've built credibility here; the promotion is close.", "Staying keeps my vesting schedule intact."],
        surprises: [
          s("The promotion took two review cycles, not one.", "slower progress"),
          s("My manager advocated for me harder than expected.", "support"),
          s("Budget freezes delayed everything.", "politics"),
          s("When it came, the promotion raise was only 8%.", "compensation"),
          s("Staying let me lead a project I really cared about.", "growth"),
        ],
      },
    ],
  },
  {
    key: "sabbatical",
    category: "career",
    count: 6,
    confidence: 5,
    variants: [
      "Take a 3-month unpaid sabbatical to recover from burnout",
      "Take four months off between jobs to travel",
      "Take a career break to figure out what I want next",
    ],
    options: [
      {
        label: "Take the break",
        share: 0.6,
        predicted: 8.6,
        actual: [8.8, 8.2, 7.4, 7.6],
        again: 0.84,
        regret: 1.8,
        outcomes: [
          "I'll come back recharged with clarity about my next step.",
          "Time off will fix my burnout.",
        ],
        surprises: [
          s("It took six weeks before I actually relaxed.", "burnout", "health"),
          s("Explaining the gap in interviews was easier than I feared.", "career gap"),
          s("I spent more money than I budgeted.", "cash flow"),
          s("I came back with a clear idea for a business.", "clarity"),
          s("My identity was so tied to work that the first month felt empty.", "identity"),
        ],
      },
      {
        label: "Keep working",
        share: 0.4,
        predicted: 6.0,
        actual: [5.8, 5.6, 5.8, 6.0],
        again: 0.5,
        regret: 4.8,
        outcomes: [
          "Pushing through another year keeps my career on track.",
          "I can take a long vacation instead.",
        ],
        surprises: [
          s("A two-week vacation didn't touch the burnout.", "burnout"),
          s("My health started to suffer.", "health"),
          s("A new manager made the job much better.", "manager quality"),
          s("Saving more gave me peace of mind.", "financial security"),
          s("I kept daydreaming about the break I didn't take.", "what if"),
        ],
      },
    ],
  },
  // ------------------------------- money -------------------------------
  {
    key: "buy-vs-rent",
    category: "money",
    count: 10,
    confidence: 6,
    variants: [
      "Buy a house now instead of continuing to rent",
      "Use my savings for a down payment on a condo",
      "Buy a home at current interest rates or keep renting and investing",
    ],
    options: [
      {
        label: "Buy the home",
        share: 0.5,
        predicted: 8.2,
        actual: [8.4, 7.4, 6.8, 7.2],
        again: 0.7,
        regret: 3.2,
        outcomes: [
          "Owning will build equity instead of paying a landlord.",
          "Having my own place will give my family stability.",
        ],
        surprises: [
          s("Maintenance and repairs cost far more than I budgeted.", "cash flow", "maintenance"),
          s("Having no cash cushion made me anxious.", "financial stress"),
          s("The stability for my kids was worth it.", "family"),
          s("Property taxes went up in the first year.", "costs"),
          s("I loved making the place truly mine.", "ownership"),
        ],
      },
      {
        label: "Keep renting and invest",
        share: 0.5,
        predicted: 6.8,
        actual: [6.8, 6.7, 6.9, 7.0],
        again: 0.72,
        regret: 3.0,
        outcomes: [
          "Investing the down payment will beat home appreciation.",
          "Renting keeps me flexible for job moves.",
        ],
        surprises: [
          s("My rent went up 12% at renewal.", "costs"),
          s("The flexibility let me take a job in another city.", "flexibility"),
          s("My portfolio grew more than house prices did.", "investing"),
          s("I felt left behind as friends bought homes.", "social comparison"),
          s("Not having to fix anything was a relief.", "freedom"),
        ],
      },
    ],
  },
  {
    key: "savings-into-business",
    category: "money",
    count: 8,
    confidence: 5,
    variants: [
      "Put $40k of my savings into my startup",
      "Use my emergency fund to keep my business going for another 6 months",
      "Invest my savings into my side business instead of the stock market",
    ],
    options: [
      {
        label: "Use my savings to fund the business",
        share: 0.55,
        predicted: 7.6,
        actual: [7.4, 6.2, 5.8, 6.4],
        again: 0.6,
        regret: 4.2,
        outcomes: [
          "Six more months of runway will get us to profitability.",
          "Betting on myself is the best investment I can make.",
        ],
        surprises: [
          s("The money ran out faster than any spreadsheet predicted.", "cash flow", "burn rate"),
          s("Financial stress strained my relationship.", "relationships", "financial stress"),
          s("Having skin in the game made me a sharper operator.", "focus"),
          s("We reached profitability right as savings hit zero.", "cash flow"),
          s("My family stepped in to help when things got tight.", "family support"),
        ],
      },
      {
        label: "Keep the savings as a safety net",
        share: 0.45,
        predicted: 6.6,
        actual: [6.8, 6.6, 6.4, 6.4],
        again: 0.6,
        regret: 4.0,
        outcomes: ["A safety net lets me make clearer decisions.", "I'll fund the business only from revenue."],
        surprises: [
          s("Sleeping well at night was worth more than I thought.", "peace of mind", "health"),
          s("Growing only from revenue was painfully slow.", "slower growth"),
          s("I missed a key hire because I wouldn't spend.", "missed opportunity"),
          s("The emergency fund saved me when my car broke down.", "financial security"),
          s("I wondered if I was betting on myself enough.", "what if"),
        ],
      },
    ],
  },
  // ----------------------------- education -----------------------------
  {
    key: "mba",
    category: "education",
    count: 10,
    confidence: 6,
    variants: [
      "Do a full-time MBA instead of continuing to work",
      "Quit my job to go to business school",
      "Take on $150k of debt for a top-20 MBA",
    ],
    options: [
      {
        label: "Do the full-time MBA",
        share: 0.45,
        predicted: 8.0,
        actual: [8.2, 7.6, 7.0, 6.8],
        again: 0.6,
        regret: 4.0,
        outcomes: [
          "The MBA will help me pivot into product or strategy roles.",
          "The network alone will be worth the cost.",
        ],
        surprises: [
          s("The debt weighed on me more than I expected.", "debt", "financial stress"),
          s("The network was genuinely the best part.", "network"),
          s("Recruiting season was more stressful than work ever was.", "stress"),
          s("I discovered I wanted to start a company, not join consulting.", "clarity"),
          s("I learned more from classmates than from classes.", "learning"),
        ],
      },
      {
        label: "Keep working instead",
        share: 0.55,
        predicted: 7.0,
        actual: [7.0, 6.8, 7.0, 7.2],
        again: 0.74,
        regret: 2.8,
        outcomes: [
          "Two more years of experience will be worth more than the degree.",
          "I'll avoid the debt and keep growing my salary.",
        ],
        surprises: [
          s("I got promoted without the degree.", "career growth"),
          s("I kept wondering about the network I missed.", "what if"),
          s("Online courses covered most of what I wanted to learn.", "learning"),
          s("Saving instead of borrowing gave me options.", "financial security"),
          s("Some roles still filtered for MBAs.", "constraints"),
        ],
      },
    ],
  },
  // ------------------------------ location ------------------------------
  {
    key: "move-city",
    category: "location",
    count: 8,
    confidence: 6,
    variants: [
      "Move from Chicago to Austin for a job with a 20% raise",
      "Relocate to London for a better job opportunity",
      "Move across the country for my career, away from family",
    ],
    options: [
      {
        label: "Move for the job",
        share: 0.55,
        predicted: 8.0,
        actual: [7.8, 6.2, 6.6, 7.2],
        again: 0.68,
        regret: 3.6,
        outcomes: [
          "A fresh start in a new city will accelerate my career.",
          "The raise will make me much better off financially.",
        ],
        surprises: [
          s("Making friends as an adult in a new city was really hard.", "loneliness"),
          s("I missed my family more than I expected.", "family"),
          s("The career boost was real; I was promoted within a year.", "career growth"),
          s("Cost of living ate most of the raise.", "cost of living"),
          s("I found my people through a running club.", "community"),
        ],
      },
      {
        label: "Stay put",
        share: 0.45,
        predicted: 6.8,
        actual: [7.0, 6.8, 6.6, 6.6],
        again: 0.62,
        regret: 4.0,
        outcomes: [
          "Staying close to family and friends matters more than the raise.",
          "I'll find a good opportunity locally.",
        ],
        surprises: [
          s("Being near family turned out to be essential when my dad got sick.", "family", "health"),
          s("Local opportunities were thinner than I hoped.", "career growth"),
          s("I kept checking in on the job I passed on.", "what if"),
          s("My social life stayed strong, which kept me happy.", "community"),
          s("A remote job came along that gave me the best of both.", "luck"),
        ],
      },
    ],
  },
  // --------------------------- relationships ---------------------------
  {
    key: "business-with-friend",
    category: "relationships",
    count: 6,
    confidence: 6,
    variants: [
      "Start a business with my best friend",
      "Go into business with my brother-in-law",
      "Partner with a close friend on our e-commerce idea",
    ],
    options: [
      {
        label: "Start the business together",
        share: 0.5,
        predicted: 8.4,
        actual: [8.6, 7.4, 6.2, 6.0],
        again: 0.5,
        regret: 5.0,
        outcomes: [
          "We trust each other, so we'll skip the cofounder drama.",
          "Building with a friend will make the hard parts fun.",
        ],
        surprises: [
          s("Money disagreements strained the friendship.", "cofounder conflict", "friendship"),
          s("We avoided hard conversations to protect the friendship.", "communication"),
          s("Having someone I trust completely made the lows bearable.", "support"),
          s("Our work styles were totally different.", "work style"),
          s("We put a written agreement in place, which saved us later.", "agreements"),
        ],
      },
      {
        label: "Go it alone",
        share: 0.5,
        predicted: 6.8,
        actual: [6.8, 6.6, 6.6, 6.8],
        again: 0.66,
        regret: 3.4,
        outcomes: ["Keeping business separate protects the friendship.", "I can move at my own pace."],
        surprises: [
          s("The friendship stayed great and they became my biggest advisor.", "friendship", "support"),
          s("Doing everything alone was lonely.", "loneliness"),
          s("I hired them as a contractor later, which worked well.", "flexibility"),
          s("I wondered if we would have gone further together.", "what if"),
          s("Decisions were faster without a partner.", "speed"),
        ],
      },
    ],
  },
];

// ---------------------------------------------------------------------------
// Demo profiles
// ---------------------------------------------------------------------------
const SKILLS = [
  "react",
  "typescript",
  "python",
  "sales",
  "marketing",
  "seo",
  "copywriting",
  "design",
  "ui/ux",
  "product management",
  "fundraising",
  "finance",
  "operations",
  "data analysis",
  "machine learning",
  "public speaking",
  "leadership",
  "negotiation",
  "hiring",
  "content creation",
  "community building",
  "devops",
  "mobile",
  "b2b sales",
  "accounting",
  "project management",
  "excel",
  "sql",
  "customer success",
] as const;
type Skill = (typeof SKILLS)[number];

type ProfileSeed = {
  name: string;
  headline: string;
  city: string;
  path: PathKind;
  stage: Stage;
  goals: string;
  have: Skill[];
  need: Skill[];
  hours: number;
  looking: LookingFor[];
};

const PROFILES: ProfileSeed[] = [
  {
    name: "Priya Raman",
    headline: "Ex-Stripe PM building a fintech for freelancers",
    city: "San Francisco",
    path: "business",
    stage: "building",
    goals:
      "Launch an invoicing and tax tool for freelancers and reach first $10k MRR by Q2. I've validated it with 40 customer interviews. I need a technical cofounder who can ship the MVP in React and TypeScript.",
    have: ["product management", "finance", "fundraising", "b2b sales"],
    need: ["react", "typescript", "devops"],
    hours: 40,
    looking: ["cofounder", "network"],
  },
  {
    name: "Daniel Kim",
    headline: "Full-stack engineer with a half-built SaaS for dental clinics",
    city: "Seattle",
    path: "business",
    stage: "building",
    goals:
      "Launch a scheduling SaaS for dental clinics and hit first $10k MRR this quarter. The product works, but I'm terrible at sales. I need someone to own outreach and marketing to paying customers.",
    have: ["react", "typescript", "devops", "sql"],
    need: ["sales", "b2b sales", "marketing", "copywriting"],
    hours: 25,
    looking: ["cofounder", "accountability"],
  },
  {
    name: "Sofia Martínez",
    headline: "Growth marketer who wants to build her own products",
    city: "Mexico City",
    path: "business",
    stage: "idea",
    goals:
      "Leave my agency job and launch a bootstrapped SaaS for Spanish-language creators. I can drive traffic and write copy that converts. I need to learn React and TypeScript or find a technical partner.",
    have: ["marketing", "seo", "copywriting", "content creation"],
    need: ["react", "typescript", "product management"],
    hours: 15,
    looking: ["cofounder", "mentor"],
  },
  {
    name: "Marcus Johnson",
    headline: "Senior accountant aiming for Controller by 2027",
    city: "Chicago",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Controller by 2027. I need to get better at leading a team and presenting to the CFO. I also want to automate our month-end close with SQL and Python instead of 40-tab Excel files.",
    have: ["accounting", "excel", "finance"],
    need: ["leadership", "public speaking", "sql", "python"],
    hours: 6,
    looking: ["mentor", "accountability"],
  },
  {
    name: "Aisha Bello",
    headline: "Data analyst going for Senior in 2027",
    city: "Lagos",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Senior Data Analyst in 2027 and lead our pricing analytics work. I want to sharpen my machine learning skills and get better at presenting insights to stakeholders.",
    have: ["sql", "python", "data analysis", "excel"],
    need: ["machine learning", "public speaking", "leadership"],
    hours: 8,
    looking: ["accountability", "mentor"],
  },
  {
    name: "Tom Becker",
    headline: "Leaving Big Four consulting to start a design agency",
    city: "Berlin",
    path: "both",
    stage: "switching",
    goals:
      "Leave corporate consulting to start a design agency for B2B fintechs within 6 months. I already have the client relationships. I need a design lead and help with pricing and agency operations.",
    have: ["b2b sales", "project management", "negotiation", "finance"],
    need: ["design", "ui/ux", "operations"],
    hours: 20,
    looking: ["cofounder", "network"],
  },
  {
    name: "Lena Novak",
    headline: "In-house product designer with a growing freelance practice",
    city: "Warsaw",
    path: "business",
    stage: "building",
    goals:
      "Turn my freelance design work into a small agency with 3 retainer clients this year, then quit my in-house job. I need someone who can sell and run the business side of the studio.",
    have: ["design", "ui/ux", "content creation"],
    need: ["b2b sales", "sales", "operations", "finance"],
    hours: 15,
    looking: ["cofounder", "accountability"],
  },
  {
    name: "Arjun Mehta",
    headline: "ML engineer building an AI screening tool for recruiters",
    city: "Bangalore",
    path: "business",
    stage: "building",
    goals:
      "Get my AI screening tool for recruiters to 20 paying customers and $10k MRR. The models work well. I need a cofounder who has sold B2B software and understands hiring teams.",
    have: ["python", "machine learning", "devops", "sql"],
    need: ["b2b sales", "sales", "hiring", "marketing"],
    hours: 30,
    looking: ["cofounder"],
  },
  {
    name: "Rachel Goldberg",
    headline: "Former SaaS sales lead ready to found her own company",
    city: "New York",
    path: "business",
    stage: "idea",
    goals:
      "Find a technical cofounder and launch a B2B SaaS in the next 6 months. I've closed over $2M in ARR for other companies. Now I want to do it for my own and get to the first paying customers fast.",
    have: ["b2b sales", "sales", "negotiation", "customer success", "hiring"],
    need: ["react", "typescript", "python", "product management"],
    hours: 20,
    looking: ["cofounder", "network"],
  },
  {
    name: "Kenji Watanabe",
    headline: "Indie hacker running two small SaaS apps",
    city: "Osaka",
    path: "business",
    stage: "launched",
    goals:
      "Grow my bootstrapped SaaS portfolio from $3k to $10k MRR without raising money. The products are solid; my bottleneck is distribution. I need help with SEO and content.",
    have: ["react", "typescript", "mobile", "devops"],
    need: ["seo", "content creation", "marketing"],
    hours: 35,
    looking: ["accountability", "network"],
  },
  {
    name: "Grace Mwangi",
    headline: "Community lead turning a newsletter into a creator business",
    city: "Nairobi",
    path: "business",
    stage: "launched",
    goals:
      "Turn my 12k-subscriber newsletter into a creator business making $5k a month from sponsorships and a paid community. I need help building the paid product and understanding my numbers.",
    have: ["community building", "content creation", "copywriting", "marketing"],
    need: ["data analysis", "react", "finance"],
    hours: 20,
    looking: ["accountability", "mentor"],
  },
  {
    name: "Oliver Bennett",
    headline: "Software engineer up for Senior in 2027",
    city: "London",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Senior Engineer in 2027. My code is solid, but I need to lead projects end-to-end, write better design docs and speak up more in planning meetings.",
    have: ["typescript", "react", "sql"],
    need: ["leadership", "project management", "public speaking"],
    hours: 5,
    looking: ["mentor", "accountability"],
  },
  {
    name: "Camila Souza",
    headline: "Teacher switching into UX design",
    city: "São Paulo",
    path: "corporate",
    stage: "switching",
    goals:
      "Switch careers from teaching into UX design and land my first junior role in 2027. I'm building a portfolio and need mentorship and real projects to work on.",
    have: ["public speaking", "project management", "content creation"],
    need: ["ui/ux", "design", "react"],
    hours: 12,
    looking: ["mentor", "hire"],
  },
  {
    name: "James O'Connor",
    headline: "First-time engineering manager at a fintech",
    city: "Dublin",
    path: "corporate",
    stage: "employed",
    goals:
      "Become a confident first-time manager: run great 1:1s, hire two engineers this year and stop being the bottleneck on code review. I want to learn from people a few steps ahead.",
    have: ["typescript", "devops", "project management"],
    need: ["leadership", "hiring", "public speaking"],
    hours: 4,
    looking: ["mentor", "network"],
  },
  {
    name: "Fatima Al-Sayed",
    headline: "Ops manager launching a modest-fashion e-commerce brand",
    city: "Dubai",
    path: "business",
    stage: "building",
    goals:
      "Launch my modest-fashion e-commerce brand and reach $10k in monthly revenue by the end of the year. Operations and sourcing are handled. I need marketing, content and design help.",
    have: ["operations", "finance", "project management", "negotiation"],
    need: ["marketing", "content creation", "seo", "design"],
    hours: 15,
    looking: ["cofounder", "accountability"],
  },
  {
    name: "Lucas Moreau",
    headline: "Backend developer building a devtool on nights and weekends",
    city: "Paris",
    path: "business",
    stage: "building",
    goals:
      "Ship my API monitoring devtool and get to first $10k MRR while keeping my day job. I need help with positioning, landing page copy and a launch strategy.",
    have: ["python", "devops", "sql", "typescript"],
    need: ["copywriting", "marketing", "seo"],
    hours: 12,
    looking: ["accountability", "cofounder"],
  },
  {
    name: "Hannah Schmidt",
    headline: "Marketing manager aiming for Director",
    city: "Munich",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Marketing Director by 2027 by owning our product-led growth funnel. I want to get hands-on with SQL and data analysis so I stop waiting on analysts.",
    have: ["marketing", "leadership", "public speaking", "content creation"],
    need: ["sql", "data analysis", "excel"],
    hours: 5,
    looking: ["mentor"],
  },
  {
    name: "David Osei",
    headline: "Career switcher from banking into software engineering",
    city: "Accra",
    path: "corporate",
    stage: "switching",
    goals:
      "Switch from banking into software engineering and land a junior developer role in tech in 2027. I'm learning React and TypeScript and want a study buddy and regular code reviews.",
    have: ["finance", "excel", "accounting", "data analysis"],
    need: ["react", "typescript", "sql"],
    hours: 20,
    looking: ["accountability", "mentor"],
  },
  {
    name: "Mei Lin",
    headline: "Designer-founder of a habit tracking app",
    city: "Singapore",
    path: "business",
    stage: "launched",
    goals:
      "Grow my habit app from 2k to 20k users and hit $10k MRR. I design and build the mobile app myself. I need a growth partner and, eventually, help raising a small round.",
    have: ["design", "ui/ux", "mobile", "react"],
    need: ["marketing", "seo", "data analysis", "fundraising"],
    hours: 30,
    looking: ["cofounder"],
  },
  {
    name: "Carlos Rivera",
    headline: "Agency owner scaling from 3 to 10 people",
    city: "Madrid",
    path: "business",
    stage: "launched",
    goals:
      "Scale my web development agency from 3 to 10 people without our margins collapsing. Sales is my strength; hiring and operations are my weak spots.",
    have: ["sales", "b2b sales", "react", "negotiation"],
    need: ["hiring", "operations", "finance", "leadership"],
    hours: 10,
    looking: ["mentor", "network"],
  },
  {
    name: "Nadia Petrova",
    headline: "Product manager eyeing Group PM",
    city: "Amsterdam",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Group Product Manager in 2027 and lead a team of PMs. I'm strong on data and delivery; I need coaching on executive communication and negotiation.",
    have: ["product management", "data analysis", "sql", "project management"],
    need: ["leadership", "public speaking", "negotiation"],
    hours: 5,
    looking: ["mentor", "accountability"],
  },
  {
    name: "Ethan Walker",
    headline: "Solo founder bootstrapping a SaaS for gyms",
    city: "Denver",
    path: "business",
    stage: "launched",
    goals:
      "Bootstrap my gym management SaaS from $4k to $10k MRR this year without raising. I need a partner to run sales calls and customer onboarding while I keep building.",
    have: ["react", "typescript", "sql", "devops"],
    need: ["sales", "customer success", "b2b sales"],
    hours: 40,
    looking: ["cofounder", "accountability"],
  },
  {
    name: "Zara Ahmed",
    headline: "YouTuber building a course business",
    city: "Toronto",
    path: "business",
    stage: "launched",
    goals:
      "Turn my YouTube channel into a creator business with a $50k course launch this year. I need help with the course platform tech, email funnels and the operations behind it.",
    have: ["content creation", "public speaking", "community building", "copywriting"],
    need: ["react", "operations", "data analysis"],
    hours: 25,
    looking: ["accountability", "hire"],
  },
  {
    name: "Samuel Adeyemi",
    headline: "Sales engineer validating a logistics SaaS idea",
    city: "Atlanta",
    path: "both",
    stage: "idea",
    goals:
      "Validate a B2B SaaS idea for logistics companies and decide by summer whether to quit my sales engineering job. I'm looking for a cofounder with product and design chops.",
    have: ["b2b sales", "sales", "sql", "customer success"],
    need: ["product management", "design", "ui/ux", "react"],
    hours: 10,
    looking: ["cofounder"],
  },
  {
    name: "Emily Chen",
    headline: "Nurse switching into health-tech product management",
    city: "Boston",
    path: "corporate",
    stage: "switching",
    goals:
      "Switch from nursing into product management at a health-tech company in 2027. I know clinical workflows deeply and need to learn the PM toolkit, SQL and data analysis.",
    have: ["project management", "public speaking", "customer success"],
    need: ["product management", "sql", "data analysis"],
    hours: 10,
    looking: ["mentor", "hire"],
  },
  {
    name: "Andrés Gómez",
    headline: "Freelance copywriter starting a content agency",
    city: "Bogotá",
    path: "business",
    stage: "building",
    goals:
      "Leave freelancing behind and start a content agency with 5 retainer clients and $15k in monthly revenue. I need someone strong on SEO and agency operations.",
    have: ["copywriting", "content creation", "marketing"],
    need: ["seo", "operations", "b2b sales"],
    hours: 30,
    looking: ["cofounder", "hire"],
  },
  {
    name: "Sarah Thompson",
    headline: "Corporate lawyer planning an exit into legal-tech",
    city: "Sydney",
    path: "both",
    stage: "switching",
    goals:
      "Leave corporate law and start a legal-tech product for small businesses. I bring the domain expertise and negotiation skills. I need a technical cofounder to build it.",
    have: ["negotiation", "public speaking", "finance"],
    need: ["react", "typescript", "product management", "python"],
    hours: 10,
    looking: ["cofounder", "network"],
  },
  {
    name: "Yusuf Demir",
    headline: "Mobile developer and first-time team lead",
    city: "Istanbul",
    path: "corporate",
    stage: "employed",
    goals:
      "Grow from first-time team lead to engineering manager this year. I want to get better at hiring, giving feedback and planning work for a team of five.",
    have: ["mobile", "react", "typescript"],
    need: ["leadership", "hiring", "project management"],
    hours: 4,
    looking: ["mentor"],
  },
  {
    name: "Chloé Dubois",
    headline: "Marketer bootstrapping a micro-SaaS for Etsy sellers",
    city: "Montreal",
    path: "business",
    stage: "building",
    goals:
      "Bootstrap a micro-SaaS for Etsy sellers to $10k MRR. I have the audience and the marketing plan. I'm learning to code but need a React and TypeScript partner.",
    have: ["marketing", "seo", "content creation", "community building"],
    need: ["react", "typescript", "devops"],
    hours: 20,
    looking: ["cofounder"],
  },
  {
    name: "Ravi Shankar",
    headline: "Finance manager going for Senior Manager",
    city: "Pune",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Senior Finance Manager in 2027 by leading our FP&A automation project. I need to build real Python and data analysis skills.",
    have: ["finance", "accounting", "excel", "leadership"],
    need: ["python", "sql", "data analysis"],
    hours: 6,
    looking: ["accountability"],
  },
  {
    name: "Isabella Rossi",
    headline: "Brand designer leaving agency life to go solo",
    city: "Milan",
    path: "business",
    stage: "building",
    goals:
      "Leave my agency job and start my own branding studio with 4 clients in 6 months. I need help with sales, pricing and negotiating retainers.",
    have: ["design", "ui/ux", "copywriting"],
    need: ["sales", "negotiation", "finance"],
    hours: 15,
    looking: ["accountability", "network"],
  },
  {
    name: "Kwame Asante",
    headline: "Ex-Shopify engineer building fintech for African SMEs",
    city: "Cape Town",
    path: "business",
    stage: "building",
    goals:
      "Build a payments and bookkeeping app for small businesses in Africa and raise a pre-seed round in 2027. I need a cofounder with fundraising, finance and B2B sales experience.",
    have: ["react", "typescript", "mobile", "devops"],
    need: ["fundraising", "finance", "accounting", "b2b sales"],
    hours: 40,
    looking: ["cofounder"],
  },
  {
    name: "Laura Fischer",
    headline: "Customer success lead aiming for Head of CS",
    city: "Vienna",
    path: "corporate",
    stage: "employed",
    goals:
      "Get promoted to Head of Customer Success by 2027 and build a team of six. I need help with hiring and data-driven churn analysis.",
    have: ["customer success", "leadership", "public speaking"],
    need: ["hiring", "data analysis", "sql"],
    hours: 5,
    looking: ["mentor"],
  },
  {
    name: "Mateo Silva",
    headline: "Bootcamp grad hunting for a first developer job",
    city: "Lisbon",
    path: "corporate",
    stage: "switching",
    goals:
      "Land my first junior React developer role in 2027 after switching from hospitality. I want accountability, mock interviews and help with TypeScript and SQL.",
    have: ["customer success", "operations", "react"],
    need: ["typescript", "sql", "public speaking"],
    hours: 25,
    looking: ["accountability", "hire"],
  },
  {
    name: "Ji-woo Park",
    headline: "Senior engineer with a profitable side SaaS",
    city: "Seoul",
    path: "both",
    stage: "launched",
    goals:
      "Decide whether to quit my job once my side SaaS hits $10k MRR (it's at $6k now). I need someone to help with SEO and content so I can stay focused on the product.",
    have: ["python", "react", "typescript", "sql"],
    need: ["seo", "content creation", "copywriting"],
    hours: 15,
    looking: ["accountability"],
  },
  {
    name: "Amara Nwosu",
    headline: "HR business partner launching a recruiting agency",
    city: "Houston",
    path: "both",
    stage: "idea",
    goals:
      "Leave corporate HR to start a recruiting agency for startups. I need a technical partner to build our candidate-matching tool and someone who understands startup sales.",
    have: ["hiring", "leadership", "negotiation", "public speaking"],
    need: ["python", "react", "b2b sales"],
    hours: 10,
    looking: ["cofounder", "network"],
  },
  {
    name: "Ben Carter",
    headline: "Product marketer launching a toolkit for podcasters",
    city: "Austin",
    path: "business",
    stage: "building",
    goals:
      "Launch a creator business toolkit for podcasters and hit $10k MRR within a year. I own marketing and community. I need a full-stack engineer as a cofounder.",
    have: ["marketing", "copywriting", "community building", "product management"],
    need: ["react", "typescript", "devops", "mobile"],
    hours: 20,
    looking: ["cofounder"],
  },
  {
    name: "Ana Popescu",
    headline: "QA engineer switching into data science",
    city: "Bucharest",
    path: "corporate",
    stage: "switching",
    goals:
      "Switch from QA into data science in 2027. I'm learning Python and machine learning and want a mentor and a project partner to build a real portfolio.",
    have: ["sql", "project management", "excel"],
    need: ["python", "machine learning", "data analysis"],
    hours: 15,
    looking: ["mentor", "accountability"],
  },
  {
    name: "Noah Williams",
    headline: "Startup ops lead who wants to become a COO",
    city: "Vancouver",
    path: "corporate",
    stage: "employed",
    goals:
      "Grow from operations lead to COO at a Series A startup within two years. I want to learn fundraising, finance and negotiation from founders who've done it.",
    have: ["operations", "project management", "hiring", "excel"],
    need: ["fundraising", "finance", "negotiation"],
    hours: 6,
    looking: ["mentor", "network"],
  },
  {
    name: "Leila Haddad",
    headline: "Indie founder of a Notion templates business",
    city: "Barcelona",
    path: "business",
    stage: "launched",
    goals:
      "Turn my Notion templates shop ($4k a month) into a real creator business with a course and a community. I need help building a web app version and getting my finances in order.",
    have: ["design", "content creation", "marketing", "community building"],
    need: ["react", "typescript", "finance"],
    hours: 25,
    looking: ["cofounder", "accountability"],
  },
];

// ---------------------------------------------------------------------------
// Circles
// ---------------------------------------------------------------------------
type CircleSeed = { slug: string; name: string; description: string; path: PathKind; keywords: string[] };

const CIRCLES: CircleSeed[] = [
  {
    slug: "first-10k-mrr",
    name: "First $10k MRR",
    description:
      "Founders pushing a product from the first paying customers to $10k in monthly recurring revenue. Weekly revenue check-ins, launch feedback and sales accountability.",
    path: "business",
    keywords: ["mrr", "paying customers", "$10k", "monthly revenue", "first customers"],
  },
  {
    slug: "promotion-senior-2027",
    name: "Promotion to Senior in 2027",
    description:
      "Ambitious employees working toward a senior, lead or director-level promotion in 2027. Share promo packets, practice presenting and keep each other on track.",
    path: "corporate",
    keywords: ["promot", "senior", "controller", "director", "head of"],
  },
  {
    slug: "corporate-to-agency",
    name: "Leaving corporate to start an agency",
    description:
      "Consultants, designers, marketers and recruiters leaving corporate jobs to start their own agency or studio. Pricing, first retainer clients and agency operations.",
    path: "both",
    keywords: ["agency", "studio", "retainer", "consultancy", "leave corporate"],
  },
  {
    slug: "career-switch-tech",
    name: "Switching into tech",
    description:
      "Career changers moving into software engineering, UX design, data and product roles. Study buddies, portfolio reviews and mock interviews for the first tech job.",
    path: "corporate",
    keywords: ["switch", "career change", "bootcamp", "junior", "first tech"],
  },
  {
    slug: "bootstrapped-saas",
    name: "Bootstrapping a SaaS",
    description:
      "Indie hackers and solo founders building profitable SaaS products without venture capital. Distribution, pricing and staying sane while building on revenue alone.",
    path: "business",
    keywords: ["bootstrap", "micro-saas", "indie", "without raising", "side saas"],
  },
  {
    slug: "first-time-manager",
    name: "First-time managers",
    description:
      "New managers and team leads learning to hire, run 1:1s, give feedback and lead a team without losing themselves in meetings.",
    path: "corporate",
    keywords: ["first-time manager", "team lead", "1:1", "engineering manager", "lead a team"],
  },
  {
    slug: "creator-business",
    name: "Building a creator business",
    description:
      "Newsletter writers, YouTubers, podcasters and course creators turning an audience into a sustainable creator business through sponsorships, courses and paid communities.",
    path: "business",
    keywords: ["creator", "newsletter", "youtube", "course", "sponsorship", "podcast"],
  },
];

// Mirrors the INSERT at the bottom of supabase/migrations/0001_hindsight.sql
const SOURCES: SourceInsert[] = [
  { id: "reddit-entrepreneur", name: "r/Entrepreneur", type: "reddit", base_url: "https://www.reddit.com/r/Entrepreneur" },
  { id: "reddit-startups", name: "r/startups", type: "reddit", base_url: "https://www.reddit.com/r/startups" },
  { id: "reddit-smallbusiness", name: "r/smallbusiness", type: "reddit", base_url: "https://www.reddit.com/r/smallbusiness" },
  { id: "reddit-career", name: "r/careerguidance + r/careeradvice", type: "reddit", base_url: "https://www.reddit.com/r/careerguidance" },
  { id: "reddit-sideproject", name: "r/SideProject + r/SaaS", type: "reddit", base_url: "https://www.reddit.com/r/SideProject" },
  { id: "hackernews", name: "Hacker News", type: "algolia", base_url: "https://news.ycombinator.com" },
  { id: "indiehackers", name: "Indie Hackers", type: "rss", base_url: "https://www.indiehackers.com" },
  { id: "producthunt", name: "Product Hunt", type: "graphql", base_url: "https://www.producthunt.com" },
  { id: "workplace-se", name: "The Workplace (Stack Exchange)", type: "stackexchange", base_url: "https://workplace.stackexchange.com" },
  { id: "devto-medium", name: "Dev.to + Medium", type: "api+rss", base_url: "https://dev.to" },
];

// ---------------------------------------------------------------------------
// Generation (pure, deterministic — runs before any network call)
// ---------------------------------------------------------------------------
type DecisionSpec = {
  row: Omit<DecisionInsert, "embedding"> & { id: string; text: string };
  checkins: CheckinInsert[];
};

function generateDecisions(): DecisionSpec[] {
  const specs: DecisionSpec[] = [];
  for (const t of TEMPLATES) {
    for (let i = 0; i < t.count; i++) {
      const id = uuid();
      const opt = rand() < t.options[0].share ? t.options[0] : t.options[1];
      const text = t.variants[i % t.variants.length];
      const daysAgo = 2 + rand() * 418;
      const createdMs = NOW - daysAgo * DAY_MS;
      const predicted = clampInt(opt.predicted + gauss() * 0.8, 1, 10);
      const confidence = clampInt(t.confidence + (predicted - opt.predicted) * 0.4 + gauss() * 1.4, 1, 10);

      const row: DecisionSpec["row"] = {
        id,
        user_id: null,
        room_code: null,
        is_seed: true,
        text,
        category: t.category,
        options: t.options.map((o) => o.label),
        chosen_option: opt.label,
        predicted_happiness: predicted,
        predicted_outcome: pick(opt.outcomes),
        confidence,
        created_at: new Date(createdMs).toISOString(),
      };

      // Person-level offset keeps one decision's trajectory internally consistent.
      const personal = gauss() * 0.9;
      const surprises = shuffle(opt.surprises);
      const checkins: CheckinInsert[] = [];
      for (let h = 0; h < HORIZON_ORDER.length; h++) {
        const horizon = HORIZON_ORDER[h];
        const dueMs = createdMs + HORIZON_DAYS[horizon] * DAY_MS;
        if (dueMs > NOW) break;
        if (rand() >= 0.88) break; // stop at the first skipped horizon
        const checkinMs = Math.min(NOW - 60 * 1000, dueMs + rand() * 3 * DAY_MS);
        const modelActual = opt.actual[h];
        const rawActual = modelActual + personal + gauss() * 0.9;
        const actual = clampInt(rawActual, 1, 10);
        const delta = rawActual - modelActual;
        const regret = clampInt(opt.regret - delta * 0.8 + gauss() * 1.2, 0, 10);
        const pAgain = clamp(opt.again + delta * 0.08 - (regret - opt.regret) * 0.03, 0.03, 0.97);
        const surprise = rand() < 0.92 ? surprises[h % surprises.length] : null;
        checkins.push({
          decision_id: id,
          horizon,
          actual_happiness: actual,
          regret,
          would_choose_again: rand() < pAgain,
          biggest_surprise: surprise ? surprise.text : null,
          surprise_tags: surprise ? surprise.tags : [],
          checkin_at: new Date(checkinMs).toISOString(),
        });
      }
      specs.push({ row, checkins });
    }
  }
  return shuffle(specs);
}

type ProfileSpec = { id: string; seed: ProfileSeed; createdAt: string };

function generateProfiles(): ProfileSpec[] {
  return PROFILES.map((p) => ({
    id: uuid(),
    seed: p,
    createdAt: new Date(NOW - (1 + rand() * 60) * DAY_MS).toISOString(),
  }));
}

// ---------------------------------------------------------------------------
// Runtime helpers
// ---------------------------------------------------------------------------
type Lib = {
  embedMany: (texts: string[]) => Promise<number[][] | null>;
  toVector: (embedding: number[]) => string;
  normalizeSkills: (list: string[]) => string[];
};

type EmbedState = { enabled: boolean; warned: boolean; count: number };

function warnNoEmbeddings(state: EmbedState, reason: string): void {
  if (state.warned) return;
  state.warned = true;
  console.warn(`  ⚠  ${reason} — rows will be stored without embeddings; the app will use the Postgres text-search fallback.`);
}

async function embedTexts(lib: Lib, state: EmbedState, texts: string[]): Promise<(string | null)[]> {
  if (!state.enabled || texts.length === 0) return texts.map(() => null);
  const res = await lib.embedMany(texts);
  if (!res || res.length !== texts.length) {
    state.enabled = false;
    warnNoEmbeddings(state, "Embedding request failed");
    return texts.map(() => null);
  }
  state.count += res.length;
  return res.map((e) => lib.toVector(e));
}

function check(error: { message: string } | null, what: string): void {
  if (error) throw new Error(`${what}: ${error.message}`);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main(): Promise<void> {
  const { createAdminClient, hasSupabase } = await import("../lib/supabase/admin");
  const { embedMany, hasOpenAI } = await import("../lib/ai");
  const { toVector, normalizeSkills } = await import("../lib/utils");

  if (!hasSupabase()) {
    console.error(
      "\n✖ Supabase is not configured.\n" +
        "  Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local, then run `npm run seed` again.\n",
    );
    process.exit(1);
  }

  const lib: Lib = { embedMany, toVector, normalizeSkills };
  const sb: AdminClient = createAdminClient();
  const embedState: EmbedState = { enabled: hasOpenAI(), warned: false, count: 0 };

  console.log("\nHindsight seed");
  console.log("──────────────");
  if (!embedState.enabled) warnNoEmbeddings(embedState, "OPENAI_API_KEY is not set");

  // Generate everything up-front so output is identical regardless of network results.
  const decisionSpecs = generateDecisions();
  const profileSpecs = generateProfiles();

  // 1) Clean previous seed rows (checkins/scheduled_checkins and connections/messages cascade).
  console.log("• Removing previous seed rows…");
  const delDecisions = await sb.from("decisions").delete({ count: "exact" }).eq("is_seed", true);
  check(delDecisions.error, "Deleting seed decisions");
  const delProfiles = await sb.from("profiles").delete({ count: "exact" }).eq("is_seed", true);
  check(delProfiles.error, "Deleting seed profiles");
  console.log(`  removed ${delDecisions.count ?? 0} decisions, ${delProfiles.count ?? 0} profiles`);

  // 2) Sources (never touches items_count).
  console.log("• Ensuring sources…");
  const srcRes = await sb.from("sources").upsert(SOURCES, { onConflict: "id" }).select("id");
  check(srcRes.error, "Upserting sources");
  const sourcesCount = srcRes.data?.length ?? 0;

  // 3) Circles.
  console.log("• Upserting circles…");
  const circleVectors = await embedTexts(
    lib,
    embedState,
    CIRCLES.map((c) => `${c.name}. ${c.description}`),
  );
  const circleRows: CircleInsert[] = CIRCLES.map((c, i) => ({
    slug: c.slug,
    name: c.name,
    description: c.description,
    path: c.path,
    keywords: c.keywords.map((k) => k.toLowerCase()),
    embedding: circleVectors[i],
  }));
  const circleRes = await sb.from("circles").upsert(circleRows, { onConflict: "slug" }).select("slug");
  check(circleRes.error, "Upserting circles");
  const circlesCount = circleRes.data?.length ?? 0;

  // 4) Decisions in batches of 50 with embeddings.
  console.log(`• Inserting ${decisionSpecs.length} decisions…`);
  const insertedIds = new Set<string>();
  const batches = chunk(decisionSpecs, 50);
  for (let b = 0; b < batches.length; b++) {
    const batch = batches[b];
    const vectors = await embedTexts(
      lib,
      embedState,
      batch.map((d) => d.row.text),
    );
    const rows: DecisionInsert[] = batch.map((d, i) => ({ ...d.row, embedding: vectors[i] }));
    const { data, error } = await sb.from("decisions").insert(rows).select("id");
    check(error, `Inserting decisions batch ${b + 1}/${batches.length}`);
    for (const r of data ?? []) insertedIds.add(r.id);
    console.log(`  batch ${b + 1}/${batches.length}: ${data?.length ?? 0} rows`);
  }

  // 5) Check-ins for decisions that were actually inserted.
  const allCheckins = decisionSpecs
    .filter((d) => insertedIds.has(d.row.id))
    .flatMap((d) => d.checkins);
  console.log(`• Inserting ${allCheckins.length} check-ins…`);
  let checkinsInserted = 0;
  for (const batch of chunk(allCheckins, 200)) {
    const { data, error } = await sb.from("checkins").insert(batch).select("id");
    check(error, "Inserting check-ins");
    checkinsInserted += data?.length ?? 0;
  }
  const byHorizon: Record<Horizon, number> = { "1w": 0, "1m": 0, "6m": 0, "1y": 0 };
  for (const c of allCheckins) {
    if (c.horizon === "1w" || c.horizon === "1m" || c.horizon === "6m" || c.horizon === "1y") byHorizon[c.horizon]++;
  }

  // 6) Demo profiles.
  console.log(`• Inserting ${profileSpecs.length} demo profiles…`);
  const goalVectors = await embedTexts(
    lib,
    embedState,
    profileSpecs.map((p) => `${p.seed.headline}. ${p.seed.goals}`),
  );
  const profileRows: ProfileInsert[] = profileSpecs.map((p, i) => ({
    id: p.id,
    name: p.seed.name,
    headline: p.seed.headline,
    avatar_url: null,
    city: p.seed.city,
    path: p.seed.path,
    stage: p.seed.stage,
    goals: p.seed.goals,
    skills_have: lib.normalizeSkills(p.seed.have),
    skills_need: lib.normalizeSkills(p.seed.need),
    hours_per_week: clampInt(p.seed.hours, 0, 100),
    looking_for: p.seed.looking,
    goal_embedding: goalVectors[i],
    is_seed: true,
    is_guest: false,
    room_code: null,
    created_at: p.createdAt,
  }));
  const profRes = await sb.from("profiles").insert(profileRows).select("id");
  check(profRes.error, "Inserting demo profiles");
  const profilesCount = profRes.data?.length ?? 0;

  // Summary
  const byCategory = new Map<string, number>();
  for (const d of decisionSpecs) {
    if (!insertedIds.has(d.row.id)) continue;
    const cat = d.row.category ?? "other";
    byCategory.set(cat, (byCategory.get(cat) ?? 0) + 1);
  }
  const categorySummary = Array.from(byCategory.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([c, n]) => `${c} ${n}`)
    .join(", ");

  console.log("\n✔ Seed complete");
  console.log(`  templates     ${TEMPLATES.length}`);
  console.log(`  decisions     ${insertedIds.size}  (${categorySummary})`);
  console.log(
    `  check-ins     ${checkinsInserted}  (1w ${byHorizon["1w"]}, 1m ${byHorizon["1m"]}, 6m ${byHorizon["6m"]}, 1y ${byHorizon["1y"]})`,
  );
  console.log(`  profiles      ${profilesCount}`);
  console.log(`  circles       ${circlesCount}`);
  console.log(`  sources       ${sourcesCount}`);
  console.log(
    `  embeddings    ${
      embedState.enabled && embedState.count > 0
        ? `${embedState.count} vectors`
        : "none (text-search fallback will be used)"
    }`,
  );
  console.log("  stories       0 created (real stories only come from `npm run ingest`)\n");
}

main().catch((err: unknown) => {
  const message = err instanceof Error ? err.message : String(err);
  console.error(`\n✖ Seed failed: ${message}\n`);
  process.exit(1);
});

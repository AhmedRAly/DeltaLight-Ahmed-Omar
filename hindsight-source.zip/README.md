# Hindsight

Ask what you're deciding. Hindsight searches real public posts from people who already faced it, validates every record, and shows exactly where each answer came from.

- **Advice (home):** a prompt, then live research across Hacker News, Stack Exchange, Lemmy (and Reddit when connected). Every result links to the original post and a stored raw record.
- **Community:** post a question, get anonymous answers. Give-to-get: answering earns unlocks to read other threads.
- **Business:** members directory and goal-based matching for co-founders, mentors and accountability partners.

## Stack
Next.js 14, TypeScript, Tailwind, Supabase (Postgres, Auth, pgvector), Recharts, Framer Motion. OpenAI is optional.

## Setup
1. `cp .env.example .env.local` and fill in the Supabase keys.
2. In the Supabase SQL editor run `supabase/migrations/0001_hindsight.sql`.
3. `npm install`, then `npm run seed` (demo decisions and members), then `npm run dev`.
4. Optional: `OPENAI_API_KEY` (cited summaries, structured stories), `REDDIT_CLIENT_ID` and `REDDIT_CLIENT_SECRET` (Reddit), `STACKEXCHANGE_KEY` (higher quota).

## Demo mode
- **Sign-in is a hardcoded demo** (four personas, a cookie, no real auth). It is on outside production, and in production only with `DEMO_AUTH=on`. Replace it with real auth before a public launch; `lib/supabase/server.ts` already falls back to Supabase Auth.
- **The community board runs on a local JSON store** (`.data/community.json`, git-ignored) seeded with 28 sample questions from fictional people. Delete the file to reset it. Swap `lib/community-store.ts` for a database when you go live.

## Notes
- Sample data (demo members, sample decisions, sample community posts) is always labeled.
- Only public handles from source posts are shown. Nothing is scraped to identify individuals.

// Demo sign-in. Hardcoded personas and a cookie; no real authentication.
// Enabled outside production, or in production only when DEMO_AUTH=on. Remove before a real launch.

export const DEMO_COOKIE = "hs_demo";

export type DemoUser = {
  id: string;
  name: string;
  /** Display name used on community posts. */
  short: string;
  email: string;
  headline: string;
  blurb: string;
  profile: {
    city: string;
    path: "business" | "corporate";
    stage: "idea" | "building" | "launched" | "employed" | "switching";
    goals: string;
    skills_have: string[];
    skills_need: string[];
    hours_per_week: number;
    looking_for: string[];
  };
};

export const DEMO_USERS: DemoUser[] = [
  {
    id: "d0000000-0000-4000-8000-000000000001",
    name: "Alex Rivera",
    short: "Alex R.",
    email: "alex@demo.hindsight",
    headline: "Founder building a scheduling SaaS",
    blurb: "Two years in, deciding whether to raise.",
    profile: {
      city: "Austin",
      path: "business",
      stage: "building",
      goals: "Reach $20k MRR this year and decide between bootstrapping and raising a small round.",
      skills_have: ["product", "react", "sales"],
      skills_need: ["marketing", "finance"],
      hours_per_week: 45,
      looking_for: ["cofounder", "mentor"],
    },
  },
  {
    id: "d0000000-0000-4000-8000-000000000002",
    name: "Maya Chen",
    short: "Maya C.",
    email: "maya@demo.hindsight",
    headline: "Product manager weighing a move to a startup",
    blurb: "Comfortable job, tempting offer.",
    profile: {
      city: "Toronto",
      path: "corporate",
      stage: "employed",
      goals: "Get promoted to Group PM within two years, or join an early-stage startup as head of product.",
      skills_have: ["product management", "data analysis", "roadmapping"],
      skills_need: ["fundraising", "engineering leadership"],
      hours_per_week: 10,
      looking_for: ["mentor", "network"],
    },
  },
  {
    id: "d0000000-0000-4000-8000-000000000003",
    name: "Jordan Brooks",
    short: "Jordan B.",
    email: "jordan@demo.hindsight",
    headline: "Career switcher from finance into software",
    blurb: "Learning to code, unsure about the leap.",
    profile: {
      city: "Chicago",
      path: "corporate",
      stage: "switching",
      goals: "Land a junior software engineering role within 9 months while keeping my finance job.",
      skills_have: ["excel", "accounting", "modeling"],
      skills_need: ["typescript", "system design"],
      hours_per_week: 12,
      looking_for: ["accountability", "mentor"],
    },
  },
  {
    id: "d0000000-0000-4000-8000-000000000004",
    name: "Sam Okafor",
    short: "Sam O.",
    email: "sam@demo.hindsight",
    headline: "Recent grad choosing a first direction",
    blurb: "Two offers, no clear favorite.",
    profile: {
      city: "London",
      path: "corporate",
      stage: "idea",
      goals: "Pick a first job that teaches me the most, and eventually start something of my own.",
      skills_have: ["research", "writing", "python"],
      skills_need: ["sales", "design"],
      hours_per_week: 15,
      looking_for: ["cofounder", "network"],
    },
  },
];

export function demoEnabled(): boolean {
  return process.env.NODE_ENV !== "production" || process.env.DEMO_AUTH === "on";
}

export function findDemoUser(id: string | undefined | null): DemoUser | null {
  if (!id) return null;
  return DEMO_USERS.find((u) => u.id === id) ?? null;
}

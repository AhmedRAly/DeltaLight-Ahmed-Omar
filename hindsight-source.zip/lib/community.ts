// Community board rules (give-to-get). Server-side only.
import { userActivity } from "./community-store";

export const CREDITS_PER_ANSWER = 3;
export const MAX_QUESTIONS_PER_DAY = 5;
export const MAX_ANSWERS_PER_DAY = 12;

export type AccessState = "signed-out" | "author" | "answered" | "unlocked" | "can-unlock" | "locked";
export type Standing = { credits: number; answers: number; unlocks: number };

/** credits = 3 per answer you've written, minus one per thread you've unlocked. */
export function getStanding(userId: string): Standing {
  const a = userActivity(userId);
  return { answers: a.answerCount, unlocks: a.unlockCount, credits: Math.max(0, a.answerCount * CREDITS_PER_ANSWER - a.unlockCount) };
}

export function getAccess(userId: string | null, question: { id: string; authorId: string | null }): { state: AccessState; standing: Standing | null } {
  if (!userId) return { state: "signed-out", standing: null };
  const standing = getStanding(userId);
  if (question.authorId === userId) return { state: "author", standing };
  const a = userActivity(userId);
  if (a.answered.has(question.id)) return { state: "answered", standing };
  if (a.unlocked.has(question.id)) return { state: "unlocked", standing };
  return { state: standing.credits > 0 ? "can-unlock" : "locked", standing };
}

export const canSeeAnswers = (s: AccessState) => s === "author" || s === "answered" || s === "unlocked";

export const TOPIC_STYLE: Record<string, string> = {
  business: "border-primary/30 bg-primary/10 text-primary",
  career: "border-sky-500/30 bg-sky-500/10 text-sky-700",
  money: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700",
  education: "border-violet-500/30 bg-violet-500/10 text-violet-700",
  relationships: "border-pink-500/30 bg-pink-500/10 text-pink-700",
  location: "border-teal-500/30 bg-teal-500/10 text-teal-700",
  other: "border-zinc-500/30 bg-zinc-500/10 text-zinc-700",
};

export function preview(text: string, max = 120): string {
  const t = text.replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  return t.slice(0, max).replace(/\s\S*$/, "") + "…";
}

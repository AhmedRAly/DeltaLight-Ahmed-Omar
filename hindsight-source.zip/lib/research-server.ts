// Server-only: live fetch from public sources for a user's question, validate every record, store it in
// raw_items, and return evidence that links back to both the original post and the stored raw record.
import { asArray, asNumber, asRecord, asString, decodeEntities, fetchJson, stripHtml, toIso, USER_AGENT } from "../scripts/ingest/http";
import { createAdminClient, hasSupabase } from "./supabase/admin";
import {
  bestExcerpt,
  keywords,
  rawApiUrlFor,
  isFirsthand,
  keywordWeights,
  scoreItem,
  SOURCE_LABEL,
  type Evidence,
  type EvidenceKind,
  type ResearchSourceKey,
  type SourceReport,
  type SourceResponse,
} from "./research";

type Candidate = {
  externalId: string;
  sourceId: string;
  sourceName: string;
  kind: EvidenceKind;
  title: string;
  body: string;
  url: string;
  author: string | null;
  postedAt: string | null;
  score: number;
};

const MIN_TEXT = 160;
const MIN_COVERAGE = 0.5;
const KEEP = 10;
const CACHE_MS = 10 * 60 * 1000;
// Bump when matching/validation rules change so stale results are never served.
const CACHE_VERSION = 7;

const SE_SITES = {
  "workplace-se": { site: "workplace", name: "The Workplace (Stack Exchange)" },
  "money-se": { site: "money", name: "Personal Finance & Money (Stack Exchange)" },
  "softwareengineering-se": { site: "softwareengineering", name: "Software Engineering (Stack Exchange)" },
  "academia-se": { site: "academia", name: "Academia (Stack Exchange)" },
  "law-se": { site: "law", name: "Law (Stack Exchange)" },
} as const;

type SeKey = keyof typeof SE_SITES;
const isSe = (k: ResearchSourceKey): k is SeKey => k in SE_SITES;

const SOURCE_ROWS: Record<string, { name: string; type: string; base_url: string }> = {
  hackernews: { name: "Hacker News", type: "algolia", base_url: "https://news.ycombinator.com" },
  "workplace-se": { name: SE_SITES["workplace-se"].name, type: "stackexchange", base_url: "https://workplace.stackexchange.com" },
  "money-se": { name: SE_SITES["money-se"].name, type: "stackexchange", base_url: "https://money.stackexchange.com" },
  "softwareengineering-se": { name: SE_SITES["softwareengineering-se"].name, type: "stackexchange", base_url: "https://softwareengineering.stackexchange.com" },
  "academia-se": { name: SE_SITES["academia-se"].name, type: "stackexchange", base_url: "https://academia.stackexchange.com" },
  "law-se": { name: SE_SITES["law-se"].name, type: "stackexchange", base_url: "https://law.stackexchange.com" },
  lemmy: { name: "Lemmy", type: "lemmy", base_url: "https://lemmy.world" },
  "reddit-live": { name: "Reddit", type: "reddit", base_url: "https://www.reddit.com" },
};

const HOST_ALLOW: Record<string, (h: string) => boolean> = {
  hackernews: (h) => h === "news.ycombinator.com",
  lemmy: (h) => h === "lemmy.world",
  "reddit-live": (h) => h === "www.reddit.com" || h === "reddit.com",
};
for (const k of Object.keys(SE_SITES) as SeKey[]) {
  HOST_ALLOW[k] = (h) => h.endsWith(".stackexchange.com");
}

// ---------------------------------------------------------------------------
// Requests
// ---------------------------------------------------------------------------
function redditConfigured() {
  return Boolean(process.env.REDDIT_CLIENT_ID && process.env.REDDIT_CLIENT_SECRET);
}

/** Variant 0 uses every keyword; later variants keep only the most distinctive (longest) words. */
const VARIANT_SIZES = [7, 3, 2, 1];
function queryFor(q: string, variant = 0) {
  const kws = keywords(q);
  const size = VARIANT_SIZES[Math.min(variant, VARIANT_SIZES.length - 1)];
  const picked = variant === 0 ? kws : [...kws].sort((a, b) => b.length - a.length).slice(0, size);
  return encodeURIComponent(picked.join(" ") || q.slice(0, 80));
}

/** The URL shown to the user. Never contains secrets. */
export function requestUrlFor(key: ResearchSourceKey, q: string, variant = 0): string {
  const query = queryFor(q, variant);
  if (key === "hn-stories") return `https://hn.algolia.com/api/v1/search?query=${query}&tags=story&hitsPerPage=40`;
  if (key === "hn-comments") return `https://hn.algolia.com/api/v1/search?query=${query}&tags=comment&hitsPerPage=40`;
  if (key === "lemmy") return `https://lemmy.world/api/v3/search?q=${query}&type_=Posts&sort=TopAll&limit=40`;
  if (key === "reddit") return `https://oauth.reddit.com/search?q=${query}&sort=relevance&type=link&limit=40&raw_json=1`;
  if (isSe(key)) {
    return `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${query}&site=${SE_SITES[key].site}&pagesize=25&filter=withbody`;
  }
  return "";
}

let redditToken: { value: string; expiresAt: number } | null = null;
async function getRedditToken(): Promise<string> {
  if (redditToken && redditToken.expiresAt > Date.now() + 60_000) return redditToken.value;
  const basic = Buffer.from(`${process.env.REDDIT_CLIENT_ID}:${process.env.REDDIT_CLIENT_SECRET}`).toString("base64");
  const json = asRecord(
    await fetchJson("https://www.reddit.com/api/v1/access_token", {
      method: "POST",
      headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: "grant_type=client_credentials",
    })
  );
  const token = asString(json?.access_token);
  if (!token) throw new Error("Reddit did not return an access token. Check REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET.");
  redditToken = { value: token, expiresAt: Date.now() + (asNumber(json?.expires_in) ?? 3600) * 1000 };
  return token;
}

async function fetchPayload(key: ResearchSourceKey, q: string, variant = 0): Promise<unknown> {
  const url = requestUrlFor(key, q, variant);
  if (key === "reddit") {
    const token = await getRedditToken();
    return fetchJson(url, { headers: { Authorization: `Bearer ${token}`, "User-Agent": `web:hindsight:1.0 (${USER_AGENT})` }, timeoutMs: 12_000 });
  }
  if (isSe(key) && process.env.STACKEXCHANGE_KEY) {
    return fetchJson(`${url}&key=${encodeURIComponent(process.env.STACKEXCHANGE_KEY)}`, { timeoutMs: 12_000 });
  }
  return fetchJson(url, { timeoutMs: 12_000 });
}

// ---------------------------------------------------------------------------
// Parsers (one per API shape)
// ---------------------------------------------------------------------------
function parseHn(json: unknown, kind: "story" | "comment"): Candidate[] {
  const out: Candidate[] = [];
  for (const h of asArray(asRecord(json)?.hits)) {
    const hit = asRecord(h);
    const id = asString(hit?.objectID);
    if (!hit || !id) continue;
    const raw = kind === "story" ? asString(hit.story_text) : asString(hit.comment_text);
    const title = asString(hit.title) ?? asString(hit.story_title);
    if (!raw || !title) continue;
    out.push({
      externalId: `hn:${id}`,
      sourceId: "hackernews",
      sourceName: "Hacker News",
      kind,
      title: decodeEntities(title).trim(),
      body: stripHtml(raw),
      url: `https://news.ycombinator.com/item?id=${id}`,
      author: asString(hit.author),
      postedAt: toIso(hit.created_at) ?? toIso(hit.created_at_i),
      score: Math.round(asNumber(hit.points) ?? 0),
    });
  }
  return out;
}

function parseSe(json: unknown, key: SeKey): Candidate[] {
  const out: Candidate[] = [];
  const { site, name } = SE_SITES[key];
  for (const it of asArray(asRecord(json)?.items)) {
    const item = asRecord(it);
    const id = asNumber(item?.question_id);
    const title = asString(item?.title);
    const link = asString(item?.link);
    const html = asString(item?.body);
    if (!item || !id || !title || !link || !html) continue;
    const owner = asRecord(item.owner);
    out.push({
      externalId: `${site}-se:${id}`,
      sourceId: key,
      sourceName: name,
      kind: "question",
      title: decodeEntities(title).trim(),
      body: stripHtml(html),
      url: link,
      author: owner ? asString(owner.display_name) : null,
      postedAt: toIso(item.creation_date),
      score: Math.round(asNumber(item.score) ?? 0),
    });
  }
  return out;
}

/** Lemmy bodies are markdown: turn [text](url) into text and drop bare link noise. */
function cleanMarkdown(md: string): string {
  return md
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\((?:https?:\/\/)[^)]*\)/g, "$1")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/[*_`>#]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseLemmy(json: unknown): Candidate[] {
  const out: Candidate[] = [];
  for (const p of asArray(asRecord(json)?.posts)) {
    const view = asRecord(p);
    const post = asRecord(view?.post);
    const id = asNumber(post?.id);
    const title = asString(post?.name);
    const body = asString(post?.body);
    if (!view || !post || !id || !title || !body) continue;
    if (post.removed === true || post.deleted === true || post.nsfw === true) continue;
    const creator = asRecord(view.creator);
    const counts = asRecord(view.counts);
    out.push({
      externalId: `lemmy:${id}`,
      sourceId: "lemmy",
      sourceName: "Lemmy",
      kind: "post",
      title: decodeEntities(title).trim(),
      body: cleanMarkdown(body),
      url: `https://lemmy.world/post/${id}`,
      author: creator ? asString(creator.name) : null,
      postedAt: toIso(post.published),
      score: Math.round(asNumber(counts?.score) ?? 0),
    });
  }
  return out;
}

function parseReddit(json: unknown): Candidate[] {
  const out: Candidate[] = [];
  for (const c of asArray(asRecord(asRecord(json)?.data)?.children)) {
    const post = asRecord(asRecord(c)?.data);
    const id = asString(post?.id);
    const title = asString(post?.title);
    const permalink = asString(post?.permalink);
    const text = asString(post?.selftext) ?? "";
    if (!post || !id || !title || !permalink) continue;
    if (post.is_self !== true || post.over_18 === true || post.stickied === true) continue;
    if (post.removed_by_category !== null && post.removed_by_category !== undefined) continue;
    if (text === "[removed]" || text === "[deleted]") continue;
    const author = asString(post.author);
    out.push({
      externalId: `reddit:${id}`,
      sourceId: "reddit-live",
      sourceName: `Reddit ${asString(post.subreddit_name_prefixed) ?? ""}`.trim(),
      kind: "post",
      title: decodeEntities(title).trim(),
      body: decodeEntities(text).trim(),
      url: `https://www.reddit.com${permalink}`,
      author: author && author !== "[deleted]" ? `u/${author}` : null,
      postedAt: toIso(post.created_utc),
      score: Math.round(asNumber(post.score) ?? 0),
    });
  }
  return out;
}

// ---------------------------------------------------------------------------
// Validation: every record must pass before it is stored or shown.
// ---------------------------------------------------------------------------
function validate(c: Candidate): string | null {
  let host = "";
  try {
    const u = new URL(c.url);
    if (u.protocol !== "https:") return "bad-url";
    host = u.host;
  } catch {
    return "bad-url";
  }
  const allow = HOST_ALLOW[c.sourceId];
  if (allow && !allow(host)) return "bad-url";
  if (!c.title || c.title.length < 5) return "too-short";
  if (!c.body) return "no-text";
  if (c.body.length < MIN_TEXT) return "too-short";
  if (!c.postedAt || Number.isNaN(Date.parse(c.postedAt)) || Date.parse(c.postedAt) > Date.now() + 86_400_000) return "bad-date";
  const letters = (c.body.match(/\p{L}/gu) ?? []).length;
  const links = (c.body.match(/https?:\/\//g) ?? []).length;
  if (letters / c.body.length < 0.55 || links > 6 || /(.)\1{14,}/.test(c.body)) return "spammy";
  return null;
}

// ---------------------------------------------------------------------------
// Deep read: for the best matches, pull what is inside the thread (top answers / comments).
// ---------------------------------------------------------------------------
const DEEP_QUESTIONS = 3;
const DEEP_PER_QUESTION = 2;

async function deepStackExchange(key: SeKey, top: { c: Candidate; relevance: number }[]): Promise<{ c: Candidate; relevance: number; firsthand: boolean }[]> {
  const { site, name } = SE_SITES[key];
  const picks = top.slice(0, DEEP_QUESTIONS);
  if (picks.length === 0) return [];
  const ids = picks.map((p) => p.c.externalId.split(":")[1]).join(";");
  const keyParam = process.env.STACKEXCHANGE_KEY ? `&key=${encodeURIComponent(process.env.STACKEXCHANGE_KEY)}` : "";
  const url = `https://api.stackexchange.com/2.3/questions/${ids}/answers?order=desc&sort=votes&site=${site}&filter=withbody&pagesize=30${keyParam}`;
  const json = await fetchJson(url, { timeoutMs: 10_000 });
  const byQuestion = new Map(picks.map((p) => [p.c.externalId.split(":")[1], p]));
  const taken = new Map<string, number>();
  const out: { c: Candidate; relevance: number; firsthand: boolean }[] = [];
  for (const it of asArray(asRecord(json)?.items)) {
    const a = asRecord(it);
    const aid = asNumber(a?.answer_id);
    const qid = String(asNumber(a?.question_id) ?? "");
    const html = asString(a?.body);
    const parent = byQuestion.get(qid);
    if (!a || !aid || !html || !parent) continue;
    if ((taken.get(qid) ?? 0) >= DEEP_PER_QUESTION) continue;
    const body = stripHtml(html);
    const owner = asRecord(a.owner);
    const cand: Candidate = {
      externalId: `${site}-se-a:${aid}`,
      sourceId: key,
      sourceName: name,
      kind: "answer",
      title: parent.c.title,
      body,
      url: `https://${site}.stackexchange.com/a/${aid}`,
      author: owner ? asString(owner.display_name) : null,
      postedAt: toIso(a.creation_date),
      score: Math.round(asNumber(a.score) ?? 0),
    };
    if (validate(cand)) continue;
    taken.set(qid, (taken.get(qid) ?? 0) + 1);
    out.push({ c: cand, relevance: Math.round(parent.relevance * 90) / 100, firsthand: isFirsthand(body) });
  }
  return out;
}

async function deepHackerNews(top: { c: Candidate; relevance: number }[], kws: string[]): Promise<{ c: Candidate; relevance: number; firsthand: boolean }[]> {
  const out: { c: Candidate; relevance: number; firsthand: boolean }[] = [];
  const picks = top.filter((p) => p.c.kind === "story").slice(0, 2);
  const threads = await Promise.all(
    picks.map(async (p) => {
      try {
        return { p, json: await fetchJson(`https://hn.algolia.com/api/v1/items/${p.c.externalId.slice(3)}`, { timeoutMs: 10_000 }) };
      } catch {
        return null;
      }
    })
  );
  for (const t of threads) {
    if (!t) continue;
    const kids = asArray(asRecord(t.json)?.children);
    const found: { c: Candidate; relevance: number; firsthand: boolean }[] = [];
    for (const k of kids) {
      const kid = asRecord(k);
      const id = asString(kid?.id);
      const text = asString(kid?.text);
      if (!kid || !id || !text) continue;
      const body = stripHtml(text);
      const cand: Candidate = {
        externalId: `hn:${id}`,
        sourceId: "hackernews",
        sourceName: "Hacker News",
        kind: "comment",
        title: t.p.c.title,
        body,
        url: `https://news.ycombinator.com/item?id=${id}`,
        author: asString(kid.author),
        postedAt: toIso(kid.created_at) ?? toIso(kid.created_at_i),
        score: 0,
      };
      if (body.length < 220 || validate(cand)) continue;
      const own = scoreItem({ title: cand.title, body, kws, points: 0, postedAt: cand.postedAt });
      found.push({ c: cand, relevance: Math.round((t.p.relevance * 0.6 + own.relevance * 0.4) * 100) / 100, firsthand: own.firsthand });
    }
    out.push(...found.sort((a, b) => b.relevance - a.relevance).slice(0, 3));
  }
  return out;
}

// ---------------------------------------------------------------------------
// Storage
// ---------------------------------------------------------------------------
async function store(cands: Candidate[]): Promise<Map<string, string>> {
  const ids = new Map<string, string>();
  if (!hasSupabase() || cands.length === 0) return ids;
  try {
    const db = createAdminClient();
    const sourceIds = Array.from(new Set(cands.map((c) => c.sourceId)));
    await db.from("sources").upsert(
      sourceIds.map((id) => ({ id, ...SOURCE_ROWS[id] })),
      { onConflict: "id", ignoreDuplicates: true }
    );
    const rows = cands.map((c) => ({
      source_id: c.sourceId,
      external_id: c.externalId,
      url: c.url,
      title: c.title.slice(0, 300),
      body: c.body.slice(0, 20_000),
      author_handle: c.author,
      posted_at: c.postedAt,
      score: c.score,
      process_note: "Fetched live from a user question",
    }));
    const { data, error } = await db.from("raw_items").upsert(rows, { onConflict: "external_id" }).select("id, external_id");
    if (error) console.warn("[research] raw_items upsert failed:", error.message);
    for (const r of data ?? []) ids.set(r.external_id, r.id);
  } catch (err) {
    console.warn("[research] store failed:", (err as Error).message);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// Public entry
// ---------------------------------------------------------------------------
const cache = new Map<string, { at: number; value: SourceResponse }>();

export async function researchSource(key: ResearchSourceKey, q: string): Promise<SourceResponse> {
  const started = Date.now();
  const requestUrl = requestUrlFor(key, q);
  const emptyReport = (patch: Partial<SourceReport>): SourceReport => ({
    key,
    label: SOURCE_LABEL[key],
    requestUrl,
    status: "ok",
    fetched: 0,
    kept: 0,
    stored: 0,
    rejected: 0,
    rejectedReasons: {},
    ms: Date.now() - started,
    ...patch,
  });

  if (key === "reddit" && !redditConfigured()) {
    return {
      items: [],
      report: emptyReport({ status: "skipped", error: "Not connected. Add REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET to enable Reddit." }),
    };
  }

  const cacheKey = `v${CACHE_VERSION}|${key}|${q.trim().toLowerCase()}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < CACHE_MS) {
    return { items: hit.value.items, report: { ...hit.value.report, cached: true, ms: Date.now() - started } };
  }

  try {
    // Long, specific questions often match nothing when every word is required. Run progressively
    // looser searches, pool the candidates, and let the relevance scorer (full question) decide.
    let json: unknown = null;
    let usedUrl = requestUrl;
    const pooled = new Map<string, Candidate>();
    let best = -1;
    for (let variant = 0; variant < VARIANT_SIZES.length; variant++) {
      if (variant > 0 && keywords(q).length <= VARIANT_SIZES[variant]) continue;
      const payload = await fetchPayload(key, q, variant);
      const parsed =
        key === "hn-stories"
          ? parseHn(payload, "story")
          : key === "hn-comments"
            ? parseHn(payload, "comment")
            : key === "lemmy"
              ? parseLemmy(payload)
              : key === "reddit"
                ? parseReddit(payload)
                : parseSe(payload, key as SeKey);
      for (const c of parsed) if (!pooled.has(c.externalId)) pooled.set(c.externalId, c);
      if (parsed.length > best) {
        best = parsed.length;
        json = payload;
        usedUrl = requestUrlFor(key, q, variant);
      }
      if (pooled.size >= 25) break;
    }
    const cands = Array.from(pooled.values());
    const rootHits = asRecord(json);
    const fetched =
      key === "lemmy"
        ? asArray(rootHits?.posts).length
        : key === "reddit"
          ? asArray(asRecord(rootHits?.data)?.children).length
          : asArray(rootHits?.hits ?? rootHits?.items).length;

    const kws = keywords(q);
    const weights = keywordWeights(cands.map((c) => `${c.title} ${c.body}`), kws);
    const reasons: Record<string, number> = {};
    const reject = (r: string) => {
      reasons[r] = (reasons[r] ?? 0) + 1;
    };
    const titles = new Set<string>();
    const valid: { c: Candidate; relevance: number; firsthand: boolean }[] = [];
    for (const c of cands) {
      const bad = validate(c);
      if (bad) {
        reject(bad);
        continue;
      }
      const tkey = c.title.toLowerCase();
      if (titles.has(tkey)) {
        reject("duplicate");
        continue;
      }
      titles.add(tkey);
      const s = scoreItem({ title: c.title, body: c.body, kws, points: c.score, postedAt: c.postedAt, weights });
      // Needs real overlap, and either a title match or a very strong body match.
      if (s.coverage < MIN_COVERAGE || (s.titleCoverage === 0 && s.coverage < 0.75)) {
        reject("low-match");
        continue;
      }
      valid.push({ c, relevance: s.relevance, firsthand: s.firsthand });
    }
    // Items the API returned without usable text are rejected above; count the rest as unusable too.
    const dropped = Math.max(0, fetched - cands.length);
    if (dropped > 0) reasons["no-text"] = (reasons["no-text"] ?? 0) + dropped;

    const top = valid.sort((a, b) => b.relevance - a.relevance).slice(0, KEEP);
    // Specific questions (several distinctive keywords) get a deeper read of the best threads.
    let deep: { c: Candidate; relevance: number; firsthand: boolean }[] = [];
    if (kws.length >= 3 && top.length > 0) {
      try {
        if (isSe(key)) deep = await deepStackExchange(key, top);
        else if (key === "hn-stories") deep = await deepHackerNews(top, kws);
      } catch {
        deep = [];
      }
    }
    const deepIds = new Set(deep.map((d) => d.c.externalId));
    const combined = [...top, ...deep.filter((d) => !top.some((t) => t.c.externalId === d.c.externalId))];
    const ids = await store(combined.map((x) => x.c));
    const items: Evidence[] = combined.map(({ c, relevance, firsthand }) => ({
      deep: deepIds.has(c.externalId),
      rawId: ids.get(c.externalId) ?? null,
      externalId: c.externalId,
      sourceId: c.sourceId,
      sourceName: c.sourceName,
      kind: c.kind,
      title: c.title,
      excerpt: bestExcerpt(c.body, kws),
      url: c.url,
      rawApiUrl: rawApiUrlFor(c.externalId),
      author: c.author,
      postedAt: c.postedAt,
      score: c.score,
      relevance,
      firsthand,
    }));
    const rejected = Object.values(reasons).reduce((a, b) => a + b, 0);
    const value: SourceResponse = {
      items,
      report: emptyReport({ requestUrl: usedUrl, fetched, kept: items.length, stored: ids.size, rejected, rejectedReasons: reasons }),
    };
    cache.set(cacheKey, { at: Date.now(), value });
    return value;
  } catch (err) {
    return { items: [], report: emptyReport({ status: "error", error: (err as Error).message }) };
  }
}

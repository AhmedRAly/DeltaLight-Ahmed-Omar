import type { Json } from "./database.types";
import { num } from "./utils";

export type GlobalInsights = {
  gaps_by_category: { category: string; n: number; avg_predicted: number | null; avg_actual: number | null; gap: number | null }[];
  most_regretted: { option: string; n: number; would_choose_again_pct: number | null; avg_regret: number | null; avg_actual: number | null; category: string }[];
  would_do_again: { option: string; n: number; would_choose_again_pct: number | null; avg_regret: number | null; category: string }[];
  story_outcomes: { category: string; total: number; success: number; mixed: number; failure: number; ongoing: number }[];
  story_tags: { tag: string; n: number }[];
  top_lessons: { story_id: string; title: string; source_id: string; outcome_type: string; created_at: string; lesson: string }[];
  totals: {
    decisions: number;
    checkins: number;
    stories: number;
    avg_gap: number | null;
    again_pct: number | null;
  };
};

function arr(v: unknown): unknown[] {
  return Array.isArray(v) ? v : [];
}

export function parseInsights(json: Json | null): GlobalInsights {
  const o = (json && typeof json === "object" ? json : {}) as Record<string, unknown>;
  return {
    gaps_by_category: arr(o.gaps_by_category).map((c) => {
      const x = c as Record<string, unknown>;
      return {
        category: String(x.category ?? ""),
        n: num(x.n) ?? 0,
        avg_predicted: num(x.avg_predicted),
        avg_actual: num(x.avg_actual),
        gap: num(x.gap),
      };
    }),
    most_regretted: arr(o.most_regretted).map((c) => {
      const x = c as Record<string, unknown>;
      return {
        option: String(x.option ?? x.choice ?? ""),
        n: num(x.n) ?? 0,
        would_choose_again_pct: num(x.would_choose_again_pct ?? x.again_pct),
        avg_regret: num(x.avg_regret),
        avg_actual: num(x.avg_actual),
        category: String(x.category ?? ""),
      };
    }),
    would_do_again: arr(o.would_do_again).map((c) => {
      const x = c as Record<string, unknown>;
      return {
        option: String(x.option ?? x.choice ?? ""),
        n: num(x.n) ?? 0,
        would_choose_again_pct: num(x.would_choose_again_pct ?? x.again_pct),
        avg_regret: num(x.avg_regret),
        category: String(x.category ?? ""),
      };
    }),
    story_outcomes: arr(o.story_outcomes).map((c) => {
      const x = c as Record<string, unknown>;
      return {
        category: String(x.category ?? ""),
        total: num(x.total) ?? 0,
        success: num(x.success) ?? 0,
        mixed: num(x.mixed) ?? 0,
        failure: num(x.failure) ?? 0,
        ongoing: num(x.ongoing) ?? 0,
      };
    }),
    story_tags: arr(o.story_tags).map((c) => {
      const x = c as Record<string, unknown>;
      return { tag: String(x.tag ?? ""), n: num(x.n) ?? 0 };
    }),
    top_lessons: arr(o.top_lessons).map((c) => {
      const x = c as Record<string, unknown>;
      return {
        story_id: String(x.story_id ?? ""),
        title: String(x.title ?? ""),
        source_id: String(x.source_id ?? ""),
        outcome_type: String(x.outcome_type ?? ""),
        created_at: String(x.created_at ?? ""),
        lesson: String(x.lesson ?? ""),
      };
    }),
    totals: {
      decisions: num((o.totals as Record<string, unknown> | undefined)?.decisions) ?? 0,
      checkins: num((o.totals as Record<string, unknown> | undefined)?.checkins) ?? 0,
      stories: num((o.totals as Record<string, unknown> | undefined)?.stories) ?? 0,
      avg_gap: num((o.totals as Record<string, unknown> | undefined)?.avg_gap),
      again_pct: num((o.totals as Record<string, unknown> | undefined)?.again_pct),
    },
  };
}
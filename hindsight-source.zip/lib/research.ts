// Shared, dependency-free types and helpers for live research (safe to import from client components).

export type ResearchSourceKey =
  | "hn-stories"
  | "hn-comments"
  | "reddit"
  | "workplace-se"
  | "money-se"
  | "softwareengineering-se"
  | "academia-se"
  | "law-se"
  | "lemmy";

export type EvidenceKind = "story" | "comment" | "question" | "post" | "answer";

export type Evidence = {
  /** raw_items.id — links to /source/[id]. null only if storing failed. */
  rawId: string | null;
  externalId: string;
  sourceId: string;
  sourceName: string;
  kind: EvidenceKind;
  title: string;
  /** Short window of the original text around the matched keywords. */
  excerpt: string;
  /** Link to the original public post. */
  url: string;
  /** Machine-readable record this was parsed from. */
  rawApiUrl: string;
  author: string | null;
  postedAt: string | null;
  score: number;
  relevance: number;
  /** Written in the first person and mentions an outcome. */
  firsthand: boolean;
  /** Pulled from inside a thread (top answer or comment) rather than the headline match. */
  deep?: boolean;
};

export type SourceReport = {
  key: ResearchSourceKey;
  label: string;
  /** The exact request made (public API URL). */
  requestUrl: string;
  status: "ok" | "error" | "skipped";
  fetched: number;
  kept: number;
  stored: number;
  rejected: number;
  rejectedReasons: Record<string, number>;
  ms: number;
  cached?: boolean;
  error?: string;
};

export type SourceResponse = { items: Evidence[]; report: SourceReport };

export const SOURCE_LABEL: Record<ResearchSourceKey, string> = {
  "hn-stories": "Hacker News posts",
  "hn-comments": "Hacker News comments",
  reddit: "Reddit",
  "workplace-se": "Workplace Stack Exchange",
  "money-se": "Money Stack Exchange",
  "softwareengineering-se": "Software Eng. Stack Exchange",
  "academia-se": "Academia Stack Exchange",
  "law-se": "Law Stack Exchange",
  lemmy: "Lemmy",
};

export const RESEARCH_SOURCES = Object.keys(SOURCE_LABEL) as ResearchSourceKey[];

export const REJECT_LABEL: Record<string, string> = {
  "bad-url": "unexpected link host",
  "too-short": "too short to be useful",
  "bad-date": "invalid date",
  spammy: "looks like spam",
  "low-match": "weak match to your question",
  duplicate: "duplicate",
  "no-text": "no body text",
};

const STOP = new Set(
  "a about above after again all also am an and any are as at be because been before being below between both but by can could did do does doing down during each few for from further had has have having he her here hers him his how i if in into is it its just me more most my myself no nor not of off on once only or other our out over own same she should so some such than that the their them then there these they this those through to too under until up very was we were what when where which while who whom why will with would you your yours need advice want help think about get going thinking whether keep keeping make take doing someone anyone really better best good right thing things way".split(
    " "
  )
);

export function keywords(q: string, max = 7): string[] {
  const words = q
    .toLowerCase()
    .replace(/[^a-z0-9$%\s'-]/g, " ")
    .split(/\s+/)
    .map((w) => w.replace(/^['-]+|['-]+$/g, ""))
    .filter((w) => w.length > 1 && !STOP.has(w));
  return Array.from(new Set(words)).slice(0, max);
}

/** Deterministic machine-readable URL for an item, so anyone can re-fetch the raw record. */
export function rawApiUrlFor(externalId: string): string {
  if (externalId.startsWith("hn:")) return `https://hn.algolia.com/api/v1/items/${externalId.slice(3)}`;
  const seA = externalId.match(/^(workplace|money|softwareengineering|academia|law)-se-a:(\d+)$/);
  if (seA) return `https://api.stackexchange.com/2.3/answers/${seA[2]}?site=${seA[1]}&filter=withbody`;
  const se = externalId.match(/^(workplace|money|softwareengineering|academia|law)-se:(\d+)$/);
  if (se) return `https://api.stackexchange.com/2.3/questions/${se[2]}?site=${se[1]}&filter=withbody`;
  const lemmy = externalId.match(/^lemmy:(\d+)$/);
  if (lemmy) return `https://lemmy.world/api/v3/post?id=${lemmy[1]}`;
  const reddit = externalId.match(/^reddit:([a-z0-9]+)$/i);
  if (reddit) return `https://www.reddit.com/comments/${reddit[1]}.json`;
  return "";
}

export function bestExcerpt(text: string, kws: string[], size = 420): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= size) return clean;
  const lower = clean.toLowerCase();
  let pos = -1;
  for (const k of kws) {
    const i = lower.indexOf(k);
    if (i !== -1 && (pos === -1 || i < pos)) pos = i;
  }
  const start = pos <= 0 ? 0 : Math.max(0, pos - Math.floor(size / 3));
  let slice = clean.slice(start, start + size);
  if (start > 0) slice = "…" + slice.replace(/^\S*\s/, "");
  if (start + size < clean.length) slice = slice.replace(/\s\S*$/, "") + "…";
  return slice;
}

const FIRST_PERSON = /\b(i|i'm|i've|i'd|my|we|our|we've)\b/i;
const OUTCOME = /\b(quit|left|launched|started|joined|moved|switched|accepted|declined|regret|worked out|failed|shut down|promoted|laid off|fired|years? later|months? later|now i|ended up)\b/i;

export function isFirsthand(text: string): boolean {
  return FIRST_PERSON.test(text) && OUTCOME.test(text);
}

export type Scored = { relevance: number; coverage: number; titleCoverage: number; firsthand: boolean };

/** Relevance 0..1: keyword coverage dominates; firsthand experience, title match, popularity and recency refine. */
const wordCache = new Map<string, RegExp>();
/** Whole-word match that tolerates simple endings (plural, -ed, -ing), so "mba" never matches "combat". */
export function hasWord(haystack: string, word: string): boolean {
  let re = wordCache.get(word);
  if (!re) {
    re = new RegExp(`(?<![\\p{L}\\p{N}])${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:s|es|ed|ing|d)?(?![\\p{L}\\p{N}])`, "iu");
    wordCache.set(word, re);
  }
  return re.test(haystack);
}

/** Rare keywords (few results contain them) weigh more than generic ones that appear everywhere. */
export function keywordWeights(docs: string[], kws: string[]): number[] {
  const n = docs.length;
  if (n < 6) return kws.map(() => 1);
  const lowered = docs.map((d) => d.toLowerCase());
  return kws.map((k) => {
    const df = lowered.reduce((c, d) => (hasWord(d, k) ? c + 1 : c), 0);
    return Math.log(1 + n / (df + 0.5));
  });
}

export function scoreItem(opts: { title: string; body: string; kws: string[]; points: number; postedAt: string | null; weights?: number[] }): Scored {
  const { title, body, kws, points, postedAt } = opts;
  const weights = opts.weights && opts.weights.length === kws.length ? opts.weights : kws.map(() => 1);
  const totalW = weights.reduce((a, b) => a + b, 0) || 1;
  if (kws.length === 0) return { relevance: 0, coverage: 0, titleCoverage: 0, firsthand: false };
  const t = title.toLowerCase();
  const hay = `${t} ${body.toLowerCase()}`;
  let hit = 0;
  let titleHit = 0;
  kws.forEach((k, i) => {
    if (hasWord(hay, k)) hit += weights[i];
    if (hasWord(t, k)) titleHit += weights[i];
  });
  const coverage = hit / totalW;
  const titleCov = titleHit / totalW;
  const firsthand = isFirsthand(body);
  const popularity = Math.min(1, Math.log10(1 + Math.max(0, points)) / 3);
  let recency = 0;
  if (postedAt) {
    const ageYears = (Date.now() - Date.parse(postedAt)) / (365 * 24 * 3600 * 1000);
    recency = Math.max(0, 1 - ageYears / 6);
  }
  const relevance = coverage * 0.6 + titleCov * 0.15 + (firsthand ? 0.1 : 0) + popularity * 0.1 + recency * 0.05;
  return { relevance: Math.round(Math.min(1, relevance) * 100) / 100, coverage, titleCoverage: titleCov, firsthand };
}

export function hostOf(url: string): string {
  try {
    return new URL(url).host.replace(/^www\./, "");
  } catch {
    return url;
  }
}

export type SortMode = "relevant" | "recent";

export function sortEvidence(items: Evidence[], mode: SortMode): Evidence[] {
  const copy = [...items];
  if (mode === "recent") {
    return copy.sort((a, b) => Date.parse(b.postedAt ?? "1970-01-01") - Date.parse(a.postedAt ?? "1970-01-01"));
  }
  return copy.sort((a, b) => b.relevance - a.relevance || b.score - a.score);
}

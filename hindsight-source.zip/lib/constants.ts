export const CATEGORIES = [
  "business",
  "career",
  "money",
  "education",
  "relationships",
  "location",
  "other",
] as const;
export type Category = (typeof CATEGORIES)[number];

export const HORIZONS = ["1w", "1m", "6m", "1y"] as const;
export type Horizon = (typeof HORIZONS)[number];
export const HORIZON_LABEL: Record<Horizon, string> = {
  "1w": "1 week",
  "1m": "1 month",
  "6m": "6 months",
  "1y": "1 year",
};

export const OUTCOME_TYPES = ["success", "mixed", "failure", "ongoing"] as const;
export type OutcomeType = (typeof OUTCOME_TYPES)[number];

export const PATHS = ["business", "corporate", "both"] as const;
export type PathKind = (typeof PATHS)[number];

export const STAGES = ["idea", "building", "launched", "employed", "switching"] as const;
export type Stage = (typeof STAGES)[number];
export const STAGE_LABEL: Record<Stage, string> = {
  idea: "Idea stage",
  building: "Building",
  launched: "Launched",
  employed: "Employed, climbing",
  switching: "Switching careers",
};

export const LOOKING_FOR = ["cofounder", "accountability", "mentor", "network", "hire"] as const;
export type LookingFor = (typeof LOOKING_FOR)[number];
export const LOOKING_FOR_LABEL: Record<LookingFor, string> = {
  cofounder: "Co-founder",
  accountability: "Accountability partner",
  mentor: "Mentor",
  network: "Network",
  hire: "Hire / get hired",
};

export const EXAMPLE_DECISIONS = [
  "Should I quit my job to work on my startup full-time?",
  "Take the promotion to manager or stay an engineer?",
  "Bootstrap or raise a pre-seed round?",
  "Switch from finance into software engineering?",
  "Do an MBA or keep working?",
  "Move to a new city for a higher-paying job?",
];

export type SourceMeta = {
  id: string;
  name: string;
  short: string;
  type: string;
  baseUrl: string;
  color: string;
};

// Keep in sync with the INSERT at the bottom of the migration.
export const SOURCES: SourceMeta[] = [
  { id: "reddit-entrepreneur", name: "r/Entrepreneur", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com/r/Entrepreneur", color: "#ff5700" },
  { id: "reddit-startups", name: "r/startups", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com/r/startups", color: "#ff5700" },
  { id: "reddit-smallbusiness", name: "r/smallbusiness", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com/r/smallbusiness", color: "#ff5700" },
  { id: "reddit-career", name: "r/careerguidance + r/careeradvice", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com/r/careerguidance", color: "#ff5700" },
  { id: "reddit-sideproject", name: "r/SideProject + r/SaaS", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com/r/SideProject", color: "#ff5700" },
  { id: "hackernews", name: "Hacker News", short: "HN", type: "algolia", baseUrl: "https://news.ycombinator.com", color: "#ff6600" },
  { id: "indiehackers", name: "Indie Hackers", short: "IH", type: "rss", baseUrl: "https://www.indiehackers.com", color: "#4f7cff" },
  { id: "producthunt", name: "Product Hunt", short: "PH", type: "graphql", baseUrl: "https://www.producthunt.com", color: "#da552f" },
  { id: "workplace-se", name: "The Workplace (Stack Exchange)", short: "Workplace SE", type: "stackexchange", baseUrl: "https://workplace.stackexchange.com", color: "#3b9cff" },
  { id: "devto-medium", name: "Dev.to + Medium", short: "Dev.to / Medium", type: "api+rss", baseUrl: "https://dev.to", color: "#a3a3a3" },
];

// Sources only used by live research (not part of the scheduled ingestion registry).
export const LIVE_ONLY_SOURCES: SourceMeta[] = [
  { id: "money-se", name: "Personal Finance & Money (Stack Exchange)", short: "Money SE", type: "stackexchange", baseUrl: "https://money.stackexchange.com", color: "#4ade80" },
  { id: "softwareengineering-se", name: "Software Engineering (Stack Exchange)", short: "SWE SE", type: "stackexchange", baseUrl: "https://softwareengineering.stackexchange.com", color: "#60a5fa" },
  { id: "academia-se", name: "Academia (Stack Exchange)", short: "Academia SE", type: "stackexchange", baseUrl: "https://academia.stackexchange.com", color: "#c084fc" },
  { id: "law-se", name: "Law (Stack Exchange)", short: "Law SE", type: "stackexchange", baseUrl: "https://law.stackexchange.com", color: "#fbbf24" },
  { id: "lemmy", name: "Lemmy", short: "Lemmy", type: "lemmy", baseUrl: "https://lemmy.world", color: "#00bc8c" },
  { id: "reddit-live", name: "Reddit", short: "Reddit", type: "reddit", baseUrl: "https://www.reddit.com", color: "#ff5700" },
];

export const SOURCE_BY_ID: Record<string, SourceMeta> = Object.fromEntries([...SOURCES, ...LIVE_ONLY_SOURCES].map((s) => [s.id, s]));

export function sourceLabel(id: string, url?: string): string {
  const meta = SOURCE_BY_ID[id];
  if (!meta) return id;
  if (id === "devto-medium" && url) return url.includes("medium.com") ? "Medium" : "Dev.to";
  if (meta.type === "reddit" && url) {
    const m = url.match(/reddit\.com\/r\/([^/]+)/i);
    if (m) return `r/${m[1]}`;
  }
  return meta.name;
}

// OpenAI helpers. Every call is wrapped so failures return null and the
// app can fall back to Postgres full-text search instead of crashing.
// Uses relative imports only so the ingestion/seed scripts can import it via tsx.
import OpenAI from "openai";
import type { z } from "zod";

export const EMBEDDING_MODEL = "text-embedding-3-small";
export const CHAT_MODEL = "gpt-4o-mini";

let client: OpenAI | null | undefined;

export function getOpenAI(): OpenAI | null {
  if (client !== undefined) return client;
  const key = process.env.OPENAI_API_KEY;
  client = key ? new OpenAI({ apiKey: key, timeout: 20_000, maxRetries: 1 }) : null;
  return client;
}

export function hasOpenAI(): boolean {
  return Boolean(process.env.OPENAI_API_KEY);
}

function clip(text: string, max = 8000): string {
  return text.length > max ? text.slice(0, max) : text;
}

export async function embed(text: string): Promise<number[] | null> {
  const res = await embedMany([text]);
  return res?.[0] ?? null;
}

export async function embedMany(texts: string[]): Promise<number[][] | null> {
  const ai = getOpenAI();
  if (!ai || texts.length === 0) return null;
  try {
    const out: number[][] = [];
    for (let i = 0; i < texts.length; i += 96) {
      const batch = texts.slice(i, i + 96).map((t) => clip(t.replace(/\s+/g, " ").trim() || "empty"));
      const res = await ai.embeddings.create({ model: EMBEDDING_MODEL, input: batch });
      for (const d of res.data.sort((a, b) => a.index - b.index)) out.push(d.embedding);
    }
    return out;
  } catch (err) {
    console.warn("[ai] embedding failed:", (err as Error).message);
    return null;
  }
}

export async function chatJSON<T>(opts: {
  system: string;
  user: string;
  schema: z.ZodType<T, z.ZodTypeDef, unknown>;
  maxTokens?: number;
  temperature?: number;
}): Promise<T | null> {
  const ai = getOpenAI();
  if (!ai) return null;
  try {
    const res = await ai.chat.completions.create({
      model: CHAT_MODEL,
      temperature: opts.temperature ?? 0.1,
      max_tokens: opts.maxTokens ?? 900,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: opts.system },
        { role: "user", content: clip(opts.user, 14000) },
      ],
    });
    const raw = res.choices[0]?.message?.content;
    if (!raw) return null;
    const parsed = opts.schema.safeParse(JSON.parse(raw));
    if (!parsed.success) {
      console.warn("[ai] schema validation failed:", parsed.error.issues.slice(0, 3));
      return null;
    }
    return parsed.data;
  } catch (err) {
    console.warn("[ai] chat failed:", (err as Error).message);
    return null;
  }
}

export async function chatText(system: string, user: string, maxTokens = 220): Promise<string | null> {
  const ai = getOpenAI();
  if (!ai) return null;
  try {
    const res = await ai.chat.completions.create({
      model: CHAT_MODEL,
      temperature: 0.3,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: system },
        { role: "user", content: clip(user, 12000) },
      ],
    });
    return res.choices[0]?.message?.content?.trim() || null;
  } catch (err) {
    console.warn("[ai] chat failed:", (err as Error).message);
    return null;
  }
}

import type { PartnerMatch } from "./database.types";

export type MatchExplanation = {
  youNeed: string[];
  theyHave: string[];
  theyNeed: string[];
  youHave: string[];
  sentence: string;
};

function list(items: string[]) {
  if (items.length <= 1) return items.join("");
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

function firstSentence(text: string) {
  const s = text.split(/(?<=[.!?])\s/)[0] ?? text;
  return s.length > 110 ? `${s.slice(0, 107)}…` : s;
}

export function explainMatch(m: Pick<PartnerMatch, "they_have_i_need" | "i_have_they_need" | "goal_score" | "goals" | "path" | "stage">, me?: { path: string; stage: string } | null): MatchExplanation {
  const parts: string[] = [];
  if (m.they_have_i_need.length) parts.push(`You need ${list(m.they_have_i_need)} — they have it.`);
  if (m.i_have_they_need.length) parts.push(`They need ${list(m.i_have_they_need)} — you have it.`);
  if (m.goal_score >= 0.55) parts.push(`Closely aligned goals: “${firstSentence(m.goals)}”`);
  else if (m.goal_score >= 0.3) parts.push(`Related goals: “${firstSentence(m.goals)}”`);
  if (me && me.path === m.path && me.stage === m.stage) parts.push(`Same path and stage (${m.path}, ${m.stage}).`);
  if (parts.length === 0) parts.push(`Working on: “${firstSentence(m.goals)}”`);
  return {
    youNeed: m.they_have_i_need,
    theyHave: m.they_have_i_need,
    theyNeed: m.i_have_they_need,
    youHave: m.i_have_they_need,
    sentence: parts.join(" "),
  };
}

export const SKILL_SUGGESTIONS = [
  "react",
  "typescript",
  "python",
  "sales",
  "b2b sales",
  "marketing",
  "seo",
  "copywriting",
  "design",
  "ui/ux",
  "product management",
  "fundraising",
  "finance",
  "operations",
  "data analysis",
  "machine learning",
  "public speaking",
  "leadership",
  "negotiation",
  "hiring",
  "content creation",
  "community building",
  "devops",
  "mobile",
  "accounting",
  "project management",
  "sql",
  "customer success",
];

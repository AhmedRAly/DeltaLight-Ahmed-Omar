// Local demo store for the community board. A JSON file seeded with hardcoded content on first use.
// Server-only. Swap for a real database later; the functions below are the whole surface.
import fs from "node:fs";
import path from "node:path";
import { CATEGORIES, type Category } from "./constants";
import { SEED_QUESTIONS } from "./community-seed";

export type Question = {
  id: string;
  title: string;
  body: string;
  category: Category;
  authorId: string | null;
  authorName: string;
  sample: boolean;
  createdAt: string;
};
export type Answer = {
  id: string;
  questionId: string;
  authorId: string | null;
  authorName: string;
  body: string;
  sample: boolean;
  createdAt: string;
};
export type QuestionView = Question & { answerCount: number };

type DB = {
  questions: Question[];
  answers: Answer[];
  unlocks: { userId: string; questionId: string }[];
  searches: { userId: string; q: string; count: number; at: string }[];
};

const FILE = path.join(process.cwd(), ".data", "community.json");
const hoursAgo = (h: number) => new Date(Date.now() - h * 3600 * 1000).toISOString();

function seed(): DB {
  const db: DB = { questions: [], answers: [], unlocks: [], searches: [] };
  for (const q of SEED_QUESTIONS) {
    db.questions.push({ id: q.id, title: q.title, body: q.body, category: q.category, authorId: null, authorName: q.by, sample: true, createdAt: hoursAgo(q.hoursAgo) });
    q.answers.forEach((a, i) =>
      db.answers.push({ id: `${q.id}-a${i + 1}`, questionId: q.id, authorId: null, authorName: a.by, body: a.text, sample: true, createdAt: hoursAgo(a.hoursAgo) })
    );
  }
  return db;
}

function write(db: DB) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(db));
}

function read(): DB {
  try {
    return JSON.parse(fs.readFileSync(FILE, "utf8")) as DB;
  } catch {
    const db = seed();
    try {
      write(db);
    } catch {
      // read-only filesystem: fall back to a fresh in-memory copy per call
    }
    return db;
  }
}

const withCounts = (db: DB, q: Question): QuestionView => ({ ...q, answerCount: db.answers.filter((a) => a.questionId === q.id).length });

export type Sort = "new" | "unanswered" | "popular";

export function listQuestions(opts: { sort?: Sort; topic?: string } = {}): QuestionView[] {
  const db = read();
  let list = db.questions.map((q) => withCounts(db, q));
  if (opts.topic) list = list.filter((q) => q.category === opts.topic);
  if (opts.sort === "unanswered") list = list.filter((q) => q.answerCount === 0);
  const byNew = (a: QuestionView, b: QuestionView) => Date.parse(b.createdAt) - Date.parse(a.createdAt);
  if (opts.sort === "popular") list.sort((a, b) => b.answerCount - a.answerCount || byNew(a, b));
  else list.sort(byNew);
  return list;
}

export function getQuestion(id: string): QuestionView | null {
  const db = read();
  const q = db.questions.find((x) => x.id === id);
  return q ? withCounts(db, q) : null;
}

export function listAnswers(questionId: string): Answer[] {
  return read()
    .answers.filter((a) => a.questionId === questionId)
    .sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));
}

const uid = () => `u-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export function addQuestion(user: { id: string; name: string }, input: { title: string; body: string; category: Category }): Question {
  const db = read();
  const q: Question = { id: uid(), ...input, authorId: user.id, authorName: user.name, sample: false, createdAt: new Date().toISOString() };
  db.questions.push(q);
  write(db);
  return q;
}

export function addAnswer(user: { id: string; name: string }, questionId: string, body: string): Answer {
  const db = read();
  const a: Answer = { id: uid(), questionId, authorId: user.id, authorName: user.name, body, sample: false, createdAt: new Date().toISOString() };
  db.answers.push(a);
  write(db);
  return a;
}

export function addUnlock(userId: string, questionId: string) {
  const db = read();
  if (!db.unlocks.some((u) => u.userId === userId && u.questionId === questionId)) {
    db.unlocks.push({ userId, questionId });
    write(db);
  }
}

export function userActivity(userId: string) {
  const db = read();
  return {
    answered: new Set(db.answers.filter((a) => a.authorId === userId).map((a) => a.questionId)),
    unlocked: new Set(db.unlocks.filter((u) => u.userId === userId).map((u) => u.questionId)),
    answerCount: db.answers.filter((a) => a.authorId === userId).length,
    unlockCount: db.unlocks.filter((u) => u.userId === userId).length,
  };
}

export function countToday(userId: string, kind: "questions" | "answers"): number {
  const db = read();
  const since = Date.now() - 24 * 3600 * 1000;
  const rows = kind === "questions" ? db.questions.filter((q) => q.authorId === userId) : db.answers.filter((a) => a.authorId === userId);
  return rows.filter((r) => Date.parse(r.createdAt) >= since).length;
}

/**
 * Ten questions across different topics for someone to choose from. Round-robins the topics
 * (starting point rotates with `round`) and prefers questions nobody has answered yet.
 */
export function pickerQuestions(userId: string | null, round = 0, size = 10): QuestionView[] {
  const db = read();
  const answered = userId ? new Set(db.answers.filter((a) => a.authorId === userId).map((a) => a.questionId)) : new Set<string>();
  const pool = db.questions
    .filter((q) => q.authorId !== userId && !answered.has(q.id))
    .map((q) => withCounts(db, q))
    .sort((a, b) => Number(a.answerCount > 0) - Number(b.answerCount > 0) || Date.parse(b.createdAt) - Date.parse(a.createdAt));

  const cats = [...CATEGORIES];
  const start = round % cats.length;
  const order = [...cats.slice(start), ...cats.slice(0, start)];
  const groups = new Map<string, QuestionView[]>(order.map((c) => [c, pool.filter((q) => q.category === c)]));
  // Within a topic, rotate which question leads so "different questions" really differs.
  for (const [c, list] of Array.from(groups.entries())) {
    if (list.length > 1) {
      const k = Math.floor(round / cats.length) % list.length;
      groups.set(c, [...list.slice(k), ...list.slice(0, k)]);
    }
  }
  const out: QuestionView[] = [];
  let i = 0;
  while (out.length < size && Array.from(groups.values()).some((g) => g.length > i)) {
    for (const c of order) {
      const q = groups.get(c)?.[i];
      if (q && out.length < size) out.push(q);
    }
    i++;
  }
  return out;
}

export function addSearch(userId: string, q: string, count: number) {
  const db = read();
  db.searches.push({ userId, q, count, at: new Date().toISOString() });
  db.searches = db.searches.slice(-500);
  write(db);
}

export function recentSearches(userId: string, limit = 8) {
  const seen = new Set<string>();
  return read()
    .searches.filter((s) => s.userId === userId)
    .reverse()
    .filter((s) => (seen.has(s.q.toLowerCase()) ? false : (seen.add(s.q.toLowerCase()), true)))
    .slice(0, limit)
    .map((s) => ({ q: s.q, result_count: s.count, created_at: s.at }));
}

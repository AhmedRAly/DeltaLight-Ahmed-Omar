import { embed } from "./ai";
import type { DecisionMatch, Json, StoryMatch } from "./database.types";
import type { Horizon } from "./constants";
import { createAdminClient } from "./supabase/admin";
import { num, toVector } from "./utils";

export type HorizonPoint = { horizon: Horizon; n: number; avg_predicted: number | null; avg_actual: number | null };
export type OptionStat = {
  option: string;
  n: number;
  would_choose_again_pct: number | null;
  avg_regret: number | null;
  avg_actual: number | null;
  avg_predicted: number | null;
};
export type Insights = {
  n: number;
  n_with_checkins: number;
  n_seed: number;
  avg_predicted: number | null;
  avg_actual: number | null;
  forecast_gap: number | null;
  would_choose_again_pct: number | null;
  avg_regret: number | null;
  by_horizon: HorizonPoint[];
  by_option: OptionStat[];
  top_surprise_tags: { tag: string; n: number }[];
};

export const EMPTY_INSIGHTS: Insights = {
  n: 0,
  n_with_checkins: 0,
  n_seed: 0,
  avg_predicted: null,
  avg_actual: null,
  forecast_gap: null,
  would_choose_again_pct: null,
  avg_regret: null,
  by_horizon: [],
  by_option: [],
  top_surprise_tags: [],
};

type Obj = Record<string, unknown>;
const asObj = (v: unknown): Obj => (v && typeof v === "object" && !Array.isArray(v) ? (v as Obj) : {});
const asArr = (v: unknown): Obj[] => (Array.isArray(v) ? (v as Obj[]) : []);

export function parseInsights(json: Json | null): Insights {
  const o = asObj(json);
  return {
    n: num(o.n) ?? 0,
    n_with_checkins: num(o.n_with_checkins) ?? 0,
    n_seed: num(o.n_seed) ?? 0,
    avg_predicted: num(o.avg_predicted),
    avg_actual: num(o.avg_actual),
    forecast_gap: num(o.forecast_gap),
    would_choose_again_pct: num(o.would_choose_again_pct),
    avg_regret: num(o.avg_regret),
    by_horizon: asArr(o.by_horizon).map((h) => ({
      horizon: String(h.horizon) as Horizon,
      n: num(h.n) ?? 0,
      avg_predicted: num(h.avg_predicted),
      avg_actual: num(h.avg_actual),
    })),
    by_option: asArr(o.by_option).map((p) => ({
      option: String(p.option ?? ""),
      n: num(p.n) ?? 0,
      would_choose_again_pct: num(p.would_choose_again_pct),
      avg_regret: num(p.avg_regret),
      avg_actual: num(p.avg_actual),
      avg_predicted: num(p.avg_predicted),
    })),
    top_surprise_tags: asArr(o.top_surprise_tags).map((t) => ({ tag: String(t.tag), n: num(t.n) ?? 0 })),
  };
}

export type AskResult = {
  query: string;
  mode: "vector" | "text";
  matches: DecisionMatch[];
  insights: Insights;
  stories: StoryMatch[];
};

export async function findSimilar(opts: {
  text: string;
  embedding?: number[] | string | null;
  decisionCount?: number;
  storyCount?: number;
  excludeId?: string;
}): Promise<AskResult> {
  const supabase = createAdminClient();
  const decisionCount = opts.decisionCount ?? 60;
  const storyCount = opts.storyCount ?? 5;

  let vector: string | null = null;
  if (typeof opts.embedding === "string") vector = opts.embedding;
  else if (Array.isArray(opts.embedding)) vector = toVector(opts.embedding);
  else if (opts.embedding === undefined) {
    const e = await embed(opts.text);
    vector = e ? toVector(e) : null;
  }

  let mode: AskResult["mode"] = vector ? "vector" : "text";
  let matches: DecisionMatch[] = [];
  let stories: StoryMatch[] = [];

  if (vector) {
    const [dm, sm] = await Promise.all([
      supabase.rpc("match_decisions", { query_embedding: vector, match_count: decisionCount, threshold: 0.3 }),
      supabase.rpc("match_stories", { query_embedding: vector, match_count: storyCount, filter_path: null }),
    ]);
    matches = dm.data ?? [];
    stories = sm.data ?? [];
    if (dm.error) console.warn("[hindsight] match_decisions:", dm.error.message);
  }

  if (matches.length === 0) {
    mode = "text";
    const dt = await supabase.rpc("search_decisions_text", { q: opts.text, match_count: decisionCount });
    matches = dt.data ?? [];
    if (stories.length === 0) {
      const st = await supabase.rpc("search_stories_text", { q: opts.text, match_count: storyCount, filter_path: null });
      stories = st.data ?? [];
    }
  }

  if (opts.excludeId) matches = matches.filter((m) => m.id !== opts.excludeId);

  let insights = EMPTY_INSIGHTS;
  if (matches.length) {
    const { data, error } = await supabase.rpc("decision_insights", { ids: matches.map((m) => m.id) });
    if (!error) insights = parseInsights(data);
  }

  return { query: opts.text, mode, matches, insights, stories };
}

export type Peek = {
  similar_n: number;
  would_choose_again_pct: number | null;
  avg_actual: number | null;
  forecast_gap: number | null;
  story: { id: string; title: string; url: string; source_id: string; tldr: string } | null;
};

export async function peekDecision(id: string): Promise<Peek | null> {
  const supabase = createAdminClient();
  const { data: d } = await supabase.from("decisions").select("id, text, embedding").eq("id", id).maybeSingle();
  if (!d) return null;
  const res = await findSimilar({
    text: d.text,
    embedding: d.embedding ?? null,
    decisionCount: 40,
    storyCount: 1,
    excludeId: d.id,
  });
  const s = res.stories[0];
  return {
    similar_n: res.insights.n,
    would_choose_again_pct: res.insights.would_choose_again_pct,
    avg_actual: res.insights.avg_actual,
    forecast_gap: res.insights.forecast_gap,
    story: s ? { id: s.id, title: s.title, url: s.url, source_id: s.source_id, tldr: s.tldr } : null,
  };
}

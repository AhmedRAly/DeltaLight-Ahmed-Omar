import { embed } from "./ai";
import type { Tables } from "./database.types";
import type { z } from "zod";
import type { storyFiltersSchema } from "./schemas";
import { createAdminClient } from "./supabase/admin";
import { toVector } from "./utils";

export type StoryFilters = z.infer<typeof storyFiltersSchema>;
export type StoryRow = Omit<Tables<"stories">, "embedding" | "fts">;

export const STORY_COLUMNS =
  "id, raw_item_id, source_id, url, title, category, path, decision_text, what_they_chose, starting_point, outcome, outcome_type, revenue_or_salary_mentioned, timeline, lessons, surprise_tags, tldr, read_time_min, author_handle, created_at";

export const PAGE_SIZE = 18;

export async function listStories(f: StoryFilters): Promise<{ stories: StoryRow[]; mode: "latest" | "hybrid" | "text"; hasMore: boolean }> {
  const supabase = createAdminClient();

  if (f.q && f.q.length >= 2) {
    const e = await embed(f.q);
    const { data: ranked, error } = await supabase.rpc("hybrid_search_stories", {
      q: f.q,
      query_embedding: e ? toVector(e) : null,
      match_count: 60,
    });
    if (error) throw new Error(error.message);
    const ids = (ranked ?? []).map((r) => r.id);
    if (ids.length === 0) return { stories: [], mode: e ? "hybrid" : "text", hasMore: false };
    let query = supabase.from("stories").select(STORY_COLUMNS).in("id", ids);
    if (f.path) query = query.eq("path", f.path);
    if (f.category) query = query.eq("category", f.category);
    if (f.outcome) query = query.eq("outcome_type", f.outcome);
    if (f.source) query = query.eq("source_id", f.source);
    const { data } = await query;
    const rank = new Map(ids.map((id, i) => [id, i]));
    const sorted = (data ?? []).sort((a, b) => (rank.get(a.id) ?? 0) - (rank.get(b.id) ?? 0));
    return { stories: sorted, mode: e ? "hybrid" : "text", hasMore: false };
  }

  let query = supabase.from("stories").select(STORY_COLUMNS).order("created_at", { ascending: false });
  if (f.path) query = query.eq("path", f.path);
  if (f.category) query = query.eq("category", f.category);
  if (f.outcome) query = query.eq("outcome_type", f.outcome);
  if (f.source) query = query.eq("source_id", f.source);
  const from = f.page * PAGE_SIZE;
  const { data, error } = await query.range(from, from + PAGE_SIZE);
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  return { stories: rows.slice(0, PAGE_SIZE), mode: "latest", hasMore: rows.length > PAGE_SIZE };
}

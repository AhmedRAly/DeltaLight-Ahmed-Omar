// Typed schema for the Supabase client (mirrors supabase/migrations/0001_hindsight.sql).
// Regenerate with: npx supabase gen types typescript --project-id <id> > lib/database.types.ts

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

type DecisionMatchRow = {
  id: string;
  text: string;
  category: string;
  options: Json;
  chosen_option: string | null;
  predicted_happiness: number;
  predicted_outcome: string | null;
  confidence: number;
  is_seed: boolean;
  created_at: string;
  similarity: number;
  latest_horizon: string | null;
  latest_actual_happiness: number | null;
  latest_regret: number | null;
  latest_would_choose_again: boolean | null;
  latest_surprise: string | null;
};

type StoryMatchRow = {
  id: string;
  title: string;
  url: string;
  source_id: string;
  category: string;
  path: string;
  tldr: string;
  outcome_type: string;
  decision_text: string;
  what_they_chose: string | null;
  starting_point: string | null;
  outcome: string | null;
  lessons: string[];
  read_time_min: number;
  similarity: number;
};

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          name: string;
          headline: string | null;
          avatar_url: string | null;
          city: string | null;
          path: string;
          stage: string;
          goals: string;
          skills_have: string[];
          skills_need: string[];
          hours_per_week: number;
          looking_for: string[];
          goal_embedding: string | null;
          is_seed: boolean;
          is_guest: boolean;
          room_code: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          headline?: string | null;
          avatar_url?: string | null;
          city?: string | null;
          path?: string;
          stage?: string;
          goals?: string;
          skills_have?: string[];
          skills_need?: string[];
          hours_per_week?: number;
          looking_for?: string[];
          goal_embedding?: string | null;
          is_seed?: boolean;
          is_guest?: boolean;
          room_code?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>;
        Relationships: [];
      };
      decisions: {
        Row: {
          id: string;
          user_id: string | null;
          text: string;
          category: string;
          options: Json;
          chosen_option: string | null;
          predicted_happiness: number;
          predicted_outcome: string | null;
          confidence: number;
          embedding: string | null;
          is_seed: boolean;
          room_code: string | null;
          created_at: string;
          fts: unknown;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          text: string;
          category?: string;
          options?: Json;
          chosen_option?: string | null;
          predicted_happiness: number;
          predicted_outcome?: string | null;
          confidence?: number;
          embedding?: string | null;
          is_seed?: boolean;
          room_code?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["decisions"]["Insert"]>;
        Relationships: [];
      };
      checkins: {
        Row: {
          id: string;
          decision_id: string;
          horizon: string;
          actual_happiness: number;
          regret: number;
          would_choose_again: boolean;
          biggest_surprise: string | null;
          surprise_tags: string[];
          checkin_at: string;
        };
        Insert: {
          id?: string;
          decision_id: string;
          horizon: string;
          actual_happiness: number;
          regret: number;
          would_choose_again: boolean;
          biggest_surprise?: string | null;
          surprise_tags?: string[];
          checkin_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["checkins"]["Insert"]>;
        Relationships: [];
      };
      scheduled_checkins: {
        Row: { id: string; decision_id: string; due_at: string; horizon: string; status: string };
        Insert: { id?: string; decision_id: string; due_at: string; horizon: string; status?: string };
        Update: Partial<Database["public"]["Tables"]["scheduled_checkins"]["Insert"]>;
        Relationships: [];
      };
      sources: {
        Row: {
          id: string;
          name: string;
          type: string;
          base_url: string;
          last_synced_at: string | null;
          items_count: number;
          last_status: string | null;
          last_error: string | null;
        };
        Insert: {
          id: string;
          name: string;
          type: string;
          base_url: string;
          last_synced_at?: string | null;
          items_count?: number;
          last_status?: string | null;
          last_error?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["sources"]["Insert"]>;
        Relationships: [];
      };
      raw_items: {
        Row: {
          id: string;
          source_id: string;
          external_id: string;
          url: string;
          title: string;
          body: string;
          author_handle: string | null;
          posted_at: string | null;
          score: number;
          fetched_at: string;
          processed: boolean;
          is_story: boolean | null;
          process_note: string | null;
        };
        Insert: {
          id?: string;
          source_id: string;
          external_id: string;
          url: string;
          title: string;
          body?: string;
          author_handle?: string | null;
          posted_at?: string | null;
          score?: number;
          fetched_at?: string;
          processed?: boolean;
          is_story?: boolean | null;
          process_note?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["raw_items"]["Insert"]>;
        Relationships: [];
      };
      stories: {
        Row: {
          id: string;
          raw_item_id: string | null;
          source_id: string;
          url: string;
          title: string;
          category: string;
          path: string;
          decision_text: string;
          what_they_chose: string | null;
          starting_point: string | null;
          outcome: string | null;
          outcome_type: string;
          revenue_or_salary_mentioned: string | null;
          timeline: string | null;
          lessons: string[];
          surprise_tags: string[];
          tldr: string;
          read_time_min: number;
          author_handle: string | null;
          embedding: string | null;
          created_at: string;
          fts: unknown;
        };
        Insert: {
          id?: string;
          raw_item_id?: string | null;
          source_id: string;
          url: string;
          title: string;
          category?: string;
          path?: string;
          decision_text: string;
          what_they_chose?: string | null;
          starting_point?: string | null;
          outcome?: string | null;
          outcome_type?: string;
          revenue_or_salary_mentioned?: string | null;
          timeline?: string | null;
          lessons?: string[];
          surprise_tags?: string[];
          tldr: string;
          read_time_min?: number;
          author_handle?: string | null;
          embedding?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["stories"]["Insert"]>;
        Relationships: [];
      };
      connections: {
        Row: {
          id: string;
          from_user: string;
          to_user: string;
          status: string;
          message: string | null;
          match_score: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          from_user: string;
          to_user: string;
          status?: string;
          message?: string | null;
          match_score?: number | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["connections"]["Insert"]>;
        Relationships: [];
      };
      messages: {
        Row: { id: string; connection_id: string; sender: string; body: string; created_at: string };
        Insert: { id?: string; connection_id: string; sender: string; body: string; created_at?: string };
        Update: Partial<Database["public"]["Tables"]["messages"]["Insert"]>;
        Relationships: [];
      };
      ingest_runs: {
        Row: {
          id: string;
          source_id: string;
          status: string;
          fetched: number;
          new_items: number;
          processed: number;
          stories_created: number;
          message: string | null;
          started_at: string;
          finished_at: string | null;
        };
        Insert: {
          id?: string;
          source_id: string;
          status?: string;
          fetched?: number;
          new_items?: number;
          processed?: number;
          stories_created?: number;
          message?: string | null;
          started_at?: string;
          finished_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["ingest_runs"]["Insert"]>;
        Relationships: [];
      };
      circles: {
        Row: {
          id: string;
          slug: string;
          name: string;
          description: string;
          path: string;
          keywords: string[];
          embedding: string | null;
        };
        Insert: {
          id?: string;
          slug: string;
          name: string;
          description: string;
          path?: string;
          keywords?: string[];
          embedding?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["circles"]["Insert"]>;
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: {
      match_decisions: {
        Args: { query_embedding: string; match_count?: number; threshold?: number };
        Returns: DecisionMatchRow[];
      };
      search_decisions_text: {
        Args: { q: string; match_count?: number };
        Returns: DecisionMatchRow[];
      };
      decision_insights: { Args: { ids: string[] }; Returns: Json };
      match_stories: {
        Args: { query_embedding: string; match_count?: number; filter_path?: string | null };
        Returns: StoryMatchRow[];
      };
      search_stories_text: {
        Args: { q: string; match_count?: number; filter_path?: string | null };
        Returns: StoryMatchRow[];
      };
      hybrid_search_stories: {
        Args: { q: string; query_embedding?: string | null; match_count?: number };
        Returns: { id: string; score: number }[];
      };
      match_partners: {
        Args: { p_user_id: string; match_count?: number };
        Returns: {
          id: string;
          name: string;
          headline: string | null;
          avatar_url: string | null;
          city: string | null;
          path: string;
          stage: string;
          goals: string;
          skills_have: string[];
          skills_need: string[];
          hours_per_week: number;
          looking_for: string[];
          is_seed: boolean;
          score: number;
          goal_score: number;
          skill_score: number;
          fit_score: number;
          they_have_i_need: string[];
          i_have_they_need: string[];
        }[];
      };
      room_pairs: {
        Args: { code: string; min_score?: number };
        Returns: {
          a_id: string;
          a_name: string;
          b_id: string;
          b_name: string;
          score: number;
          a_gets: string[];
          b_gets: string[];
        }[];
      };
      match_profiles_by_embedding: {
        Args: { query_embedding: string; match_count?: number };
        Returns: {
          id: string;
          name: string;
          headline: string | null;
          avatar_url: string | null;
          path: string;
          stage: string;
          goals: string;
          is_seed: boolean;
          similarity: number;
        }[];
      };
      circles_overview: { Args: { member_limit?: number }; Returns: Json };
      room_stats: { Args: { code: string }; Returns: Json };
      site_counters: { Args: Record<PropertyKey, never>; Returns: Json };
      global_insights: { Args: Record<PropertyKey, never>; Returns: Json };
    };
    Enums: { [_ in never]: never };
    CompositeTypes: { [_ in never]: never };
  };
};

export type Tables<T extends keyof Database["public"]["Tables"]> = Database["public"]["Tables"][T]["Row"];
export type DecisionMatch = DecisionMatchRow;
export type StoryMatch = StoryMatchRow;
export type PartnerMatch = Database["public"]["Functions"]["match_partners"]["Returns"][number];

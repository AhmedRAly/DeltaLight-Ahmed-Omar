import { z } from "zod";
import { CATEGORIES, HORIZONS, LOOKING_FOR, OUTCOME_TYPES, PATHS, STAGES } from "./constants";

const roomCodeSchema = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z0-9]{3,8}$/)
  .optional()
  .nullable();

export const askSchema = z.object({ q: z.string().trim().min(3).max(400) });

export const decisionInputSchema = z.object({
  text: z.string().trim().min(5).max(600),
  category: z.enum(CATEGORIES),
  options: z.array(z.string().trim().min(1).max(120)).min(1).max(4),
  chosen_option: z.string().trim().min(1).max(120),
  predicted_happiness: z.coerce.number().int().min(1).max(10),
  predicted_outcome: z.string().trim().max(500).optional().nullable(),
  confidence: z.coerce.number().int().min(1).max(10),
  room_code: roomCodeSchema,
});
export type DecisionInput = z.infer<typeof decisionInputSchema>;

export const checkinInputSchema = z.object({
  decision_id: z.string().uuid(),
  horizon: z.enum(HORIZONS),
  actual_happiness: z.coerce.number().int().min(1).max(10),
  regret: z.coerce.number().int().min(0).max(10),
  would_choose_again: z.boolean(),
  biggest_surprise: z.string().trim().max(600).optional().nullable(),
});

export const timeTravelSchema = z.object({ decision_id: z.string().uuid() });

const skillList = z.array(z.string().trim().min(1).max(40)).max(15);

export const profileInputSchema = z.object({
  name: z.string().trim().min(1).max(60),
  headline: z.string().trim().max(120).optional().nullable(),
  city: z.string().trim().max(60).optional().nullable(),
  path: z.enum(PATHS),
  stage: z.enum(STAGES),
  goals: z.string().trim().min(10).max(800),
  skills_have: skillList,
  skills_need: skillList,
  hours_per_week: z.coerce.number().int().min(1).max(80),
  looking_for: z.array(z.enum(LOOKING_FOR)).max(5),
  guest_id: z.string().uuid().optional().nullable(),
  room_code: roomCodeSchema,
});
export type ProfileInput = z.infer<typeof profileInputSchema>;

export const quickProfileSchema = z.object({
  name: z.string().trim().min(1).max(60),
  path: z.enum(PATHS),
  goals: z.string().trim().min(5).max(400),
  skills_have: skillList,
  skills_need: skillList,
  room_code: roomCodeSchema,
});

export const connectSchema = z.object({
  to_user: z.string().uuid(),
  message: z.string().trim().max(500).optional().nullable(),
  match_score: z.number().min(0).max(1).optional().nullable(),
});

export const connectionUpdateSchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["accepted", "declined"]),
});

export const messageSchema = z.object({
  connection_id: z.string().uuid(),
  body: z.string().trim().min(1).max(2000),
});

export const storyFiltersSchema = z.object({
  q: z.string().trim().max(200).optional(),
  path: z.enum(["business", "corporate"]).optional(),
  category: z.enum(CATEGORIES).optional(),
  outcome: z.enum(OUTCOME_TYPES).optional(),
  source: z.string().max(40).optional(),
  page: z.coerce.number().int().min(0).max(50).default(0),
});

export const ingestRequestSchema = z.object({
  source: z.string().min(1).max(40),
  max_process: z.number().int().min(1).max(60).optional(),
});

// ---- AI output schemas ----
export const surpriseTagsSchema = z.object({
  tags: z.array(z.string().trim().min(1).max(40)).max(5),
});

export const storyClassifierSchema = z.object({
  is_story: z.boolean(),
  reason: z.string().max(300).optional(),
});

const nullableText = (max: number) =>
  z
    .string()
    .max(max * 2)
    .nullable()
    .optional()
    .transform((v) => (v && v.trim() ? v.trim().slice(0, max) : null));

export const storyExtractionSchema = z.object({
  title: z.string().min(3).max(300).transform((v) => v.trim().slice(0, 160)),
  category: z.enum(CATEGORIES).catch("other"),
  path: z.enum(["business", "corporate"]).catch("business"),
  decision_text: z.string().min(5).max(600).transform((v) => v.trim()),
  what_they_chose: nullableText(300),
  starting_point: nullableText(400),
  outcome: nullableText(600),
  outcome_type: z.enum(OUTCOME_TYPES).catch("ongoing"),
  revenue_or_salary_mentioned: nullableText(120),
  timeline: nullableText(120),
  lessons: z.array(z.string().min(3).max(400)).max(6).catch([]),
  surprise_tags: z.array(z.string().min(1).max(40)).max(5).catch([]),
  tldr: z.string().min(10).max(800).transform((v) => v.trim()),
});
export type StoryExtraction = z.infer<typeof storyExtractionSchema>;

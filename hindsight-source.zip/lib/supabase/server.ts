import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/lib/database.types";
import { DEMO_COOKIE, demoEnabled, findDemoUser } from "@/lib/demo";

export type SessionUser = { id: string; email?: string | null; name?: string; demo?: boolean };

// Cookie-aware client for Server Components / Route Handlers (acts as the signed-in user).
export function createServerSupabase() {
  const cookieStore = cookies();
  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options));
          } catch {
            // Called from a Server Component: middleware refreshes the session instead.
          }
        },
      },
    }
  );
}

export async function getSessionUser(): Promise<SessionUser | null> {
  // Demo sign-in (hardcoded personas) takes priority when enabled.
  if (demoEnabled()) {
    try {
      const d = findDemoUser(cookies().get(DEMO_COOKIE)?.value);
      if (d) return { id: d.id, email: d.email, name: d.short, demo: true };
    } catch {
      // cookies() unavailable outside a request
    }
  }
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) return null;
  try {
    const supabase = createServerSupabase();
    const { data } = await supabase.auth.getUser();
    return data.user ? { id: data.user.id, email: data.user.email } : null;
  } catch {
    return null;
  }
}

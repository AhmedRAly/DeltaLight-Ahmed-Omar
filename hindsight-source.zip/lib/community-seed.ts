// Hardcoded demo content: previous askers and their answers. Names are made up.
import type { Category } from "./constants";

export type SeedQuestion = {
  id: string;
  title: string;
  body: string;
  category: Category;
  by: string;
  hoursAgo: number;
  answers: { by: string; text: string; hoursAgo: number }[];
};

export const SEED_QUESTIONS: SeedQuestion[] = [
  // ------------------------------------------------------------------ business
  {
    id: "seed-q01",
    title: "Should I raise money or keep bootstrapping my SaaS?",
    body: "Two years in, $9k MRR, just me and one contractor. A few angels offered to invest at a $3M valuation. I like owning the business, but growth has been slow and I am tired of doing everything.",
    category: "business",
    by: "Priya S.",
    hoursAgo: 60,
    answers: [
      { by: "Marcus T.", text: "At $9k MRR I would bootstrap a bit longer. A $3M valuation means you will be expected to grow fast, and if you are not sure how to spend the money, it becomes pressure instead of fuel. If hiring one more person would unlock growth, see if you can afford that from revenue first.", hoursAgo: 55 },
      { by: "Elena V.", text: "I raised a small angel round at a similar stage and do not regret it, but only because I knew exactly what it would buy: one engineer and six months of marketing. Write down what you would do with the cash. If the list is vague, wait.", hoursAgo: 48 },
      { by: "Kenji N.", text: "Ask the angels what happened to their other companies. Some are helpful, some vanish. Their intros and advice matter more than the check at your size.", hoursAgo: 30 },
    ],
  },
  {
    id: "seed-q02",
    title: "How do I find my first 10 customers for a B2B tool?",
    body: "I built a small tool that helps freelance accountants send invoices and reminders. It works, but nobody knows it exists. I have no marketing budget and no audience.",
    category: "business",
    by: "Daniel K.",
    hoursAgo: 90,
    answers: [
      { by: "Hannah L.", text: "Go where accountants already talk: forums, LinkedIn groups, local meetups. Do not pitch. Ask people how they chase late invoices and listen. Your first 10 customers usually come from 30 honest conversations.", hoursAgo: 80 },
      { by: "Omar B.", text: "Offer to set it up for five freelancers for free in exchange for a short call about what is missing. Those five become case studies and referrals.", hoursAgo: 70 },
      { by: "Rachel G.", text: "Cold email works if it is specific. Mention the exact annoyance (chasing unpaid invoices) and offer a 10 minute demo. I got 3 of my first 8 customers that way.", hoursAgo: 40 },
    ],
  },
  {
    id: "seed-q03",
    title: "Is it worth bringing in a co-founder or should I go solo?",
    body: "I am a developer with a decent idea and some savings. A friend from college wants to join as a co-founder on the business side, but we have never worked together.",
    category: "business",
    by: "Aisha M.",
    hoursAgo: 120,
    answers: [
      { by: "Luis P.", text: "Work on a small paid project together first, even for a month. How you handle disagreement and deadlines tells you more than any conversation about vision.", hoursAgo: 110 },
      { by: "Nina F.", text: "Solo is lonely but simple. A co-founder is great only if they fill a real gap. Business skills you lack are a real gap, so it may be worth testing.", hoursAgo: 100 },
    ],
  },
  {
    id: "seed-q04",
    title: "When is the right time to raise prices on existing customers?",
    body: "My product has been the same price for two years. Costs went up and I added features, but I am scared of losing customers if I raise it.",
    category: "business",
    by: "Tom H.",
    hoursAgo: 8,
    answers: [],
  },

  // -------------------------------------------------------------------- career
  {
    id: "seed-q05",
    title: "Should I take the management track or stay an individual contributor?",
    body: "I have been a senior engineer for three years. My manager says I would be a good fit to lead a team, but I enjoy the hands-on work and I am not sure I would like the people side.",
    category: "career",
    by: "Sofia R.",
    hoursAgo: 72,
    answers: [
      { by: "Ethan W.", text: "Try it before committing. Ask to lead a project or mentor two juniors for a quarter. Many companies let you go back, and you learn quickly whether you like unblocking others more than writing code.", hoursAgo: 65 },
      { by: "Grace O.", text: "I went into management and missed building things within a year. I switched back to a staff IC role and was much happier. Know that both paths exist at good companies.", hoursAgo: 50 },
      { by: "Victor D.", text: "If you only want it for the pay bump, do not. If you find yourself caring more about the team shipping than your own code, that is the real signal.", hoursAgo: 40 },
    ],
  },
  {
    id: "seed-q06",
    title: "Is it a red flag to leave a job after only 8 months?",
    body: "The role was not what was described and the team is disorganized. I have a better offer but I worry a short stint will look bad on my resume.",
    category: "career",
    by: "Mei L.",
    hoursAgo: 100,
    answers: [
      { by: "Chris A.", text: "One short stint is fine, especially if you can explain it in one clear sentence like the role changed from what was agreed. Several in a row is what raises eyebrows.", hoursAgo: 90 },
      { by: "Fatima Z.", text: "I left a job at 7 months and it never came up again once I was a year into the next one. Go if the new offer is clearly better.", hoursAgo: 80 },
    ],
  },
  {
    id: "seed-q07",
    title: "How do I negotiate a raise when the company says budgets are frozen?",
    body: "I took on a bigger scope eight months ago and my reviews are strong. HR says there is a salary freeze, but I know others got raises.",
    category: "career",
    by: "Noah J.",
    hoursAgo: 150,
    answers: [
      { by: "Isabel C.", text: "Ask for a title change and a written timeline for the next review. Freezes end, and a documented promotion path gives you leverage later. Also ask about one-off bonuses or learning budget.", hoursAgo: 140 },
      { by: "Raj P.", text: "Bring evidence of the bigger scope and what it would cost to replace you. If they still say no, that is useful information about whether to start looking.", hoursAgo: 130 },
    ],
  },
  {
    id: "seed-q08",
    title: "Should I accept a startup offer with lower pay but meaningful equity?",
    body: "The startup is 12 people, just closed a seed round, and offered me 0.4% equity with a 20% pay cut. I like the team but I have a mortgage.",
    category: "career",
    by: "Laura M.",
    hoursAgo: 5,
    answers: [],
  },

  // --------------------------------------------------------------------- money
  {
    id: "seed-q09",
    title: "Should I pay off student loans early or invest the difference?",
    body: "I have $28k at 5.8% interest and a steady job. I can put $600 a month toward either the loans or index funds. My employer offers a 401k match that I already max out.",
    category: "money",
    by: "Ben S.",
    hoursAgo: 80,
    answers: [
      { by: "Amara E.", text: "At 5.8% a guaranteed return from paying off debt is hard to beat, and you sleep better. Since you already get the match, I would put most of the extra toward the loan and keep a small amount invested.", hoursAgo: 70 },
      { by: "Diego F.", text: "Market returns are higher on average but not guaranteed. I split it 50/50 and refinanced to a lower rate. Check whether you can refinance before deciding.", hoursAgo: 62 },
      { by: "Julia K.", text: "Make sure you have 3 to 6 months of emergency savings first. After that, high interest debt goes first.", hoursAgo: 50 },
    ],
  },
  {
    id: "seed-q10",
    title: "Is buying a house worth it if I might move in three years?",
    body: "Rent in my city keeps rising. I can afford a down payment, but my job could relocate me in a few years.",
    category: "money",
    by: "Sean R.",
    hoursAgo: 110,
    answers: [
      { by: "Priya S.", text: "Three years is usually too short once you add closing costs and selling costs. Many people only break even around five years. If you are unsure, rent and invest the difference.", hoursAgo: 100 },
      { by: "Marcus T.", text: "It depends on the market. In mine, prices rose fast and I came out ahead after 3 years, but that was luck. Do not count on appreciation.", hoursAgo: 90 },
    ],
  },
  {
    id: "seed-q11",
    title: "How much runway do I need before quitting to freelance?",
    body: "I am a designer with two steady clients bringing in about 40% of my current salary. I would like to go full-time freelance but I am nervous.",
    category: "money",
    by: "Elena V.",
    hoursAgo: 130,
    answers: [
      { by: "Kenji N.", text: "Aim for six months of expenses plus a pipeline where you can see the next two months of work. I quit with four months and it was stressful.", hoursAgo: 120 },
      { by: "Hannah L.", text: "Replace at least 70% of your salary from freelance work before leaving, so a slow month does not become a crisis.", hoursAgo: 110 },
      { by: "Omar B.", text: "Raise your rates before you quit. Most new freelancers undercharge, and the extra margin is your real runway.", hoursAgo: 100 },
    ],
  },
  {
    id: "seed-q12",
    title: "Do I need a financial advisor at 28 with $40k saved?",
    body: "I have savings, a 401k, and no debt. I keep seeing ads for advisors but I do not know if paying one makes sense at my level.",
    category: "money",
    by: "Rachel G.",
    hoursAgo: 12,
    answers: [],
  },

  // ----------------------------------------------------------------- education
  {
    id: "seed-q13",
    title: "Is a coding bootcamp still worth it for a career switch?",
    body: "I am 31, working in logistics. Bootcamps cost around $12k and promise job placement, but I keep hearing the junior market is tough.",
    category: "education",
    by: "Luis P.",
    hoursAgo: 70,
    answers: [
      { by: "Nina F.", text: "The market is harder than it was, so a bootcamp alone is risky. Build two real projects, contribute somewhere, and talk to graduates from the last year before paying.", hoursAgo: 60 },
      { by: "Ethan W.", text: "I did self-study plus a cheaper online program and got hired after 10 months. The bootcamp network is nice but you can build it other ways.", hoursAgo: 50 },
      { by: "Grace O.", text: "Ask the bootcamp for outcome data and what percentage got jobs within 6 months, in writing. If they dodge, that is your answer.", hoursAgo: 40 },
    ],
  },
  {
    id: "seed-q14",
    title: "Should I do a master's or get more work experience first?",
    body: "I just finished my undergrad in economics. I have a job offer at a consulting firm and an admission to a master's program. I cannot do both.",
    category: "education",
    by: "Victor D.",
    hoursAgo: 95,
    answers: [
      { by: "Mei L.", text: "Take the job, and look for a master's later if you still want it. Employers often pay for it, and you will know much better what to study.", hoursAgo: 90 },
      { by: "Chris A.", text: "If the program is in a field you cannot enter without it, go. Otherwise work experience usually opens more doors than a second degree.", hoursAgo: 80 },
    ],
  },
  {
    id: "seed-q15",
    title: "How do I choose between two universities with different strengths?",
    body: "One has a better reputation in my field, the other offered me a scholarship that covers most tuition and is in a city I love.",
    category: "education",
    by: "Fatima Z.",
    hoursAgo: 140,
    answers: [
      { by: "Noah J.", text: "Graduating with little debt gives you freedom for years. Unless the reputation gap is huge in your specific field, I would take the scholarship.", hoursAgo: 130 },
      { by: "Isabel C.", text: "Talk to recent graduates of both about where they work now. That tells you more than rankings.", hoursAgo: 120 },
    ],
  },
  {
    id: "seed-q16",
    title: "Is a part-time MBA worth it while working full-time?",
    body: "My company would cover half the cost. It means evenings and weekends for three years, and I worry about burnout.",
    category: "education",
    by: "Raj P.",
    hoursAgo: 6,
    answers: [],
  },

  // ------------------------------------------------------------- relationships
  {
    id: "seed-q17",
    title: "How do I tell my co-founder I am unhappy with their work?",
    body: "We have been building for a year. They miss deadlines and their code needs a lot of fixing. They are also my close friend, so I keep avoiding the conversation.",
    category: "relationships",
    by: "Laura M.",
    hoursAgo: 85,
    answers: [
      { by: "Ben S.", text: "Be specific and kind. Pick two concrete examples, say how they affect the company, and ask what is getting in their way. Avoiding it will cost you the friendship anyway.", hoursAgo: 75 },
      { by: "Amara E.", text: "Agree on weekly goals together so the feedback becomes part of the routine instead of a confrontation.", hoursAgo: 65 },
      { by: "Diego F.", text: "I waited too long and it blew up. Say it now, privately, and offer help before blame.", hoursAgo: 55 },
    ],
  },
  {
    id: "seed-q18",
    title: "Should I start a business with a close friend?",
    body: "We get along great and have complementary skills. I am worried about what happens to the friendship if it fails.",
    category: "relationships",
    by: "Julia K.",
    hoursAgo: 115,
    answers: [
      { by: "Sean R.", text: "Write down roles, equity and what happens if one of you wants out before you start. It feels awkward, but it protects the friendship.", hoursAgo: 105 },
      { by: "Priya S.", text: "I did it with my best friend and we are still close, mostly because we agreed up front on how to handle disagreements.", hoursAgo: 95 },
    ],
  },
  {
    id: "seed-q19",
    title: "My partner wants to move abroad but I am settled here. What do we do?",
    body: "They got an offer in Berlin. I have a good job, family nearby, and I do not speak the language. We have been together four years.",
    category: "relationships",
    by: "Marcus T.",
    hoursAgo: 160,
    answers: [
      { by: "Elena V.", text: "Try a defined period like 12 months with a check-in date. It turns an all-or-nothing decision into an experiment you can both live with.", hoursAgo: 150 },
      { by: "Kenji N.", text: "Think about what you would regret more: missing the chance together or staying while resenting it. Both are real costs.", hoursAgo: 140 },
      { by: "Hannah L.", text: "We moved for my partner's job. The first year was hard, the second was great. Visit the city before deciding.", hoursAgo: 130 },
    ],
  },
  {
    id: "seed-q20",
    title: "How do I set boundaries with a boss who messages me on weekends?",
    body: "My manager sends requests on Saturday and Sunday and expects replies. I like the job otherwise and do not want to look unmotivated.",
    category: "relationships",
    by: "Omar B.",
    hoursAgo: 3,
    answers: [],
  },

  // ------------------------------------------------------------------ location
  {
    id: "seed-q21",
    title: "Is moving to a smaller city actually better for early-career people?",
    body: "Everyone says go to the big city for opportunities, but rent takes half my salary. A smaller city has a good company offering me a similar role.",
    category: "location",
    by: "Rachel G.",
    hoursAgo: 75,
    answers: [
      { by: "Luis P.", text: "I moved to a mid-sized city and saved much more in the first two years. You can always move later with more savings and the same experience.", hoursAgo: 65 },
      { by: "Nina F.", text: "Network matters in some industries. If yours is concentrated in one city, think twice. Otherwise cost of living is a huge advantage.", hoursAgo: 55 },
    ],
  },
  {
    id: "seed-q22",
    title: "Should I relocate for a promotion if it means being far from family?",
    body: "The promotion is a 20% raise and a bigger team, but the city is a 9 hour flight from my parents and I am close to them.",
    category: "location",
    by: "Ethan W.",
    hoursAgo: 105,
    answers: [
      { by: "Grace O.", text: "I moved far for a role and the first six months were lonely. Plan visits in advance and decide up front how long you will give it before reassessing.", hoursAgo: 95 },
      { by: "Victor D.", text: "Ask whether you can work from home for part of the year. Many companies say yes once you have the role.", hoursAgo: 85 },
      { by: "Mei L.", text: "Money fades, relationships with family do not. If your parents are aging, weigh that heavily.", hoursAgo: 75 },
    ],
  },
  {
    id: "seed-q23",
    title: "Is it worth moving abroad for a better salary?",
    body: "I got an offer in Amsterdam paying about 35% more than I make now, but I would be leaving my friends and the language is new.",
    category: "location",
    by: "Chris A.",
    hoursAgo: 135,
    answers: [
      { by: "Fatima Z.", text: "Compare after taxes and cost of living, not just salary. Also check how easy it is to make friends there, since that decides whether you stay.", hoursAgo: 125 },
      { by: "Noah J.", text: "I did it and it was one of my best decisions, mostly for the experience. Treat it as a two-year adventure, not a forever move.", hoursAgo: 115 },
    ],
  },
  {
    id: "seed-q24",
    title: "Will working remotely from a cheaper city hurt my career?",
    body: "I could save a lot by moving to a smaller town while keeping my remote job. I worry about being overlooked for promotions.",
    category: "location",
    by: "Isabel C.",
    hoursAgo: 14,
    answers: [],
  },

  // --------------------------------------------------------------------- other
  {
    id: "seed-q25",
    title: "How do I decide between two good job offers?",
    body: "One pays more and is at a well-known company. The other pays slightly less but has a better manager and more interesting work. I cannot stop going back and forth.",
    category: "other",
    by: "Raj P.",
    hoursAgo: 65,
    answers: [
      { by: "Laura M.", text: "A great manager changes everything about the first two years. If the pay gap is small, I would take the better manager and the learning.", hoursAgo: 55 },
      { by: "Ben S.", text: "List what you would regret not doing in 5 years. Picking from regret, not from fear, makes it clearer.", hoursAgo: 45 },
      { by: "Amara E.", text: "Ask both teams the same five questions and compare how openly they answer. Honest answers say a lot.", hoursAgo: 35 },
    ],
  },
  {
    id: "seed-q26",
    title: "I am burned out but cannot afford a break. What would you do?",
    body: "I work long hours, I am tired all the time, and I am too nervous about money to quit or take unpaid leave.",
    category: "other",
    by: "Diego F.",
    hoursAgo: 100,
    answers: [
      { by: "Julia K.", text: "Start small: protect two evenings a week and one full day off, and talk to your manager about scope. Many people never ask for the change that would help.", hoursAgo: 90 },
      { by: "Sean R.", text: "Check if you have access to mental health days or a short paid leave. Burnout gets worse if you wait, and a quiet job search can give you options.", hoursAgo: 80 },
    ],
  },
  {
    id: "seed-q27",
    title: "How do you know when it is time for a career change at 40?",
    body: "I have been in sales for 15 years. I am good at it but it no longer excites me. I think about moving into teaching or product, but I have a family to support.",
    category: "other",
    by: "Priya S.",
    hoursAgo: 125,
    answers: [
      { by: "Marcus T.", text: "Test it on the side. Take a weekend course or volunteer to teach. If you still want it after three months, you can plan a real transition.", hoursAgo: 115 },
      { by: "Elena V.", text: "Your sales experience transfers well into product roles. A bridge job, like customer success or product operations, lowers the risk.", hoursAgo: 105 },
      { by: "Kenji N.", text: "I changed at 41. It took two years and a pay cut, but I am happier. Save up a cushion first.", hoursAgo: 95 },
    ],
  },
  {
    id: "seed-q28",
    title: "Is taking a sabbatical a smart move or a career risk?",
    body: "I have been working nonstop for 8 years. I have savings for about 6 months and I am thinking about taking time off to travel and reset.",
    category: "other",
    by: "Hannah L.",
    hoursAgo: 145,
    answers: [
      { by: "Omar B.", text: "I took six months off and found a better job after. Employers were curious, not concerned, as long as I could explain what I learned.", hoursAgo: 135 },
      { by: "Rachel G.", text: "Ask if your company offers a sabbatical or unpaid leave. Keeping your job as a safety net makes it much easier.", hoursAgo: 125 },
    ],
  },
];

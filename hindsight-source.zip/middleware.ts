import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { DEMO_COOKIE, demoEnabled } from "@/lib/demo";

const PUBLIC_PREFIXES = ["/login", "/api", "/auth", "/room", "/source", "/checkin"];

// Refreshes the Supabase auth session cookie on navigation.
export async function middleware(request: NextRequest) {
  // Demo gate: nothing is visible until you "sign in" on /login.
  if (demoEnabled()) {
    const { pathname, search } = request.nextUrl;
    const open = PUBLIC_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));
    const signedIn = request.cookies.has(DEMO_COOKIE) || request.cookies.getAll().some((c) => c.name.startsWith("sb-"));
    if (!open && !signedIn) {
      const url = request.nextUrl.clone();
      url.pathname = "/login";
      url.search = pathname === "/" ? "" : `?next=${encodeURIComponent(pathname + search)}`;
      return NextResponse.redirect(url);
    }
  }
  let response = NextResponse.next({ request });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return response;

  try {
    const supabase = createServerClient(url, key, {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        },
      },
    });
    await supabase.auth.getUser();
  } catch {
    // Never block navigation on auth refresh failures.
  }
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/cron|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
